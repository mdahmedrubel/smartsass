<?php
/*Yearly Archive */
class theme_yearly_archive_Widget extends WP_Widget {
    function __construct() {
        parent::__construct(
            'year_archive_widget',
            esc_html__( 'Smartsaas :: Yearly Archive', 'smartsaas' ),
            array( 'description' => esc_html__( 'Smartsaas yearly archive widget', 'smartsaas' ), ) // Args
        );
    }

    private $widget_fields = array(
    );

    public function widget( $args, $instance ) {
        echo $args['before_widget'];

        
        
        $medicap_archive_q = new WP_Query(array(
          's' => (!empty($_REQUEST["search"])?$_REQUEST["search"]:''),
          'post_type' => 'post',
          'post_status' =>'publish',
          'orderby'  => 'random',
          'cat' => -1,
          'posts_per_page' => 10,
          'monthnum' =>(!empty($_GET["monthnum"])?$_GET["monthnum"]:''),
          'year' => (!empty($_GET["year"])?$_GET["year"]:''),
          'orderby' =>(!empty($_GET["orderby"])?$_GET["orderby"]:'date'),
          'order' => (!empty($_GET["order"])?$_GET["order"]:'DSCE'),

        ));

        ?>
        <div class="widget widget-archive">
            <div class="widget-header">
                <h5><?php if ( ! empty( $instance['title'] ) ): echo esc_html($instance['title']); endif;  ?></h5>
            </div>
            <ul class="widget-wrapper lab-ul">
                <?php
                if($medicap_archive_q->have_posts()):
                 while($medicap_archive_q->have_posts()): $medicap_archive_q->the_post();  
                ?>
                <li>
                    <a href="#" class="d-flex flex-wrap justify-content-between">
                        <span>
                            <i class="icofont-double-right"></i>
                            <?php echo esc_html(get_the_date('F')); ?>
                        </span>
                        <span><?php echo esc_html(get_the_date('Y')); ?></span>
                    </a> 
                </li>
                <?php 
                endwhile; 
                endif; 
                wp_reset_query(); 
                ?>
         
            </ul>
        </div>
        <?php
        
        echo $args['after_widget'];
    }

    public function field_generator( $instance ) {
        $output = '';
        foreach ( $this->widget_fields as $widget_field ) {
            $default = '';
            if ( isset($widget_field['default']) ) {
                $default = $widget_field['default'];
            }
            $widget_value = ! empty( $instance[$widget_field['id']] ) ? $instance[$widget_field['id']] : esc_html__( $default, 'smartsaas' );
            switch ( $widget_field['type'] ) {
                default:
                    $output .= '<p>';
                    $output .= '<label for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'smartsaas' ).':</label> ';
                    $output .= '<input class="widefat" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" type="'.$widget_field['type'].'" value="'.esc_attr( $widget_value ).'">';
                    $output .= '</p>';
            }
        }
        echo $output;
    }

    public function form( $instance ) {
        $title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'smartsaas' );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'smartsaas' ); ?></label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <?php
        $this->field_generator( $instance );
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        foreach ( $this->widget_fields as $widget_field ) {
            switch ( $widget_field['type'] ) {
                default:
                    $instance[$widget_field['id']] = ( ! empty( $new_instance[$widget_field['id']] ) ) ? strip_tags( $new_instance[$widget_field['id']] ) : '';
            }
        }
        return $instance;
    }
}

if(!function_exists('smartsaas_year_archive_widget')){
    function smartsaas_year_archive_widget() {
        register_widget( 'theme_yearly_archive_Widget' );
        }
    add_action( 'widgets_init', 'smartsaas_year_archive_widget' );  
}