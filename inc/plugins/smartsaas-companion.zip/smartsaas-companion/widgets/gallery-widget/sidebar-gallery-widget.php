<?php 
class Gallery_Widget extends WP_Widget {
	function __construct() {
		parent::__construct(
			'gallery_widget',
			esc_html__( 'Smartsaas:: Gallery', 'smartsaas' ),
			array( 'description' => esc_html__( 'gallery image', 'smartsaas' ), ) // Args
		);
		add_action( 'admin_footer', array( $this, 'media_fields' ) );
		add_action( 'customize_controls_print_footer_scripts', array( $this, 'media_fields' ) );
	}

	private $widget_fields = array(
		array(
			'label' => 'Gallery Image 1',
			'id' => 'img1_media',
			'type' => 'media',
		),
		array(
			'label' => 'Gallery Image 2',
			'id' => 'img2_media',
			'type' => 'media',
		),
		array(
			'label' => 'Gallery Image 3',
			'id' => 'img3_media',
			'type' => 'media',
		),
		array(
			'label' => 'Gallery Image 4',
			'id' => 'img4_media',
			'type' => 'media',
		),
		array(
			'label' => 'Gallery Image 5',
			'id' => 'img5_media',
			'type' => 'media',
		),
		array(
			'label' => 'Gallery Image 6',
			'id' => 'img6_media',
			'type' => 'media',
		),
		array(
			'label' => 'Gallery Image 7',
			'id' => 'img7_media',
			'type' => 'media',
		),
		array(
			'label' => 'Gallery Image 8',
			'id' => 'img8_media',
			'type' => 'media',
		),
		array(
			'label' => 'Gallery Image 9',
			'id' => 'img9_media',
			'type' => 'media',
		),
	);

	public function widget( $args, $instance ) {
		echo $args['before_widget'];

	?>
	<div class="widget widget-instagram">
	    <div class="widget-header">
	        <h5>
	        	<?php if(!empty($instance['title'])): echo esc_html($instance['title']); endif;  ?>
	        </h5>
	    </div>
	        <ul class="widget-wrapper d-flex flex-wrap justify-content-center">
	        	<?php
	        	$gallery1 = wp_get_attachment_url($instance['img1_media']); 
	        	if(!empty($gallery1)):
	        	?>
	            <li>
	                <a href="<?php echo esc_url($gallery1); ?>">
	                    <img src="<?php echo esc_url($gallery1); ?>" alt="<?php bloginfo('name'); ?>">
	                </a>
	            </li>
	        	<?php
	        	endif;
	        	$gallery2 = wp_get_attachment_url($instance['img2_media']); 
	        	if(!empty($gallery2)):
	        	?>
	            <li>
	                <a href="<?php echo esc_url($gallery2); ?>">
	                    <img src="<?php echo esc_url($gallery2); ?>" alt="<?php bloginfo('name'); ?>">
	                </a>
	            </li>
	        	<?php
	        	endif;
	        	$gallery3 = wp_get_attachment_url($instance['img3_media']); 
	        	if(!empty($gallery3)): 
	        	?>
	            <li>
	                <a href="<?php echo esc_url($gallery3); ?>">
	                    <img src="<?php echo esc_url($gallery3); ?>" alt="<?php bloginfo('name'); ?>">
	                </a>
	            </li>
	        	<?php
	        	 endif;
	        	$gallery4 = wp_get_attachment_url($instance['img4_media']); 
	        	if(!empty($gallery4)):  
	        	?>
	            <li>
	                <a href="<?php echo esc_url($gallery4); ?>">
	                    <img src="<?php echo esc_url($gallery4); ?>" alt="<?php bloginfo('name'); ?>">
	                </a>
	            </li>
		        <?php
		         endif;
		        $gallery5 = wp_get_attachment_url($instance['img5_media']); 
	        	if(!empty($gallery5)): 
		        ?>
	            <li>
	                <a href="<?php echo esc_url($gallery5); ?>">
	                    <img src="<?php echo esc_url($gallery5); ?>" alt="<?php bloginfo('name'); ?>">
	                </a>
	            </li>
	        	<?php
	        	endif; 
	        	$gallery6 = wp_get_attachment_url($instance['img6_media']); 
	        	if(!empty($gallery6)): 
	        	?>
	            <li>
	                <a href="<?php echo esc_url($gallery6); ?>">
	                    <img src="<?php echo esc_url($gallery6); ?>" alt="<?php bloginfo('name'); ?>">
	                </a>
	            </li>
	        	<?php
	        	endif;
	        	$gallery7 = wp_get_attachment_url($instance['img7_media']); 
	        	if(!empty($gallery7)):  
	        	?>
	            <li>
	                <a href="<?php echo esc_url($gallery7); ?>">
	                    <img src="<?php echo esc_url($gallery7); ?>" alt="<?php bloginfo('name'); ?>">
	                </a>
	            </li>
	        	<?php
	        	endif; 
	        	$gallery8 = wp_get_attachment_url($instance['img8_media']); 
	        	if(!empty($gallery8)): 
	        	?>
	            <li>
	                <a href="<?php echo esc_url($gallery8); ?>">
	                    <img src="<?php echo esc_url($gallery8); ?>" alt="<?php bloginfo('name'); ?>">
	                </a>
	            </li>
	        	<?php
	        	endif;
	        	$gallery9 = wp_get_attachment_url($instance['img9_media']); 
	        	if(!empty($gallery9)):  
	        	?>
	            <li>
	                <a href="<?php echo esc_url($gallery9); ?>">
	                    <img src="<?php echo esc_url($gallery9); ?>" alt="<?php bloginfo('name'); ?>">
	                </a>
	            </li>
		        <?php
		        endif;
		        ?>
	        </ul>
	</div>
	<?php 
	echo $args['after_widget'];
	}

	public function media_fields() {
		?><script>
			jQuery(document).ready(function($){
				if ( typeof wp.media !== 'undefined' ) {
					var _custom_media = true,
					_orig_send_attachment = wp.media.editor.send.attachment;
					$(document).on('click','.custommedia',function(e) {
						var send_attachment_bkp = wp.media.editor.send.attachment;
						var button = $(this);
						var id = button.attr('id');
						_custom_media = true;
							wp.media.editor.send.attachment = function(props, attachment){
							if ( _custom_media ) {
								$('input#'+id).val(attachment.id);
								$('span#preview'+id).css('background-image', 'url('+attachment.url+')');
								$('input#'+id).trigger('change');
							} else {
								return _orig_send_attachment.apply( this, [props, attachment] );
							};
						}
						wp.media.editor.open(button);
						return false;
					});
					$('.add_media').on('click', function(){
						_custom_media = false;
					});
					$(document).on('click', '.remove-media', function() {
						var parent = $(this).parents('p');
						parent.find('input[type="media"]').val('').trigger('change');
						parent.find('span').css('background-image', 'url()');
					});
				}
			});
		</script><?php
	}

	public function field_generator( $instance ) {
		$output = '';
		foreach ( $this->widget_fields as $widget_field ) {
			$default = '';
			if ( isset($widget_field['default']) ) {
				$default = $widget_field['default'];
			}
			$widget_value = ! empty( $instance[$widget_field['id']] ) ? $instance[$widget_field['id']] : esc_html__( $default, 'smartsaas' );
			switch ( $widget_field['type'] ) {
				case 'media':
					$media_url = '';
					if ($widget_value) {
						$media_url = wp_get_attachment_url($widget_value);
					}
					$output .= '<p>';
					$output .= '<label for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'smartsaas' ).':</label> ';
					$output .= '<input style="display:none;" class="widefat" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" type="'.$widget_field['type'].'" value="'.$widget_value.'">';
					$output .= '<span id="preview'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" style="margin-right:10px;border:2px solid #eee;display:block;width: 100px;height:100px;background-image:url('.$media_url.');background-size:contain;background-repeat:no-repeat;"></span>';
					$output .= '<button id="'.$this->get_field_id( $widget_field['id'] ).'" class="button select-media custommedia">Add Media</button>';
					$output .= '<input style="width: 19%;" class="button remove-media" id="buttonremove" name="buttonremove" type="button" value="Clear" />';
					$output .= '</p>';
					break;
				default:
					$output .= '<p>';
					$output .= '<label for="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'">'.esc_attr( $widget_field['label'], 'smartsaas' ).':</label> ';
					$output .= '<input class="widefat" id="'.esc_attr( $this->get_field_id( $widget_field['id'] ) ).'" name="'.esc_attr( $this->get_field_name( $widget_field['id'] ) ).'" type="'.$widget_field['type'].'" value="'.esc_attr( $widget_value ).'">';
					$output .= '</p>';
			}
		}
		echo $output;
	}

	public function form( $instance ) {
		$title = ! empty( $instance['title'] ) ? $instance['title'] : esc_html__( '', 'smartsaas' );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_attr_e( 'Title:', 'smartsaas' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<?php
		$this->field_generator( $instance );
	}

	public function update( $new_instance, $old_instance ) {
		$instance = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
		foreach ( $this->widget_fields as $widget_field ) {
			switch ( $widget_field['type'] ) {
				default:
					$instance[$widget_field['id']] = ( ! empty( $new_instance[$widget_field['id']] ) ) ? strip_tags( $new_instance[$widget_field['id']] ) : '';
			}
		}
		return $instance;
	}
}

function register_gallery_widget() {
	register_widget( 'Gallery_Widget' );
}
add_action( 'widgets_init', 'register_gallery_widget' );