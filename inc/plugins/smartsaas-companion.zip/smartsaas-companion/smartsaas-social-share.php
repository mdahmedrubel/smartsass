<?php
/*
This is displaying Social share
*/
defined( 'ABSPATH' ) || exit;
 
if( ! function_exists('smartsaas_social_share')){
	function smartsaas_social_share(){
	    
	?>
		<a class="facebook" onClick="window.open('http://www.facebook.com/sharer.php?u=<?php echo site_url();?>','Facebook','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://www.facebook.com/sharer.php?u=<?php echo site_url();?>">
			<i class="icofont-facebook"></i>
		</a>
		<a class="twitter" onClick="window.open('http://twitter.com/share?url=<?php echo site_url();?>&amp;text=<?php bloginfo('title'); ?>','Twitter share','width=600,height=300,left='+(screen.availWidth/2-300)+',top='+(screen.availHeight/2-150)+''); return false;" href="http://twitter.com/share?url=<?php echo site_url();?>&amp;text=<?php echo str_replace(" ", "%20", bloginfo('title')); ?>">
			<i class="icofont-twitter"></i>
		</a> 					 
		<a class="linkedin" href="https://www.linkedin.com/share?url=<?php echo site_url(); ?>" onclick="window.open( 'https://www.linkedin.com/share?url=<?php echo site_url(); ?>', 'sharer', 'toolbar=0, status=0, width=600, height=300'); return false;">
			<i class="icofont-linkedin"></i>
		</a>
		<a class="vimeo" href="http://vimeo.com/share?url=<?php echo site_url(); ?>" onclick="window.open( 'http://vimeo.com/share?url=<?php echo site_url(); ?>', 'sharer', 'toolbar=0, status=0, width=600, height=300'); return false;">
			<i class="icofont-vimeo"></i>
		</a>
	<?php
	 }
}