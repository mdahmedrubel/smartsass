<?php 
/*
*This is for showing custom post for the theme
*/

/*smartsaas team section custom post type*/
if ( !class_exists('smartsaas_Team_Custom_Post_Type') ):
	class smartsaas_Team_Custom_Post_Type {
		public static $post_type = 'team';
		public static $menu_position = 5;
		public static function register() {
			
			$labels = array(
				'name'                  => esc_html__('Teams',                 'smartsaas'),
				'singular_name'         => esc_html__('Team',            	   'smartsaas'),
				'add_new'               => esc_html__('Add New Team',          'smartsaas'),
				'add_new_item'          => esc_html__('Add New Team',          'smartsaas'),
				'edit_item'             => esc_html__('Edit Team',             'smartsaas'),
				'new_item'              => esc_html__('New Team',              'smartsaas'),
				'view_item'             => esc_html__('View Team',             'smartsaas'),
				'search_items'          => esc_html__('Search Team',           'smartsaas'),
				'not_found'             => esc_html__('No Team found',         'smartsaas'),
				'not_found_in_trash'    => esc_html__('No Team found in trash','smartsaas'),
				'all_items'			    => esc_html__( 'All Teams', 		   'smartsaas' ), 
				'featured_image'        => esc_html__( 'Team image', 		   'smartsaas' ),    
			    'set_featured_image'    => esc_html__( 'Set team image', 	   'smartsaas' ),    
			    'remove_featured_image' => esc_html__( 'Remove team image',    'smartsaas' ), 
			    'use_featured_image'    => esc_html__( 'Use as team image',    'smartsaas' ),
				'parent_item_colon'     => '',
				'menu_name'             => esc_html__('Teams',                 'smartsaas')
			);

			$args = array(
				'labels'                => $labels,
				'public'                => true,
				'publicly_queryable'    => true,
				'show_ui'               => true,
				'show_in_menu'          => true, 
				'query_var'             => true,
				'rewrite'               => array( 'slug' => self::$post_type ),
				'capability_type'       => 'post',
				'has_archive'           => false, 
				'hierarchical'          => false,
				'menu_position'         => self::$menu_position,
				'menu_icon'             => 'dashicons-networking',
				'supports'              => array( 'title', 'editor', 'thumbnail'),
			);

			$args = apply_filters( 'presscore_post_type_' . self::$post_type . '_args', $args );

			register_post_type( self::$post_type, $args );
	                flush_rewrite_rules();
		}	
	}
endif;


/*smartsaas services section custom post type*/
if ( !class_exists('smartsaas_Service_Custom_Post_Type') ):
	class smartsaas_Service_Custom_Post_Type {
		public static $post_type = 'service';
		public static $menu_position = 5;
		public static function register() {
			
			$labels = array(
				'name'                  => esc_html__('Services',                 'smartsaas'),
				'singular_name'         => esc_html__('Service',            	  'smartsaas'),
				'add_new'               => esc_html__('Add New Service',          'smartsaas'),
				'add_new_item'          => esc_html__('Add New Service',          'smartsaas'),
				'edit_item'             => esc_html__('Edit Service',             'smartsaas'),
				'new_item'              => esc_html__('New Service',              'smartsaas'),
				'view_item'             => esc_html__('View Service',             'smartsaas'),
				'search_items'          => esc_html__('Search Service',           'smartsaas'),
				'not_found'             => esc_html__('No Service found',         'smartsaas'),
				'not_found_in_trash'    => esc_html__('No Service found in trash','smartsaas'),
				'all_items'			    => esc_html__( 'All Services', 		   	  'smartsaas' ), 
				'featured_image'        => esc_html__( 'Service image', 		  'smartsaas' ),    
			    'set_featured_image'    => esc_html__( 'Set service image', 	  'smartsaas' ),    
			    'remove_featured_image' => esc_html__( 'Remove service image',    'smartsaas' ), 
			    'use_featured_image'    => esc_html__( 'Use as service image',    'smartsaas' ),
				'parent_item_colon'     => '',
				'menu_name'             => esc_html__('Services',                 'smartsaas')
			);

			$args = array(
				'labels'                => $labels,
				'public'                => true,
				'publicly_queryable'    => true,
				'show_ui'               => true,
				'show_in_menu'          => true, 
				'query_var'             => true,
				'rewrite'               => array( 'slug' => self::$post_type ),
				'capability_type'       => 'post',
				'has_archive'           => false, 
				'hierarchical'          => false,
				'menu_position'         => self::$menu_position,
				'menu_icon'             => 'dashicons-star-filled',
				'supports'              => array( 'title', 'editor', 'thumbnail'),
			);

			$args = apply_filters( 'presscore_post_type_' . self::$post_type . '_args', $args );

			register_post_type( self::$post_type, $args );
	                flush_rewrite_rules();
		}	
	}
endif;

/*smartsaas services taxonomy*/
if ( !class_exists('smartsaas_services_custom_post_taxonomy') ):
	function smartsaas_services_custom_post_taxonomy() {
	    register_taxonomy(
	        'service_cat', 
	        'service',               
	        array(
	            'label'                 => 'Services Category',
	            'show_admin_column'     => true,
	            'hierarchical'    => true,
	        )
	    );
	}
	add_action( 'init', 'smartsaas_services_custom_post_taxonomy');
endif;
/*smartsaas services taxonomy*/





/*smartsaas custompost for Portfolio */
if ( !class_exists('smartsaas_Portfolio_Custom_Post_Type') ):
	class smartsaas_Portfolio_Custom_Post_Type {
		public static $post_type = 'portfolio';
		public static $menu_position = 11;
		public static function register() {
			
			
			$labels = array(
				'name'                  => esc_html__('Portfolios',                 'smartsaas'),
				'singular_name'         => esc_html__('Portfolio',            	  'smartsaas'),
				'add_new'               => esc_html__('Add New Portfolio',          'smartsaas'),
				'add_new_item'          => esc_html__('Add New Portfolio',          'smartsaas'),
				'edit_item'             => esc_html__('Edit Portfolio',             'smartsaas'),
				'new_item'              => esc_html__('New Portfolio',              'smartsaas'),
				'view_item'             => esc_html__('View Portfolio',             'smartsaas'),
				'search_items'          => esc_html__('Search Portfolio',           'smartsaas'),
				'not_found'             => esc_html__('No Portfolio found',         'smartsaas'),
				'not_found_in_trash'    => esc_html__('No Portfolio found in trash','smartsaas'),
				'all_items'			    => esc_html__( 'All Portfolio', 			  'smartsaas' ), 
				'featured_image'        => esc_html__( 'Portfolio image', 		  'smartsaas' ),    
			    'set_featured_image'    => esc_html__( 'Set Portfolio image', 	  'smartsaas' ),    
			    'remove_featured_image' => esc_html__( 'Remove Portfolio image', 	  'smartsaas' ), 
			    'use_featured_image'    => esc_html__( 'Use as Portfolio image',    'smartsaas' ),
				'parent_item_colon'     => '',
				'menu_name'             => esc_html__('Portfolios',                 'smartsaas')
			);

		
			$args = array(
				'labels'                => $labels,
				'public'                => true,
				'publicly_queryable'    => true,
				'show_ui'               => true,
				'show_in_menu'          => true, 
				'query_var'             => true,
				'rewrite'               => array( 'slug' => self::$post_type ),
				'capability_type'       => 'post',
				'has_archive'           => false, 
				'hierarchical'          => false,
				'menu_position'         => self::$menu_position,
				'menu_icon'             => 'dashicons-info',
				'supports'              => array('title','editor', 'thumbnail'),
			);

			$args = apply_filters( 'presscore_post_type_' . self::$post_type . '_args', $args );

			register_post_type( self::$post_type, $args );
	                flush_rewrite_rules();
					
		}	
	}
endif;

/*smartsaas portfolio taxonomy*/
if ( !class_exists('smartsaas_portfolio_custom_post_taxonomy') ):
	function smartsaas_portfolio_custom_post_taxonomy() {
	    register_taxonomy(
	        'Portfolio_cat', 
	        'portfolio',               
	        array(
	            'label'               => 'Portfolios Category',
	            'show_admin_column'   => true,
	            'hierarchical'    	  => true,
	        )
	    );
	}
	add_action( 'init', 'smartsaas_portfolio_custom_post_taxonomy');
 
endif;
/*smartsaas portfolio taxonomy*/


/////////////////////////
// Register post types //
/////////////////////////

if ( ! function_exists( 'smartsaas_register_post_types' ) ) :
	function smartsaas_register_post_types() {
		smartsaas_Team_Custom_Post_Type::register();
		smartsaas_Service_Custom_Post_Type::register();
		smartsaas_Portfolio_Custom_Post_Type::register();
}
add_action( 'init', 'smartsaas_register_post_types', 10 );
endif;