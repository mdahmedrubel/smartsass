<?php
/**
 * Plugin Name: SmartSaas Companion
 * Plugin URI: 
 * Description: This plugin is essential for smartsaas theme
 * Author: CodexCoder
 * Author URI: 
 * Version: 1.0.0
 * Text Domain: smartsaas
 */


defined( 'ABSPATH' ) || exit;

/**
* Define Plugin DIR
*/
define( 'SMARTSAAS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

/*
* All Custom Post types on this file
*/
//require_once( ENVISHARE_PLUGIN_DIR . 'post-type.php' ); 


include_once( ABSPATH . 'wp-admin/includes/plugin.php' );

/*
* All Custom Post types on this file
*/
require_once( SMARTSAAS_PLUGIN_DIR . 'smartsaas-custompost.php' ); 
require_once( SMARTSAAS_PLUGIN_DIR . 'smartsaas-social-share.php' ); 





// footer widgets
require_once SMARTSAAS_PLUGIN_DIR . '/widgets/footer-about-widget/smartsaas-footer-about-widget-class.php';
require_once SMARTSAAS_PLUGIN_DIR . '/widgets/footer-social-widget/smartsaas-footer-social-widget-class.php';
require_once SMARTSAAS_PLUGIN_DIR . '/widgets/footer-top-widget/smartsaas-footer-top-widget-class.php';


//blog sidebar widget
require_once SMARTSAAS_PLUGIN_DIR . '/widgets/search-widget/search-widget.php';
require_once SMARTSAAS_PLUGIN_DIR . '/widgets/category/class-category-widget.php';
require_once SMARTSAAS_PLUGIN_DIR . '/widgets/latest-posts/class-widget-latest-news.php';
require_once SMARTSAAS_PLUGIN_DIR . '/widgets/date-archive/date-archive-widget.php';
require_once SMARTSAAS_PLUGIN_DIR . '/widgets/tags-clouds/tag-cloud-class-widget.php';
require_once SMARTSAAS_PLUGIN_DIR . '/widgets/gallery-widget/sidebar-gallery-widget.php';



