<?php
class Smartsass__Seo_Analysis_Section extends \Elementor\Widget_Base {
	public function get_name() {
		return "seo_analysis";
	}

	public function get_title() {
		return __( "SEO Analysis", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'SEO Analysis Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'analysis_shortcode',[
				'label' => __( 'Contact Shortcode', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'contact_shape',[
				'label' => __( 'Circle Shape Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$this->add_control(
			'contact_imgs',[
				'label' => __( 'Contact Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);

		$this->add_control(
			'critht_title',[
				'label' => __( 'Right Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cright_desc',[
				'label' => __( 'Right Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'right_analytics',[
				'label' => __( 'Analysis Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
			]
		);
		$this->add_control(
			'right_groups',
			[
				'label' => __( 'Seo About Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$right_groups = $this->get_settings('right_groups');
	?>
	<!-- SEO Analysis Section Start Here -->
	<section class="seo-analysis-section padding-tb">
		<div class="round-shape d-none d-lg-block">
			<div class="round">
				<?php if(!empty($settings['contact_shape']['url'])): ?>
					<img src="<?php echo wp_kses_post($settings['contact_shape']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
				<?php endif; ?>
			</div>
		</div>
		<div class="container">
			<div class="section-wrapper">
				<div class="row align-items-center">
					<div class="col-lg-6 col-12">
						<div class="analysis-from">
							<div class="lab-abs-thumb">
								<?php if(!empty($settings['contact_imgs']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['contact_imgs']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
							</div>
							<div class="analysis-head">
								<h4><?php _e('Free SEO Analysis', 'smartsaas'); ?></h4>
							</div>
							<div class="analysis-body">
								<?php
								 if(!empty($settings['analysis_shortcode'])): 
								 	echo do_shortcode($settings['analysis_shortcode']); 
								endif; 
								?>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="section-header style-2">
							<h2><?php if(!empty($settings['critht_title'])): echo esc_html($settings['critht_title']); endif; ?></h2>
							<p><?php if(!empty($settings['cright_desc'])): echo esc_html($settings['cright_desc']); endif; ?></p>
							<ul class="smart-list-ef">
								<?php 
								if(!empty($right_groups)):
								foreach($right_groups as $right_group):
								?>
								<li>
									<div class="left"><span><i class="icofont-tick-mark"></i></span></div>
									<div class="right">
										<p><?php if(!empty($right_group['right_analytics'])): echo esc_html($right_group['right_analytics']); endif; ?></p>
									</div>
								</li>
								<?php
								endforeach;
								endif; 
								?>
							</ul>
							<div class="codex-shape">
								<div class="line line_5"></div>
								<div class="line line_6"></div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- SEO  Analysis Section Ending Here -->
	<?php
		
	}



}





