<?php
class Smartsass_Team_Style_One extends \Elementor\Widget_Base {
	public function get_name() {
		return "team_one";
	}

	public function get_title() {
		return __( "Team One", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Team Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'team_count',[
				'label' => __( 'Team Count', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
    <!-- Team Member Section Start here -->
	<div class="team-section style-2 padding-tb">
		<div class="container">
		    <div class="row">
		        <div class="col-12">
		            <div class="team-bottom">
		                <div class="team-bottom-area">
		                    <div class="row justify-content-center align-items-center">
		                    	<?php 
								$saas_teams = new WP_Query(array(
									'post_type'  => 'team',
									'posts_per_page'  => esc_attr($settings['team_count']),
									'post_status'     => 'publish',
									'order'     => 'ASC',

									));
								?>
								<?php
								if ($saas_teams->have_posts()):
								 	while($saas_teams->have_posts()): 
								 	$saas_teams->the_post(); 
								 	$saas_team_m = get_post_meta(get_the_ID(), 'saas_team', true);
								?>
		                        <div class="col-xl-4 col-md-6 col-12">
		                            <div class="team-item style-2">
		                                <div class="team-item-inner">
		                                    <div class="team-thumb">
		                                        <div class="t-thumb">
		                                        	<?php  
		                                        	$team_img = get_the_post_thumbnail_url();
		                                        	?>
		                                            <img src="<?php echo esc_url($team_img); ?>" alt="<?php bloginfo('name'); ?>">
		                                        </div>
		                                        <div class="self-intregration">
		                                            <div class="intregration-head">
		                                                <span><?php esc_html_e('Follow Me', 'smartsaas'); ?></span>
		                                            </div>
		                                            <div class="intregration-icon">
		                                                <ul>
		                                                	<?php if(!empty($saas_team_m['team_fburl'])): ?>
		                                                    <li><a href="<?php echo esc_url($saas_team_m['team_fburl']); ?>" class="facebook"><i class="fab fa-facebook-f"></i></a></li>
		                                                	<?php endif; ?>
		                                                	<?php if(!empty($saas_team_m['team_piurl'])): ?>
		                                                    <li><a href="<?php echo esc_url($saas_team_m['team_piurl']); ?>" class="pinterest"><i class="fab fa-pinterest-p"></i></a></li>
		                                                    <?php endif; ?>
		                                                    <?php if(!empty($saas_team_m['team_twurl'])): ?>
		                                                    <li><a href="<?php echo esc_url($saas_team_m['team_twurl']); ?>" class="twitter"><i class="fab fa-twitter"></i></a></li>
		                                                    <?php endif; ?>
		                                                    <?php if(!empty($saas_team_m['team_gburl'])): ?>
		                                                    <li><a href="<?php echo esc_url($saas_team_m['team_gburl']); ?>" class="globe"><i class="fas fa-globe"></i></a></li>
		                                                    <?php endif; ?>
		                                                </ul>
		                                            </div>
		                                        </div>
		                                    </div>
		                                    <div class="team-content">
		                                        <a href="<?php the_permalink(); ?>">
		                                        	<h5 class="member-name"><?php the_title(); ?></h5>
		                                        </a>
		                                        <span class="member-dagi">
		                                        <?php 
												if(!empty($saas_team_m['position'])):
											 		echo esc_html($saas_team_m['position']); 
												endif;
												?>
		                                        </span>
		                                        <p class="member-details">
		                                        	<?php
														$trimexcerpt = get_the_excerpt();
														$shortexcerpt = wp_trim_words( $trimexcerpt, $num_words = 14, $more = '.' );
														echo esc_html($shortexcerpt); 
													?>
		                                        </p>
		                                        <ul class="icon-style-list">
		                                            <li><i class="icofont-phone"></i><span><?php if(!empty($saas_team_m['team_number'])): echo esc_html($saas_team_m['team_number']); endif; ?></span></li>
		                                            <li><i class="icofont-envelope"></i><span><?php if(!empty($saas_team_m['team_mail'])): echo esc_html($saas_team_m['team_mail']); endif; ?></span></li>
		                                            <li></li>
		                                        </ul>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                        <?php 
								endwhile;
								wp_reset_query(); 
								endif; 
								?>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</div>
	<!-- Team Member Section Ending here -->
	<?php
		
	}



}





