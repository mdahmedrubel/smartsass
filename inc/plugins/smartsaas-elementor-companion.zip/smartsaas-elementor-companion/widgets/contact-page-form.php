<?php
class Smartsass_Contact_Form extends \Elementor\Widget_Base {
	public function get_name() {
		return "Contact_Forms";
	}

	public function get_title() {
		return __( "Contact Form", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Contact Page Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'main_contact',[
				'label' => __( 'Vpn Faqs Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [
                    [
                        'name' => 'contact_title',
                        'label' => esc_html__('Contact Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'contact_pone',
                        'label' => esc_html__('Content Part One', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'contact_ptwo',
                        'label' => esc_html__('Contact Part Two', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'contact_icon',
                        'label' => esc_html__('Contact Small Image', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                    ],
                ],
                
			]
		);
	    $this->add_control(
			'contact_shortcode',[
				'label' => __( 'Contact Short Code', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$main_contact = $this->get_settings('main_contact');
	?>
	<!-- Contact -->
	<section class="contact-us padding-tb">
		<div class="container">
			<div class="row">
			    <div class="col-lg-4 col-md-6 col-12">
			        <ul class="contact-area">
			        	<?php  
			        	if(!empty($main_contact)):
			        	foreach ($main_contact as $main_co):
			        	?>
			            <li class="contact-item">
			                <div class="contact-icon">
					            <?php if(!empty($main_co['contact_icon']['url'])): ?>
		                        	<img src="<?php echo wp_kses_post($main_co['contact_icon']['url']); ?>" alt="<?php bloginfo('name'); ?>">
		                		<?php endif; ?>
			                </div>
			                <div class="content">
			                    <h6><?php if(!empty($main_co['contact_title'])): echo esc_html($main_co['contact_title']); endif; ?></h6>
			                    <p><?php if(!empty($main_co['contact_pone'])): echo esc_html($main_co['contact_pone']); endif; ?> <br> <?php if(!empty($main_co['contact_ptwo'])): echo esc_html($main_co['contact_ptwo']); endif; ?></p>
			                </div>
			            </li>
			            <?php  
			        	endforeach;
			        	endif;
			            ?>
			        </ul>
			    </div>
			    <div class="col-lg-8 col-md-6 col-xs-12">
			        <div class="contact-form">
			        	<?php  
			        	if(!empty($settings['contact_shortcode'])):
			        		echo do_shortcode($settings['contact_shortcode']);
			        	endif;
			        	?>
			        </div>
			    </div>
			</div>
		</div>
	</section>
	<!-- Contact -->
	<?php
	}


}





