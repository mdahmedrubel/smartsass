<?php
class Smartsass_What_Is_Crypto extends \Elementor\Widget_Base {
	public function get_name() {
		return "what_iscrypto";
	}

	public function get_title() {
		return __( "What Is Crypto", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'What Is Crypto Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'crypto_img',[
				'label' => __( 'Crypto Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$this->add_control(
			'billiont',[
				'label' => __( 'Billion Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'invest_money',[
				'label' => __( 'Invest Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'billiont2',[
				'label' => __( 'Billion Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'sold_text',[
				'label' => __( 'Sold Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypt_rtitle',[
				'label' => __( 'Right Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypt_rdesc',[
				'label' => __( 'Right Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypt_btn1',[
				'label' => __( 'Crypto Button One', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypt_btnurl1',[
				'label' => __( 'Crypto Button One Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypt_btn2',[
				'label' => __( 'Crypto Button Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypt_btnurl2',[
				'label' => __( 'Crypto Button Two Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypt_title2',[
				'label' => __( 'Crypto Group Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);

		$this->add_control(
			'cryptos',[
				'label' => __( 'Crypto Group Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [
                    [
                        'name' => 'crypt_group',
                        'label' => esc_html__('Faqs Content', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$cryptos = $this->get_settings('cryptos');
	?>
	<!-- About Section Start Here -->
	<section class="about-section style-6 crypto-bg padding-tb pb-0">
	    <div class="lines">
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	    </div>
	    <div class="container">
	        <div class="row">
	            <div class="col-lg-6 col-12">
	                <div class="abl-part">
	                    <div class="about-thumb">
	                        <?php if(!empty($settings['crypto_img']['url'])): ?>
	                        	<img src="<?php echo wp_kses_post($settings['crypto_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
	                		<?php endif; ?>
	                    </div>
	                    <div class="about-contents">
	                        <div class="ab-item">
	                            <div class="ab-inner">
	                                <div class="ab-content">
	                                    <h2><?php if(!empty($settings['billiont'])): echo esc_html($settings['billiont']); endif; ?></h2>
	                                    <p><?php if(!empty($settings['invest_money'])): echo esc_html($settings['invest_money']); endif; ?></p>
	                                </div>
	                            </div>
	                        </div>
	                        <div class="ab-item">
	                            <div class="ab-inner">
	                                <div class="ab-content">
	                                    <h2><?php if(!empty($settings['billiont2'])): echo esc_html($settings['billiont2']); endif; ?></h2>
	                                    <p><?php if(!empty($settings['sold_text'])): echo esc_html($settings['sold_text']); endif; ?></p>
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	            </div>
	            <div class="col-lg-6 col-12">
	                <div class="abr-part">
	                    <div class="section-header style-2">
	                        <h2><?php if(!empty($settings['crypt_rtitle'])): echo esc_html($settings['crypt_rtitle']); endif; ?></h2>
	                        <p><?php if(!empty($settings['crypt_rdesc'])): echo esc_html($settings['crypt_rdesc']); endif; ?></p>
	                        <div class="btn-group">
	                        	<?php  if(!empty($settings['crypt_btn1'])): ?>
	                            	<a href="<?php echo esc_url($settings['crypt_btnurl1']); ?>" class="lab-btn"><span><?php echo esc_html($settings['crypt_btn1']);?></span></a>
	                        	<?php endif; ?>
	                        	<?php  if(!empty($settings['crypt_btn2'])): ?>
	                            <a href="<?php echo esc_url($settings['crypt_btnurl2']); ?>" class="lab-btn"><span><?php echo esc_html($settings['crypt_btn2']);?></span></a>
	                        	<?php endif; ?>
	                        </div>
	                    </div>
	                    <div class="section-wrapper">
	                        <h4><?php if(!empty($settings['crypt_title2'])): echo esc_html($settings['crypt_title2']); endif; ?></h4>
	                        <ul>
	                        	<?php 
				            	if(!empty($cryptos)):
				            	foreach($cryptos as $crypto):
				            	?>
	                            <li>
	                                <div class="left"><span><i class="icofont-tick-mark"></i></span></div>
	                                <div class="right">
	                                    <p><?php if(!empty($crypto['crypt_group'])): echo esc_html($crypto['crypt_group']); endif; ?></p>
	                                </div>
	                            </li>
	                            <?php 
				            	endforeach;
				            	endif;
				                ?>
	                        </ul>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</section>
	<!-- About Section Ending Here -->
	<?php
	}



}





