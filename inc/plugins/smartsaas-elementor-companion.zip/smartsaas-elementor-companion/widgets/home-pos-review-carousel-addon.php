<?php
class Smartsass_Pos_Review_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "pos_review";
	}

	public function get_title() { 
		return __( "Pos Client Testimonial", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Pos Testimonial Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'pos_revtitle',[
				'label' => __( 'Testimonial Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'pos_revdesc',[
				'label' => __( 'Testimonial Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		//Pos testimonial settings 
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'pclient_img',[
				'label' => __( 'Client Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'pclient_name',[
				'label' => __( 'Client Name', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'pclient_position',[
				'label' => __( 'Client Position', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'pclient_logo',[
				'label' => __( 'Client Logo', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$repeater->add_control(
			'pclient_review',[
				'label' => __( 'Client Review Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$repeater->add_control(
				'pos_rating',[
				'label' => __( 'Select Ratings', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'ratings55',
				'label_block' => true,
				'options' => [
					'ratings11'  => __( 'One Star', 'smartsaas' ),
					'ratings22'  => __( 'Two Star', 'smartsaas' ),
					'ratings33'  => __( 'Three Star', 'smartsaas' ),
					'ratings44'  => __( 'Four Star', 'smartsaas' ),
					'ratings55'  => __( 'Five Star', 'smartsaas' ),
				],
			]
		);	
		$this->add_control(
			'pos_testis',
			[
				'label' => __( 'Pos Testimonial Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$pos_testis = $this->get_settings('pos_testis');
	?>
	<section class="testimonial-section padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['pos_revtitle'])): echo esc_html($settings['pos_revtitle']); endif; ?></h2>
				<p><?php if(!empty($settings['pos_revdesc'])): echo esc_html($settings['pos_revdesc']); endif; ?></p>
	        </div>
	        <div class="testimonial-slider">
	            <div class="swiper-wrapper">
	            	<?php
					if(!empty($pos_testis)): 
					foreach($pos_testis as $pos_testi):
					?>
	                <div class="swiper-slide">
	                    <div class="testi-item">
	                        <div class="testi-inner">
	                            <div class="testi-header">
	                                <div class="testi-thumb">
	                                	<div class="testi-shape"></div>
	                                   <?php if(!empty($pos_testi['pclient_img']['url'])): ?>
											<img src="<?php echo wp_kses_post($pos_testi['pclient_img']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
		                            </div>
	                                <div class="testi-content">
	                                    <h5><?php if(!empty($pos_testi['pclient_name'])): echo esc_html($pos_testi['pclient_name']); endif; ?></h5>
	                                    <p><?php if(!empty($pos_testi['pclient_position'])): echo esc_html($pos_testi['pclient_position']); endif; ?></p>
	                                </div>
	                                <div class="sponsor-thumb">
	                                    <?php if(!empty($pos_testi['pclient_logo']['url'])): ?>
											<img src="<?php echo wp_kses_post($pos_testi['pclient_logo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
	                                </div>
	                            </div>
	                            <div class="testi-body">
	                                <p><?php if(!empty($pos_testi['pclient_review'])): echo esc_html($pos_testi['pclient_review']); endif; ?></p>
	                                <div class="rating">
	                                    <?php if($pos_testi['pos_rating'] == 'ratings11'): ?>
											<i class="icofont-star"></i>
										<?php endif; ?>
										<?php if($pos_testi['pos_rating'] == 'ratings22'): ?>
											<i class="icofont-star"></i><i class="icofont-star"></i>
										<?php endif; ?>
										<?php if($pos_testi['pos_rating'] == 'ratings33'): ?>
											<i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i>
										<?php endif; ?>
										<?php if($pos_testi['pos_rating'] == 'ratings44'): ?>
											<i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i>
										<?php endif; ?>
										<?php if($pos_testi['pos_rating'] == 'ratings55'): ?>
											<i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i>
										<?php endif; ?>
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <?php 
					endforeach;
					endif;
					?>
	            </div>
	        </div>
	    </div>
	</section>
	<?php
		
	}



}





