<?php
class Smartsass_Invest_Cripto_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "invest_cripto";
	}

	public function get_title() { 
		return __( "Invest In Cripto", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Invest Cripto Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'inv_title',[
				'label' => __( 'Cripto Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'inv_desc',[
				'label' => __( 'Cripto Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		//Cripto content 
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'inv_img',[
				'label' => __( 'Invest Cripto Imgae', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'inv_number',[
				'label' => __( 'Invest Cripto Number', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'inv_btitle',[
				'label' => __( 'Invest Cripto Box Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'inv_bdesc',[
				'label' => __( 'Invest Cripto Box Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'inv_criptos',
			[
				'label' => __( 'Invest Cripto Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//crypto logos
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'inv_crylogo',[
				'label' => __( 'Invest Cripto Logos', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'inv_logourl',[
				'label' => __( 'Invest Cripto Logo Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,

			]
		);
		$this->add_control(
			'inv_logos',
			[
				'label' => __( 'Invest Cripto Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$inv_criptos = $this->get_settings('inv_criptos');
		$inv_logos = $this->get_settings('inv_logos');
	?>
	<div class="service-sponsor">
    <div class="lines">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
	<!-- Service Section Style 2 Start Here -->
	<section class="service-section style-7 crypto-bg">
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['inv_title'])): echo esc_html($settings['inv_title']); endif; ?></h2>
				<p><?php if(!empty($settings['inv_desc'])): echo esc_html($settings['inv_desc']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	        	<?php 
				if(!empty($inv_criptos)):
				foreach($inv_criptos as $inv_cripto):
				?>
	            <div class="lab-item-2">
	                <div class="lab-inner">
	                	<?php if(!empty($inv_cripto['inv_img']['url'])): ?>
	                    <div class="lab-thumb">
	                        <img src="<?php echo wp_kses_post($inv_cripto['inv_img']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
	                    </div>
	                	<?php endif; ?>
	                    <div class="lab-content">
	                        <h2><?php if(!empty($inv_cripto['inv_number'])): echo esc_html($inv_cripto['inv_number']); endif; ?></h2>
	                        <h4><?php if(!empty($inv_cripto['inv_btitle'])): echo esc_html($inv_cripto['inv_btitle']); endif; ?></h4>
	                        <p><?php if(!empty($inv_cripto['inv_bdesc'])): echo esc_html($inv_cripto['inv_bdesc']); endif; ?></p>
	                    </div>
	                </div>
	            </div>
	            <?php
				endforeach;
				endif; 
				?>
	        </div>
	    </div>
	</section>
	<!-- Service Section Style 2 Ending Here -->


	<!-- Sponsor Section Start Here -->
	<div class="sponsor-section crypto-bg padding-tb">
	    <div class="container">
	        <div class="section-wrapper">
	            <div class="sponsor-slider">
	                <div class="swiper-wrapper">
	                	<?php 
						if(!empty($inv_logos)):
						foreach($inv_logos as $inv_logo):
						?>
	                    <div class="swiper-slide">
	                        <div class="sponsor-item">
	                            <div class="sponsor-thumb">
	                            	<?php if(!empty($inv_logo['inv_crylogo']['url'])): ?>
	                                <a href="<?php echo esc_url($inv_logo['inv_logourl']['url']); ?>">

	                                	<img src="<?php echo wp_kses_post($inv_logo['inv_crylogo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
	                                </a>
	                            	<?php endif; ?>
	                            </div>
	                        </div>
	                    </div>
	                    <?php
						endforeach;
						endif; 
						?>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
	<!-- Sponsor Section Ending Here -->
	</div>
	<?php
		
	}



}





