<?php
class Smartsaas_Home_Pos_Retail_Store extends \Elementor\Widget_Base {
	public function get_name() {
		return "retail_store";
	}

	public function get_title() {
		return __( "Home Pos Store", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Home Pos Store Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'pstore_title',[
				'label' => __( 'Pos Software Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'pstore_desc',[
				'label' => __( 'Pos Software Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Short Content', 'smartsaas' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'retail_stores',[
				'label' => __( 'Pos Retail Store Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [
                    [
                        'name' => 'retail_btitle',
                        'label' => esc_html__('Retail Store Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'retail_bimg',
                        'label' => esc_html__('Retail Box Image', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                    ],
                ],
                
			]
		);


	$this->end_controls_section();

	}



	protected function render() {
		$settings = $this->get_settings_for_display();
	
	?>
	<!-- Service Section Start Here -->
	<section class="service-section style-5 padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['pstore_title'])): echo esc_html($settings['pstore_title']); endif; ?></h2>
				<p><?php if(!empty($settings['pstore_desc'])): echo esc_html($settings['pstore_desc']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	        	<?php 
            	if(!empty($settings['retail_stores'])):
            	foreach($settings['retail_stores'] as $retail_stor):
            	?>
	            <div class="lab-item">
	                <div class="lab-inner">
	                    <div class="lab-thumb">
	                        <?php if(!empty($retail_stor['retail_bimg']['url'])): ?>
	                        	<img src="<?php echo wp_kses_post($retail_stor['retail_bimg']['url']); ?>" alt="<?php bloginfo('name'); ?>">
	                		<?php endif; ?>
	                    </div>
	                    <div class="lab-content">
	                        <h6><?php if(!empty($retail_stor['retail_btitle'])): echo esc_html($retail_stor['retail_btitle']); endif; ?></h6>
	                    </div>
	                </div>
	            </div>
	            <?php 
            	endforeach;
            	endif;
                ?> 
	        </div>
	    </div>
	</section>
	<!-- Service Section Ending Here -->
	<?php
	}



}


