<?php
class Smartsass_Two_Services extends \Elementor\Widget_Base {
	public function get_name() {
		return "two_services";
	}

	public function get_title() {
		return __( "Service Two", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Servicess Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'service2_title',[
				'label' => __( 'Servicess Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'service2_stitle',[
				'label' => __( 'Servicess Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'service2_count',[
				'label' => __( 'Servicess Count', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		

	?>
	<!-- Service Section Start Here -->
	<section class="service-section style-4 padding-tb">
	    <div class="container">
	        <div class="section-header">
            	<h2><?php if(!empty($settings['service2_title'])): echo esc_html($settings['service2_title']); endif; ?></h2> 
				<p><?php if(!empty($settings['service2_stitle'])): echo esc_html($settings['service2_stitle']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	        	<?php  
				$serv_two_q = new WP_Query(
				    array(
				        'post_type'       => 'service',
				        'post_status'     => 'publish',
				        'posts_per_page' => $settings['service2_count'],
				        'order'       => 'DESC',
				        'orderby'       => 'name',
				    )
				);

				if ( $serv_two_q->have_posts() ) :
				while ( $serv_two_q->have_posts() ):
	    		$serv_two_q->the_post();

	    		$two_sr = get_post_meta(get_the_ID(), 'saas_service', true);
	    		if(isset($two_sr['icon_service2']['id'])){	
	    			$ser2_icon =  wp_get_attachment_image_src($two_sr['icon_service2']['id'], 'large');	
	    		}
				?>
	            <div class="lab-item">
	                <div class="lab-inner">
	                    <div class="lab-thumb">
	                    	<?php if(!empty($ser2_icon[0])): ?>
	                        	<img src="<?php echo esc_url($ser2_icon[0]); ?>" alt="<?php bloginfo('name'); ?>">
	                    	<?php endif; ?>
	                    </div>
	                    <div class="lab-content myclass">
	                        <a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
	                        <p>
	                        	<?php 
					                $xcerpt = get_the_excerpt();
									$shortexcerpt = wp_trim_words($xcerpt, $num_words = 16, ' ');
									echo esc_html($shortexcerpt);
				                ?>
	                        </p>
	                    </div>
	                </div>
	            </div>
	            <?php 
				endwhile;
				wp_reset_query();  
				endif;
				?>
	        </div>
	    </div>
	</section>
	<!-- Service Section Ending Here -->
	<?php
	}



}





