<?php
class Smartsass_Seo_Services extends \Elementor\Widget_Base {
	public function get_name() {
		return "seo_services";
	}

	public function get_title() {
		return __( "Service Section", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Servicess Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'choose_service',[
				'label' => __( 'Select Service Style', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'seo-service',
				'options' => [
					'seo-service'  => __( 'Seo Service', 'smartsaas' ),
					'host-service' => __( 'Host Service', 'smartsaas' ),

				],
			]
		);

		//seo page service control
		$this->add_control(
			'seoservice_title',[
				'label' => __( 'Servicess Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'seo-service',
						]
					]
				]

			]
		);
		$this->add_control(
			'seoservice_stitle',[
				'label' => __( 'Servicess Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'seo-service',
						]
					]
				]

			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'service_icon',[
				'label' => __( 'Service Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'service_titl',[
				'label' => __( 'Service Box Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'service_desc',[
				'label' => __( 'Service Box Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'service_rshape',[
				'label' => __( 'Service Box Right Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$this->add_control(
			'service_boxs',
			[
				'label' => __( 'Seo Service Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'seo-service',
						]
					]
				]
			]
		);

		//host service section
		$this->add_control(
			'hseoservice_title',[
				'label' => __( 'Servicess Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'host-service',
						]
					]
				]

			]
		);
		$this->add_control(
			'hseoservice_stitle',[
				'label' => __( 'Servicess Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'host-service',
						]
					]
				]

			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'hservice_icon',[
				'label' => __( 'Service Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'hservice_titl',[
				'label' => __( 'Service Box Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'hservice_desc',[
				'label' => __( 'Service Box Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'hservice_rshape',[
				'label' => __( 'Service Box Right Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$this->add_control(
			'hservice_boxs',
			[
				'label' => __( 'Host Service Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_service',
							'operator'  => '==',
							'value'  => 'host-service',
						]
					]
				]
			]
		);
		

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$service_boxs = $this->get_settings('service_boxs');
		$choose_service = $this->get_settings('choose_service');
		$hservice_boxs = $this->get_settings('hservice_boxs');
	?>
	<?php if($choose_service == 'seo-service'): ?>
	<!-- Service Section Style 2 Start Here -->
	<section class="service-section style-2 seo padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['seoservice_title'])): echo esc_html($settings['seoservice_title']); endif; ?></h2>
				<p><?php if(!empty($settings['seoservice_stitle'])): echo esc_html($settings['seoservice_stitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<?php 
				if(!empty($service_boxs)):
				foreach($service_boxs as $service_box):
				?>
				<div class="lab-item-2">
					<div class="lab-inner">
							<div class="lab-abs-thumb">
								<?php if(!empty($service_box['service_rshape']['url'])): ?>
									<img src="<?php echo wp_kses_post($service_box['service_rshape']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
							</div>
						<div class="lab-thumb">
							<?php if(!empty($service_box['service_icon']['url'])): ?>
								<img src="<?php echo wp_kses_post($service_box['service_icon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
						<div class="lab-content">
							<h4><?php if(!empty($service_box['service_titl'])): echo esc_html($service_box['service_titl']); endif; ?></h4>
							<p><?php if(!empty($service_box['service_desc'])): echo esc_html($service_box['service_desc']); endif; ?></p>
						</div>
					</div>
				</div>
				<?php
				endforeach;
				endif; 
				?>
			</div>
		</div>
	</section>
	<!-- Service Section Style 2 Ending Here -->
	<?php elseif($choose_service == 'host-service'): ?>
	<!-- Service Section Style 2 Start Here -->
	<section class="service-section style-3 padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['hseoservice_title'])): echo esc_html($settings['hseoservice_title']); endif; ?></h2>
				<p><?php if(!empty($settings['hseoservice_stitle'])): echo esc_html($settings['hseoservice_stitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<?php 
				if(!empty($hservice_boxs)):
				foreach($hservice_boxs as $hservice_box):
				?>
				<div class="lab-item-2">
					<div class="lab-inner">
							<div class="lab-abs-thumb">
								<?php if(!empty($hservice_box['hservice_rshape']['url'])): ?>
									<img src="<?php echo wp_kses_post($hservice_box['hservice_rshape']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
							</div>
						<div class="lab-thumb">
							<?php if(!empty($hservice_box['hservice_icon']['url'])): ?>
								<img src="<?php echo wp_kses_post($hservice_box['hservice_icon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
						<div class="lab-content">
							<h4><?php if(!empty($hservice_box['hservice_titl'])): echo esc_html($hservice_box['hservice_titl']); endif; ?></h4>
							<p><?php if(!empty($hservice_box['hservice_desc'])): echo esc_html($hservice_box['hservice_desc']); endif; ?></p>
						</div>
					</div>
				</div>
				<?php 
				endforeach;
				endif;
				?>
			</div>
		</div>
	</section>
	<!-- Service Section Style 2 Ending Here -->

	<?php
	endif;
	}



}





