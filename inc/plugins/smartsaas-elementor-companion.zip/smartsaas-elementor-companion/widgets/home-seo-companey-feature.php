<?php
class Smartsass_Companey_Feature extends \Elementor\Widget_Base {
	public function get_name() {
		return "companey_feature";
	}

	public function get_title() {
		return __( "Companey Features", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Companey Feature Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'choose_feature',[
				'label' => __( 'Select Feature style', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'seo-feature',
				'options' => [
					'seo-feature'  => __( 'Home Seo Feature', 'smartsaas' ),
					'host-feature' => __( 'Home Host Feature', 'smartsaas' ),
					'erp-feature' => __( 'Home Erp Feature', 'smartsaas' ),
					'pos-feature' => __( 'Home Pos Feature', 'smartsaas' ),
				],
			]
		);
		//SEO feature section
		$this->add_control(
			'seo_feature_title',[
				'label' => __( 'Feature Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'seo-feature',
						]
					]
				]

			]
		);
		$this->add_control(
			'seo_feature_stitle',[
				'label' => __( 'Feature Short Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'seo-feature',
						]
					]
				]

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'seo_f_icon',[
				'label' => __( 'Add Feature Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'feature_titel',[
				'label' => __( 'Feature Box Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'feature_desc',[
				'label' => __( 'Feature Box Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'seo_features',
			[
				'label' => __( 'Seo Features Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'seo-feature',
						]
					]
				]
			]
		);

		//host feature section
		$this->add_control(
			'host_feature_title',[
				'label' => __( 'Feature Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'host-feature',
						]
					]
				]

			]
		);

		$this->add_control(
			'host_feature_stitle',[
				'label' => __( 'Feature Short Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'host-feature',
						]
					]
				]

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'host_f_icon',[
				'label' => __( 'Add Feature Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'hfeature_titel',[
				'label' => __( 'Feature Box Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'hfeature_desc',[
				'label' => __( 'Feature Box Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'hosts_features',
			[
				'label' => __( 'Host Features Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'host-feature',
						]
					]
				]
			]
		);
		
		//erp feature section controls
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'erp_f_icon',[
				'label' => __( 'Add Feature Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'erpfeature_titel',[
				'label' => __( 'Feature Box Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'erpfeture_desc',[
				'label' => __( 'Feature Box Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'erps_features',
			[
				'label' => __( 'Host Features Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'erp-feature',
						]
					]
				]
			]
		);

		//POS feature section
		$this->add_control(
			'pos_feature_title',[
				'label' => __( 'Feature Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'pos-feature',
						]
					]
				]

			]
		);
		$this->add_control(
			'pos_feature_stitle',[
				'label' => __( 'Feature Short Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'pos-feature',
						]
					]
				]

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'pos_f_icon',[
				'label' => __( 'Add Feature Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'posfeature_titel',[
				'label' => __( 'Feature Box Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'posfeature_desc',[
				'label' => __( 'Feature Box Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'pos_features',
			[
				'label' => __( 'Pos Features Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_feature',
							'operator'  => '==',
							'value'  => 'pos-feature',
						]
					]
				]
			]
		);
		

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$seo_features = $this->get_settings('seo_features');
		$hosts_features = $this->get_settings('hosts_features');
		$erps_features = $this->get_settings('erps_features');
		$pos_features = $this->get_settings('pos_features');
		$choose_feature = $this->get_settings('choose_feature');
	?>
	<?php if($choose_feature == 'seo-feature'): ?>
	<section class="service-section padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['seo_feature_title'])): echo esc_html($settings['seo_feature_title']); endif; ?></h2>
				<p><?php if(!empty($settings['seo_feature_stitle'])): echo esc_html($settings['seo_feature_stitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<?php 
				if(!empty($seo_features)):
				foreach($seo_features as $seo_feature):
				?>
				<div class="lab-item">
					<div class="lab-inner">
						<div class="lab-thumb">
							<?php if(!empty($seo_feature['seo_f_icon']['url'])): ?>
								<img src="<?php echo wp_kses_post($seo_feature['seo_f_icon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
						<div class="lab-content">
							<h4><?php if(!empty($seo_feature['feature_titel'])): echo esc_html($seo_feature['feature_titel']); endif; ?></h4>
							<p><?php if(!empty($seo_feature['feature_desc'])): echo esc_html($seo_feature['feature_desc']); endif; ?></p>
						</div>
					</div>
				</div>
				<?php
				endforeach;
				endif; 
				?>
			</div>
		</div>
	</section>
	<?php elseif($choose_feature == 'host-feature'): ?>
	<section class="service-section style-2 padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['host_feature_title'])): echo esc_html($settings['host_feature_title']); endif; ?></h2>
				<p><?php if(!empty($settings['host_feature_stitle'])): echo esc_html($settings['host_feature_stitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<?php 
				if(!empty($hosts_features)):
				foreach($hosts_features as $hosts_feature):
				?>
				<div class="lab-item">
					<div class="lab-inner">
						<div class="lab-thumb">
							<?php if(!empty($hosts_feature['host_f_icon']['url'])): ?>
								<img src="<?php echo wp_kses_post($hosts_feature['host_f_icon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
						<div class="lab-content">
							<h4><?php if(!empty($hosts_feature['hfeature_titel'])): echo esc_html($hosts_feature['hfeature_titel']); endif; ?></h4>
							<p><?php if(!empty($hosts_feature['hfeature_desc'])): echo esc_html($hosts_feature['hfeature_desc']); endif; ?></p>
						</div>
					</div>
				</div>
				<?php
				endforeach;
				endif; 
				?>
			</div>
		</div>
	</section>
	<?php elseif($choose_feature == 'erp-feature'): ?>
	<section class="about-section erp-about style-2 padding-tb">
		<div class="container">
			<div class="section-wrapper">
				<?php 
				if(!empty($erps_features)):
				foreach($erps_features as $erps_feature):
				?>
	            <div class="lab-item">
	                <div class="lab-inner">
	                    <div class="lab-thumb">
	                        <?php if(!empty($erps_feature['erp_f_icon']['url'])): ?>
								<img src="<?php echo wp_kses_post($erps_feature['erp_f_icon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
	                    </div>
	                    <div class="lab-content">
	                        <h4><?php if(!empty($erps_feature['erpfeature_titel'])): echo esc_html($erps_feature['erpfeature_titel']); endif; ?></h4>
							<p><?php if(!empty($erps_feature['erpfeture_desc'])): echo esc_html($erps_feature['erpfeture_desc']); endif; ?></p>
	                    </div>
	                </div>
	            </div>
	            <?php
				endforeach;
				endif; 
				?>
	        </div>
		</div>
	</section>
	<?php elseif($choose_feature == 'pos-feature'): ?>
	<section class="about-section style-2 style-3 padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['pos_feature_title'])): echo esc_html($settings['pos_feature_title']); endif; ?></h2>
				<p><?php if(!empty($settings['pos_feature_stitle'])): echo esc_html($settings['pos_feature_stitle']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	        	<?php 
				if(!empty($pos_features)):
				foreach($pos_features as $pos_feature):
				?>
	            <div class="lab-item">
	                <div class="lab-inner">
	                    <div class="lab-thumb">
	                        <?php if(!empty($pos_feature['pos_f_icon']['url'])): ?>
								<img src="<?php echo wp_kses_post($pos_feature['pos_f_icon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
	                    </div>
	                    <div class="lab-content">
	                        <h4><?php if(!empty($pos_feature['posfeature_titel'])): echo esc_html($pos_feature['posfeature_titel']); endif; ?></h4>
	                        <p><?php if(!empty($pos_feature['posfeature_desc'])): echo esc_html($pos_feature['posfeature_desc']); endif; ?></p>
	                    </div>
	                </div>
	            </div>
	            <?php
				endforeach;
				endif; 
				?>
	        </div>
	    </div>
	</section>
	<?php
	endif;
	}



}





