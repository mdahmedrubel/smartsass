<?php
class Smartsass_Footer_Erp_Author_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "footer_author";
	}

	public function get_title() {
		return __( "Erp Footer Author", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Erp Author Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'author_img',[
				'label' => __( 'Author Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'author_title',[
				'label' => __( 'Author Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Newsletter Background', 'smartsaas' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .author-area',
			]
		);
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

	?>
	<!-- Author Level Section Start Here -->
	<div class="author padding-tb pb-0">
		<div class="container">
			<div class="section-wrapper">
				<div class="author-area">
					<div class="lab-thumb">
						<?php if(!empty($settings['author_img']['url'])): ?>
							<img src="<?php echo wp_kses_post($settings['author_img']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
						<?php endif; ?>
					</div>
					<div class="lab-content">
						<p><?php if(!empty($settings['author_title'])): echo esc_html($settings['author_title']); endif; ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Author Level Section Start Here -->
	<?php
		
	}



}





