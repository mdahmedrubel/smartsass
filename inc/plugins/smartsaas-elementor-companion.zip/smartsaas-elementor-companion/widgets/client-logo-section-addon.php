<?php
class Smartsass_Logo_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "host_client_logo";
	}

	public function get_title() { 
		return __( "Client Logo", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Client Logo Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'client_ltitle',[
				'label' => __( 'Client Logo Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'client_lstitle',[
				'label' => __( 'Client Logo Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		//list one logo 
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'sponsor_logo',[
				'label' => __( 'Client Logo', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'sponsor_logourl',[
				'label' => __( 'Client Logo Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,

			]
		);
		$this->add_control(
			'sponsor_logos',
			[
				'label' => __( 'Client Logo One', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//list two logo 
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'sponsors2_logo',[
				'label' => __( 'Client Logo', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'sponsor2_logourl',[
				'label' => __( 'Client Logo Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,

			]
		);
		$this->add_control(
			'sponsor2_logos',
			[
				'label' => __( 'Client Logo Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//list three logo 
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'sponsors3_logo',[
				'label' => __( 'Client Logo', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'sponsor3_logourl',[
				'label' => __( 'Client Logo Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,

			]
		);
		$this->add_control(
			'sponsor3_logos',
			[
				'label' => __( 'Client Logo Three', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$sponsor_logos = $this->get_settings('sponsor_logos');
		$sponsor2_logos = $this->get_settings('sponsor2_logos');
		$sponsor3_logos = $this->get_settings('sponsor3_logos');
	?>
	<!-- Sponsor Section Start Here -->
	<div class="sponsor-section style-2 padding-tb">
		<div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['client_ltitle'])): echo esc_html($settings['client_ltitle']); endif; ?></h2>
				<p><?php if(!empty($settings['client_lstitle'])): echo esc_html($settings['client_lstitle']); endif; ?></p>
	        </div>
			<div class="section-wrapper">
	            <div class="sponsor-list list-one">
	            	<?php 
					if(!empty($sponsor_logos)):
					foreach($sponsor_logos as $sponsor_logo):
					?>
	                <div class="sponsor-item">
	                    <div class="sponsor-thumb">
	                        <?php if(!empty($sponsor_logo['sponsor_logo']['url'])): ?>
							<a href="<?php if(!empty($sponsor_logo['sponsor_logourl']['url'])): echo esc_url($sponsor_logo['sponsor_logourl']['url']); endif; ?>">
								<img src="<?php echo wp_kses_post($sponsor_logo['sponsor_logo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							</a>
							<?php endif; ?>
	                    </div>

	                </div>
	                <?php
					endforeach;
					endif; 
					?>
	            </div>
	            <div class="sponsor-list list-two">
	               <?php 
					if(!empty($sponsor2_logos)):
					foreach($sponsor2_logos as $sponsor2_logo):
					?>
	                <div class="sponsor-item">
	                    <div class="sponsor-thumb">
	                        <?php if(!empty($sponsor2_logo['sponsors2_logo']['url'])): ?>
							<a href="<?php if(!empty($sponsor2_logo['sponsor2_logourl']['url'])): echo esc_url($sponsor2_logo['sponsor2_logourl']['url']); endif; ?>">
								<img src="<?php echo wp_kses_post($sponsor2_logo['sponsors2_logo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							</a>
							<?php endif; ?>
	                    </div>
	                </div>
	                <?php
					endforeach;
					endif; 
					?>
	            </div>
	            <div class="sponsor-list list-three">
	            	<?php 
					if(!empty($sponsor3_logos)):
					foreach($sponsor3_logos as $sponsor3_logo):
					?>
	                <div class="sponsor-item">
	                    <div class="sponsor-thumb">
	                        <?php if(!empty($sponsor3_logo['sponsors3_logo']['url'])): ?>
							<a href="<?php if(!empty($sponsor3_logo['sponsor3_logourl']['url'])): echo esc_url($sponsor3_logo['sponsor3_logourl']['url']); endif; ?>">
								<img src="<?php echo wp_kses_post($sponsor3_logo['sponsors3_logo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							</a>
							<?php endif; ?>
	                    </div>
	                </div>
	                <?php
					endforeach;
					endif; 
					?>
	            </div>
	        </div>
		</div>
	</div>
	<!-- Sponsor Section Ending Here -->
	<?php
		
	}



}





