<?php
class Smartsass_Home_Marketing_Blog extends \Elementor\Widget_Base {
	public function get_name() {
		return "marketing_blog";
	}

	public function get_title() {
		return __( "Marketing App Blog", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Marketing Blog Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'choose_bblog',[
				'label' => __( 'Select Banner', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'home-marketing',
				'options' => [
					'home-marketing'  => __( 'Home Marketing Blog', 'smartsaas' ),
					'home-shopapp' => __( 'Home Shopapp Blog', 'smartsaas' ),
				],
			]
		);
		$this->add_control(
			'mtesti_btitle',[
				'label' => __( 'Marketing Sub Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_bblog',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]

			]
		);
		$this->add_control(
			'mtesti_bstitle',[
				'label' => __( 'Marketing Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_bblog',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]

			]
		);
		$this->add_control(
			'mtesti_bcount',[
				'label' => __( 'Marketing Blog Count', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_bblog',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]

			]
		);

		//style tow
		$this->add_control(
			'mtesti_bcount2',[
				'label' => __( 'Marketing Blog Count', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_bblog',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]

			]
		);


		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$choose_bblog = $this->get_settings('choose_bblog');
	?>
	<?php if($choose_bblog == 'home-marketing'): ?>
    <!-- Blog Section Start Here -->
	<section class="blog-section marketing padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <span><?php if(!empty($settings['mtesti_btitle'])): echo esc_html($settings['mtesti_btitle']); endif; ?></span>
				<h2><?php if(!empty($settings['mtesti_bstitle'])): echo esc_html($settings['mtesti_bstitle']); endif; ?></h2>
	        </div>
	        <div class="section-wrapper">
	            <div class="row justify-content-center">
	            	<?php 
	            	//wp_query for the seo blog post
					$marketing_blog = new WP_Query(
					    array(
					        'post_type'       => 'post',
					        'post_status'     => 'publish',
					        'posts_per_page' => $settings['mtesti_bcount'],
					        'ignore_sticky_posts' => 1
					    )
					);

					while ( $marketing_blog->have_posts() ):
		    		$marketing_blog->the_post();
					?>
	                <div class="col-lg-4 col-sm-6 col-12">
	                    <div class="post-item">
	                        <div class="post-item-inner">
	                            <div class="post-thumb">
	                                <?php
									$mkt_thumb =  get_the_post_thumbnail_url(get_the_ID(),"large"); 
									 if(!empty($mkt_thumb)):
									?>
									<a href="<?php the_permalink(); ?>">
										<img src="<?php echo esc_url($mkt_thumb); ?>" alt="<?php bloginfo('name'); ?>">
									</a>
									<?php endif; ?>
	                            </div>
	                            <div class="post-content">
	                                <h4>
	                                	<a href="<?php the_permalink(); ?>">
											<?php
											$title = get_the_title();
											$short_title = wp_trim_words( $title, 5, ' ...' );
											echo $short_title;
											?>
										</a>
	                                </h4>
	                                <div class="author-date">
	                                    <a href="<?php the_permalink(); ?>" class="date">
	                                    	<i class="icofont-calendar"></i>
		                                    <?php echo get_the_date('F j, Y') ?>
		                                </a>
	                                    <a href="<?php the_permalink(); ?>" class="admin">
	                                    	<i class="icofont-ui-user"></i>
	                                    	<?php echo get_the_author_meta( 'display_name' ); ?>
	                                    </a>
	                                </div>
	                                <p>
	                                <?php 
						                $xcerpt = get_the_excerpt();
										$shortexcerpt = wp_trim_words($xcerpt, $num_words = 18, ' ');
										echo esc_html($shortexcerpt);
					                ?>
	                                </p>
	                                <div class="post-footer">
	                                    <a href="<?php the_permalink(); ?>" class="text-btn"><?php _e("Read More", "smartsaas"); ?><i class="icofont-double-right"></i></a>

	                                    <div class="comments">

	                                    	<i class="icofont-comment"></i>
	                                    	<span>
	                                    		<?php
											  comments_popup_link( '0', '1', '%', 'comments-link', 'off');
											?>
	                                    	</span>

	                                    </div>

	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <?php 
					endwhile;
					wp_reset_query();  
					?>

	            </div>
	        </div>
	    </div>
	</section>
	<?php elseif($choose_bblog == 'home-shopapp'): ?>
	<section class="blog-section marketing padding-tb">
	    <div class="container">
	        <div class="section-wrapper">
	            <div class="row justify-content-center">
	            	<?php 
	            	//wp_query for the seo blog post
					$marketing_blog = new WP_Query(
					    array(
					        'post_type'       => 'post',
					        'post_status'     => 'publish',
					        'posts_per_page' => $settings['mtesti_bcount2'],
					        'ignore_sticky_posts' => 1
					    )
					);

					while ( $marketing_blog->have_posts() ):
		    		$marketing_blog->the_post();
					?>
	                <div class="col-lg-4 col-sm-6 col-12">
	                    <div class="post-item">
	                        <div class="post-item-inner">
	                            <div class="post-thumb">
	                                <?php
									$mkt_thumb =  get_the_post_thumbnail_url(get_the_ID(),"large"); 
									 if(!empty($mkt_thumb)):
									?>
									<a href="<?php the_permalink(); ?>">
										<img src="<?php echo esc_url($mkt_thumb); ?>" alt="<?php bloginfo('name'); ?>">
									</a>
									<?php endif; ?>
	                            </div>
	                            <div class="post-content">
	                                <h4>
	                                	<a href="<?php the_permalink(); ?>">
											<?php
											$title = get_the_title();
											$short_title = wp_trim_words( $title, 5, ' ...' );
											echo $short_title;
											?>
										</a>
	                                </h4>
	                                <div class="author-date">
	                                    <a href="<?php the_permalink(); ?>" class="date">
	                                    	<i class="icofont-calendar"></i>
		                                    <?php echo get_the_date('F j, Y') ?>
		                                </a>
	                                    <a href="<?php the_permalink(); ?>" class="admin">
	                                    	<i class="icofont-ui-user"></i>
	                                    	<?php echo get_the_author_meta( 'display_name' ); ?>
	                                    </a>
	                                </div>
	                                <p>
	                                <?php 
						                $xcerpt = get_the_excerpt();
										$shortexcerpt = wp_trim_words($xcerpt, $num_words = 18, ' ');
										echo esc_html($shortexcerpt);
					                ?>
	                                </p>
	                                <div class="post-footer">
	                                    <a href="<?php the_permalink(); ?>" class="text-btn"><?php _e("Read More", "smartsaas"); ?><i class="icofont-double-right"></i></a>

	                                    <div class="comments">

	                                    	<i class="icofont-comment"></i>
	                                    	<span>
	                                    		<?php
											  comments_popup_link( '0', '1', '%', 'comments-link', 'off');
											?>
	                                    	</span>

	                                    </div>

	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <?php 
					endwhile;
					wp_reset_query();  
					?>

	            </div>
	        </div>
	    </div>
	</section>
	<!-- Blog Section Ending Here -->
	<?php
	endif;
	}



}





