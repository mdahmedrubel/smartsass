<?php
class Smartsass_How_Crypto_works extends \Elementor\Widget_Base {
	public function get_name() {
		return "how_ctypto_work";
	}

	public function get_title() { 
		return __( "How Crypto Works", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'How Crypto Works Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'how_crpwork',[
				'label' => __( 'How Crypto Works Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'how_crpdesc',[
				'label' => __( 'How Crypto Works Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'how_crpimg',[
				'label' => __( 'How Crypto Works Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);


		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'how_crpbicon',[
				'label' => __( 'How Crypto Works Box Icon ', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'how_crpbtitle',[
				'label' => __( 'How Crypto Works Box Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'how_crpbdesc',[
				'label' => __( 'How Crypto Works Box Short Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'how_workscrp',
			[
				'label' => __( 'How Crypto Works Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$how_workscrp = $this->get_settings('how_workscrp');
	?>
	<!-- Servise Section Stert Here -->
	<section class="service-section style-8 crypto-bg padding-tb">
	    <div class="lines">
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	    </div>
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['how_crpwork'])): echo esc_html($settings['how_crpwork']); endif; ?></h2>
				<p><?php if(!empty($settings['how_crpdesc'])): echo esc_html($settings['how_crpdesc']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	        	<?php if(!empty($settings['how_crpimg']['url'])): ?>
	            <div class="abs-thumb">
	                <img src="<?php echo wp_kses_post($settings['how_crpimg']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
	            </div>
	        	<?php endif; ?>
	            <div class="service-content">
	                <ul class="abs-items">
	                	<?php 
						if(!empty($how_workscrp)):
						foreach($how_workscrp as $how_workscr):
						?>
	                    <li>
	                        <div class="abs-item">
	                            <div class="left">
	                                <div class="lb-thumb">
	                                    <img src="<?php echo wp_kses_post($how_workscr['how_crpbicon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
	                                </div>
	                            </div>
	                            <div class="right">
	                                <h4><?php if(!empty($how_workscr['how_crpbtitle'])): echo esc_html($how_workscr['how_crpbtitle']); endif; ?></h4>
									<p><?php if(!empty($how_workscr['how_crpbdesc'])): echo esc_html($how_workscr['how_crpbdesc']); endif; ?></p>
	                            </div>
	                        </div>
	                    </li>
	                    <?php
						endforeach;
						endif; 
						?>
	                </ul>
	            </div>
	        </div>
	    </div>
	</section>
	<!-- Servise Section Ending Here -->
	<?php
		
	}



}





