<?php
class Smartsass_Cripto_Waller_Cole_Storage extends \Elementor\Widget_Base {
	public function get_name() {
		return "crp_cole_storage";
	}

	public function get_title() { 
		return __( "Crypto Cold Storage", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Cold Storage Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'cold_imgs',[
				'label' => __( 'Cold Storage Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cold_simgs',[
				'label' => __( 'Cold Storage Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cold_title',[
				'label' => __( 'Cold Storage Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cold_cont',[
				'label' => __( 'Cold Storage Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'cold_servc',[
				'label' => __( 'Colde Cervice', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'could_groups',
			[
				'label' => __( 'Cold Cripto Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);


		//cold storage two style
		$this->add_control(
			'cold_imgs2',[
				'label' => __( 'Cold Storage Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cold_simgs2',[
				'label' => __( 'Cold Storage Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cold_title2',[
				'label' => __( 'Cold Storage Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cold_cont2',[
				'label' => __( 'Cold Storage Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'cold_servc2',[
				'label' => __( 'Colde Cervice', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'could_groups2',
			[
				'label' => __( 'Cold Cripto Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		//cold storage three style
		$this->add_control(
			'cold_imgs3',[
				'label' => __( 'Cold Storage Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cold_simgs3',[
				'label' => __( 'Cold Storage Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cold_title3',[
				'label' => __( 'Cold Storage Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cold_cont3',[
				'label' => __( 'Cold Storage Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'cold_servc3',[
				'label' => __( 'Colde Cervice', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'could_groups3',
			[
				'label' => __( 'Cold Cripto Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$could_groups = $this->get_settings('could_groups');
		$could_groups2 = $this->get_settings('could_groups2');
		$could_groups3 = $this->get_settings('could_groups3');
	?>
	<section class="about-section style-7 crypto-bg padding-tb pb-0">
        <div class="lines">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-12">
                    <div class="abl-part">
                    	<?php if(!empty($settings['cold_imgs']['url'])): ?>
                        <div class="about-thumb">
                            <img src="<?php echo wp_kses_post($settings['cold_imgs']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
                        </div>
                    	<?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="abr-part">
                        <div class="section-header style-2 mb-0">
                            <div class="abs-lab-thumb pink">
                                <span class="pluse_1"></span>
                                <span class="pluse_2"></span>
                                <?php if(!empty($settings['cold_simgs']['url'])): ?>
                                	<img src="<?php echo wp_kses_post($settings['cold_simgs']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
                            	<?php endif; ?>
                            </div>
                            <h2><?php if(!empty($settings['cold_title'])): echo esc_html($settings['cold_title']); endif; ?></h2>
							<p><?php if(!empty($settings['cold_cont'])): echo esc_html($settings['cold_cont']); endif; ?></p>
                            <ul>
                            	<?php 
								if(!empty($could_groups)):
								foreach($could_groups as $could_group):
								?>
                                <li>
                                    <div class="left"><span><i class="icofont-tick-mark"></i></span></div>
                                    <div class="right">
                                        <p><?php if(!empty($could_group['cold_servc'])): echo esc_html($could_group['cold_servc']); endif; ?></p>
                                    </div>
                                </li>
                                <?php
								endforeach;
								endif; 
								?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="about-section style-7 crypto-bg padding-tb pb-0">
	    <div class="lines">
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	    </div>
	    <div class="container">
	        <div class="row flex-row-reverse align-items-center">
	            <div class="col-lg-6 col-12">
	                <div class="abl-part">
	                    <?php if(!empty($settings['cold_imgs2']['url'])): ?>
                        <div class="about-thumb">
                            <img src="<?php echo wp_kses_post($settings['cold_imgs2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
                        </div>
                    	<?php endif; ?>
	                </div>
	            </div>
	            <div class="col-lg-6 col-12">
	                <div class="abr-part">
	                    <div class="section-header style-2 mb-0">
	                        <div class="abs-lab-thumb">
	                            <span class="pluse_1"></span>
	                            <span class="pluse_2"></span>
	                            <?php if(!empty($settings['cold_simgs2']['url'])): ?>
                                	<img src="<?php echo wp_kses_post($settings['cold_simgs2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
                            	<?php endif; ?>
	                        </div>
	                        <h2><?php if(!empty($settings['cold_title2'])): echo esc_html($settings['cold_title2']); endif; ?></h2>
							<p><?php if(!empty($settings['cold_cont2'])): echo esc_html($settings['cold_cont2']); endif; ?></p>
	                        <ul>
	                        	<?php 
								if(!empty($could_groups2)):
								foreach($could_groups2 as $could_g):
								?>
	                            <li>
	                                <div class="left"><span><i class="icofont-tick-mark"></i></span></div>
	                                <div class="right">
	                                    <p><?php if(!empty($could_g['cold_servc2'])): echo esc_html($could_g['cold_servc2']); endif; ?></p>
	                                </div>
	                            </li>
	                            <?php
								endforeach;
								endif; 
								?>
	                        </ul>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</section> 

	<section class="about-section style-7 crypto-bg padding-tb pb-0">
        <div class="lines">
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
            <div class="line"></div>
        </div>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-12">
                    <div class="abl-part">
                        <?php if(!empty($settings['cold_imgs3']['url'])): ?>
                        <div class="about-thumb">
                            <img src="<?php echo wp_kses_post($settings['cold_imgs3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
                        </div>
                    	<?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="abr-part">
                        <div class="section-header style-2 mb-0">
                            <div class="abs-lab-thumb green">
                                <span class="pluse_1"></span>
                                <span class="pluse_2"></span>
                                <?php if(!empty($settings['cold_simgs3']['url'])): ?>
                                	<img src="<?php echo wp_kses_post($settings['cold_simgs3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
                            	<?php endif; ?>
                            </div>
                            <h2><?php if(!empty($settings['cold_title3'])): echo esc_html($settings['cold_title3']); endif; ?></h2>
							<p><?php if(!empty($settings['cold_cont3'])): echo esc_html($settings['cold_cont3']); endif; ?></p>
                            <ul>
                            	<?php 
								if(!empty($could_groups3)):
								foreach($could_groups3 as $could_grou):
								?>
                                <li>
                                    <div class="left"><span><i class="icofont-tick-mark"></i></span></div>
                                    <div class="right">
                                        <p><?php if(!empty($could_grou['cold_servc3'])): echo esc_html($could_grou['cold_servc3']); endif; ?></p>
                                    </div>
                                </li>
                                <?php
								endforeach;
								endif; 
								?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<?php
		
	}



}





