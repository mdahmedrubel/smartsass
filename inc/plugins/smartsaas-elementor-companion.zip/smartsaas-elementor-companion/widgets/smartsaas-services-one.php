<?php
class Smartsass_One_Services extends \Elementor\Widget_Base {
	public function get_name() {
		return "one_services";
	}

	public function get_title() {
		return __( "Service One", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Servicess Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'service1_title',[
				'label' => __( 'Servicess Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'service1_stitle',[
				'label' => __( 'Servicess Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'service1_count',[
				'label' => __( 'Servicess Count', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		

	?>
	<!-- Service Section Style 2 Start Here -->
	<section class="service-section style-2 seo padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['service1_title'])): echo esc_html($settings['service1_title']); endif; ?></h2> 
				<p><?php if(!empty($settings['service1_stitle'])): echo esc_html($settings['service1_stitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<?php  
				$serv_one_q = new WP_Query(
				    array(
				        'post_type'       => 'service',
				        'post_status'     => 'publish',
				        'posts_per_page' => $settings['service1_count'],
				        'order'       => 'ASC',
				        'orderby'       => 'title',
				    )
				);
				if ( $serv_one_q->have_posts() ) :
				while ( $serv_one_q->have_posts() ):
	    		$serv_one_q->the_post();

	    		$one_sr = get_post_meta(get_the_ID(), 'saas_service', true);
	    		if(isset($one_sr['icon_service']['id'])){	
	    			$ser_icon =  wp_get_attachment_image_src($one_sr['icon_service']['id'], 'large');	
	    		}
				?>
				<div class="lab-item-2">
					<div class="lab-inner">
							<div class="lab-abs-thumb">
								<?php the_post_thumbnail(); ?>
							</div>
						<div class="lab-thumb">
							<?php if(!empty($ser_icon[0])): ?>
								<img src="<?php echo esc_url($ser_icon[0]); ?>" alt="<?php bloginfo('name'); ?>">
							<?php endif; ?>
						</div>
						<div class="lab-content">
							<a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
							<p>
								<?php 
					                $xcerpt = get_the_excerpt();
									$shortexcerpt = wp_trim_words($xcerpt, $num_words = 19, ' ');
									echo esc_html($shortexcerpt);
				                ?>
							</p>
						</div>
					</div>
				</div>
				<?php 
				endwhile;
				wp_reset_query();  
				endif;
				?>
			</div>
		</div>
	</section>
    <!-- Service Section Style 2 Ending Here -->
	<?php

	}



}





