<?php
class Smartsass_Vpn_How_It_Work extends \Elementor\Widget_Base {
	public function get_name() {
		return "how_it_work";
	}

	public function get_title() {
		return __( "Vpn How It Work", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'How It Work Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'vpn_worktitle',[
				'label' => __( 'How It Work Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'vpn_workdesc',[
				'label' => __( 'How It Work Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'hwork_groups',[
				'label' => __( 'How It Work Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [
                     [
                        'name' => 'work_img',
                        'label' => esc_html__('How It Work Image', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                    ], 
                    [
                        'name' => 'circle_txt',
                        'label' => esc_html__('How It Work Circle Text', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'how_work_btitle',
                        'label' => esc_html__('How It Work Box Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$hwork_groups = $this->get_settings('hwork_groups');
	?>
	<!-- vpn Services Section Start here -->
	<section class="vpn-services padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['vpn_worktitle'])): echo esc_html($settings['vpn_worktitle']); endif; ?></h2>
				<p><?php if(!empty($settings['vpn_workdesc'])): echo esc_html($settings['vpn_workdesc']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	        	<?php 
            	if(!empty($hwork_groups)):
            	foreach($hwork_groups as $hwork):
            	?>
	            <div class="service-item">
	                <div class="service-inner">
	                    <div class="service-thumb">
	                        <?php if(!empty($hwork['work_img']['url'])): ?>
								<img src="<?php echo wp_kses_post($hwork['work_img']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
	                        <span><?php if(!empty($hwork['circle_txt'])): echo esc_html($hwork['circle_txt']); endif; ?></span>
	                    </div>
	                    <div class="service-content">
	                        <h5><?php if(!empty($hwork['how_work_btitle'])): echo esc_html($hwork['how_work_btitle']); endif; ?></h5>
	                    </div>
	                </div>
	            </div>
	            <?php 
            	endforeach;
            	endif;
                ?>
	        </div>
	    </div>
	</section>
	<!-- vpn Services Section Ending here -->
	<?php
	}



}





