<?php
class Smartsass_Vpn_About extends \Elementor\Widget_Base {
	public function get_name() {
		return "vpn_about";
	}

	public function get_title() {
		return __( "Vpn About", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Vpn About Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'vpn_aboutimg',[
				'label' => __( 'Vpn About Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$this->add_control(
			'vpn_abouttitle',[
				'label' => __( 'About Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'vpn_aboutdesc',[
				'label' => __( 'Vpn About Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'vpn_con',[
				'label' => __( 'Add Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$this->add_control(
			'vpn_imgs',
			[
				'label' => __( 'Vpn Images', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$vpn_imgs = $this->get_settings('vpn_imgs');
	?>
	<!-- About Section Start Here -->
	<section class="about-section style-3 padding-tb">
		<div class="container">
	        <div class="row align-items-center">
	            <div class="col-lg-6 col-12">
	                <div class="section-wrapper">
	                    <div class="about-thumb"> 
	                        <?php if(!empty($settings['vpn_aboutimg']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['vpn_aboutimg']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
	                    </div>
	                </div>
	            </div>
	            <div class="col-lg-6 col-12">
	                <div class="section-header style-2">
	                    <h2><?php if(!empty($settings['vpn_abouttitle'])): echo esc_html($settings['vpn_abouttitle']); endif; ?></h2>
						<p><?php if(!empty($settings['vpn_aboutdesc'])): echo esc_html($settings['vpn_aboutdesc']); endif; ?></p>
	                    <ul>
	                    	<?php 
							if(!empty($vpn_imgs)):
							foreach($vpn_imgs as $vpn_img):
							?>
	                        <li>
	                        	<?php if(!empty($vpn_img['vpn_con']['url'])): ?>
									<img src="<?php echo wp_kses_post($vpn_img['vpn_con']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
	                        </li>
	                        <?php
							endforeach;
							endif; 
							?>
	                    </ul>
	                </div>
	            </div>
	        </div>
		</div>
	</section>
	<!-- About Section Ending Here -->
	<?php
	}



}





