<?php
class Smartsass_Three_Services extends \Elementor\Widget_Base {
	public function get_name() {
		return "three_services";
	}

	public function get_title() {
		return __( "Service Three", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Servicess Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'service3_title',[
				'label' => __( 'Servicess Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'service3_stitle',[
				'label' => __( 'Servicess Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'service3_count',[
				'label' => __( 'Servicess Count', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		

	?>
	<!-- Service Section Start Here -->
	<section class="service-section style-2 style-6 padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <span><?php if(!empty($settings['service3_title'])): echo esc_html($settings['service3_title']); endif; ?></span> 
				<h2><?php if(!empty($settings['service3_stitle'])): echo esc_html($settings['service3_stitle']); endif; ?></h2>
	        </div>
	        <div class="section-wrapper">
	        	<?php  
				$serv_three_q = new WP_Query(
				    array(
				        'post_type'       => 'service',
				        'post_status'     => 'publish',
				        'posts_per_page' => $settings['service3_count'],
				        'order'       => 'ASC',
				        'orderby'       => 'rand',
				    )
				);

				if ( $serv_three_q->have_posts() ) :
				while ( $serv_three_q->have_posts() ):
	    		$serv_three_q->the_post();

	    		$three_srv = get_post_meta(get_the_ID(), 'saas_service', true);
	    		if(isset($three_srv['icon_service3']['id'])){	
	    			$ser3_icon =  wp_get_attachment_image_src($three_srv['icon_service3']['id'], 'large');	
	    		}
				?>
	            <div class="lab-item">
	                <div class="lab-inner">
	                    <div class="lab-thumb">
	                        <?php if(!empty($ser3_icon[0])): ?>
	                        	<img src="<?php echo esc_url($ser3_icon[0]); ?>" alt="<?php bloginfo('name'); ?>">
	                    	<?php endif; ?>
	                    </div>
	                    <div class="lab-content">
	                        <a href="<?php the_permalink(); ?>"><h4><?php the_title(); ?></h4></a>
	                        <p>
	                        	<?php 
					                $xcerpt = get_the_excerpt();
									$shortexcerpt = wp_trim_words($xcerpt, $num_words = 16, ' ');
									echo esc_html($shortexcerpt);
				                ?>
	                        </p>
	                    </div>
	                </div>
	            </div>
	            <?php 
				endwhile;
				wp_reset_query();  
				endif;
				?>
	        </div>
	    </div>
	</section>
	<!-- Service Section Ending Here -->
	<?php

	}



}





