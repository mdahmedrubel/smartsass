<?php
class Smartsass_Marketing_Counterup extends \Elementor\Widget_Base {
	public function get_name() {
		return "marketing_counterup";
	}

	public function get_title() {
		return __( "Marketing Counterup", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Marketing Counterup Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'progress_img',[
				'label' => __( 'Progess Left Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$this->add_control(
			'progress_stitle',[
				'label' => __( 'Progess Sub Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'progress_title',[
				'label' => __( 'Progess Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'progress_cont',[
				'label' => __( 'Progess Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		//progress bar 
		$this->add_control(
			'progess_groups',[
				'label' => __( 'Progess Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [
                    [
                        'name' => 'pg_title',
                        'label' => esc_html__('Progress Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'pg_percent',
                        'label' => esc_html__('Add Progess Bar Percent Number', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'pg_percentage',
                        'label' => esc_html__('Add Progess Bar Percent Number Two', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

		//Counter up setting
		$this->add_control(
			'marketing_counter',[
				'label' => __( 'Counter Up Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [
                    [
                        'name' => 'count_number',
                        'label' => esc_html__('Counter Numbers', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'count_title',
                        'label' => esc_html__('Add Counter Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$progess_groups = $this->get_settings('progess_groups');
		$marketing_counter = $this->get_settings('marketing_counter');
	?>
	<!-- Marketing Range Section Start here -->
	<section class="market-range-section padding-tb">
	    <div class="container">
	        <div class="top-area">
	            <div class="row align-items-center">
	                <div class="col-lg-6 col-12">
	                    <div class="mr-thumb">
	                        <?php if(!empty($settings['progress_img']['url'])): ?>
	                        	<img src="<?php echo wp_kses_post($settings['progress_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
	                		<?php endif; ?>
	                    </div>
	                </div>
	                <div class="col-lg-6 col-12">
	                    <div class="section-header style-2">
	                        <span><?php if(!empty($settings['progress_stitle'])): echo esc_html($settings['progress_stitle']); endif; ?></span>
	                        <h2><?php if(!empty($settings['progress_title'])): echo esc_html($settings['progress_title']); endif; ?></h2>
	                        <p><?php if(!empty($settings['progress_cont'])): echo esc_html($settings['progress_cont']); endif; ?></p>
	                    </div>
	                    <div class="section-wrapper">
	                        <div class="skill-bar-wrapper">
	                        	<?php 
				            	if(!empty($progess_groups)):
				            	$crp_prog = 0;
				            	foreach($progess_groups as $progessg):
				            	$crp_prog++;

				            	if($crp_prog == 1){
				            		$p_color = "background: linear-gradient(to top, #23cc88, #8ecf35);";
				            	}elseif($crp_prog == 2){
				            		$p_color = "background: linear-gradient(to top, #ff4f58, #ffb400);";
				            	}else{
				            		$p_color = "background: linear-gradient(to top, #01cbad, #47a1f2);";
				            	}

				            	?>
	                            <div class="skill-item">
                                    <div class="skill-title">
                                        <div class="left"><?php if(!empty($progessg['pg_title'])): echo esc_html($progessg['pg_title']); endif; ?></div>
                                        <div class="right"><?php if(!empty($progessg['pg_percent'])): echo esc_html($progessg['pg_percent']); endif; ?></div>
                                    </div>
                                    <div class="skillbar-container clearfix" data-percent="<?php if(!empty($progessg['pg_percentage'])): echo esc_html($progessg['pg_percentage']); endif; ?>">
                                        <div class="skills" style="<?php echo esc_attr($p_color); ?>"></div>
                                    </div>
                                </div>
	                            <?php 
				            	endforeach;
				            	endif;
				                ?>
	                        </div>
	                    </div>
	                </div>
	            </div>
	        </div>
	        <div class="bottom-area">
	            <div class="section-wrapper">
	            	<?php 
	            	if(!empty($marketing_counter)):
	            	$color = 0;
	            	foreach($marketing_counter as $marketingc):
	            	$color++;

	            	if($color == 1){
	            		$colors = "#fb4f6b";
	            	}elseif($color == 2){
	            		$colors = "#ffb400";
	            	}elseif($color == 3){
	            		$colors = "#c961fa";
	            	}elseif($color == 4){
	            		$colors = "#38cd78";
	            	}
	            	?>
	                <div class="contact-count-item">
	                    <div class="contact-count-inner">
	                        <div class="contact-count-content">
	                            <h5 style="color: <?php echo esc_attr($colors); ?>;">
	                            	<span class="counter">
	                            		<?php if(!empty($marketingc['count_number'])): echo esc_html($marketingc['count_number']); endif; ?>
	                            	</span><?php if($color == 4): ?><?php _e("k", "smartsaas"); ?><?php endif; ?>
	                            	<?php if($color == 3 || $color == 4): ?>+<?php endif; ?>
	                            </h5>
	                            <p><?php if(!empty($marketingc['count_title'])): echo esc_html($marketingc['count_title']); endif; ?></p>
	                        </div>
	                    </div>
	                </div>
	                <?php 
	            	endforeach;
	            	endif;
	                ?>
	            </div>
	        </div>
	    </div>
	</section>
	   <script>
            jQuery(window).scroll(function() {
                var hT = jQuery('.skill-bar-wrapper').offset().top,
                    hH = jQuery('.skill-bar-wrapper').outerHeight(),
                    wH = jQuery(window).height(),
                    wS = jQuery(this).scrollTop();
                if (wS > (hT+hH-1.4*wH)){
                    jQuery(document).ready(function(){
                        jQuery('.skillbar-container').each(function(){
                            jQuery(this).find('.skills').animate({
                                width:jQuery(this).attr('data-percent')
                            }, 5000); // 5 seconds
                        });
                    });
                }
            });
        </script>
	<!-- Marketing Range Section Start here -->
	<?php
	}

}





