<?php
class Smartsass__Seo_Section extends \Elementor\Widget_Base {
	public function get_name() {
		return "our_smartseo";
	}

	public function get_title() {
		return __( "SEO Our SmartSeo", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Smart SEO Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'smart_seotitle',[
				'label' => __( 'Smart Seo Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'seotitle_part2',[
				'label' => __( 'Smart Seo Title Part Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'smart_seocont',[
				'label' => __( 'Smart Seo Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'smart_imgone',[
				'label' => __( 'Smart Seo Round Shape', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'smart_imgtwo',[
				'label' => __( 'Smart Seo Big Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'seo_numbers',[
				'label' => __( 'Seo Number', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
			]
		);
		$repeater->add_control(
			'seo_number_text',[
				'label' => __( 'Seo Number Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'about_seos',
			[
				'label' => __( 'Seo About Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->add_control(
			'seoabout_btn',[
				'label' => __( 'Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'seoabot_url',[
				'label' => __( 'Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$about_seos = $this->get_settings('about_seos');
	?>
	<!-- About Section Start Here -->
	<section class="about-section seo-about padding-tb">
		<div class="round-shape d-none d-lg-block">
			<div class="round">
				<?php if(!empty($settings['smart_imgone']['url'])): ?>
					<img src="<?php echo wp_kses_post($settings['smart_imgone']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
				<?php endif; ?>
			</div>
		</div>
		<div class="codex-shape">
			<div class="line line_1"></div>
			<div class="line line_2"></div>
			<div class="line line_3"></div>
			<div class="line line_4"></div>
			<div class="line line_5"></div>
			<div class="line line_6"></div>
		</div>
		<div class="container">
			<div class="row align-items-center flex-row-reverse">
				<div class="col-lg-6">
					<div class="section-wrapper">
						<div class="lab-thumb">
							<?php if(!empty($settings['smart_imgtwo']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['smart_imgtwo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="col-lg-6">
					<div class="section-header style-2">
						<h2><?php if(!empty($settings['smart_seotitle'])): echo esc_html($settings['smart_seotitle']); endif; ?></h2>
						<h2><?php if(!empty($settings['seotitle_part2'])): echo esc_html($settings['seotitle_part2']); endif; ?></h2>
						<p><?php if(!empty($settings['smart_seocont'])): echo esc_html($settings['smart_seocont']); endif; ?></p>
						<ul class="smart-list-ef">
							<?php
							$seo_about_count = 0;
							 foreach($about_seos as $about_seo):
							 $seo_about_count++; 
							?>
							<li>
								<div class="left"><span><?php echo esc_attr($seo_about_count); ?></span></div>
								<div class="right">
									<p>
										<span><?php if(!empty($about_seo['seo_numbers'])): echo esc_html($about_seo['seo_numbers']); endif; ?></span>
										<?php if(!empty($about_seo['seo_number_text'])): echo esc_html($about_seo['seo_number_text']); endif; ?>
									</p>
								</div>
							</li>
							<?php
							if($seo_about_count == 4){
								break;
							}
							 endforeach; 
							?>


						</ul>
						<?php if(!empty($settings['seoabout_btn'])): ?>
						<a href="<?php echo esc_url($settings['seoabot_url']); ?>" class="lab-btn">
							<span><?php echo esc_html($settings['seoabout_btn']); ?></span>
						</a>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- About Section Ending Here -->
	<?php
		
	}



}





