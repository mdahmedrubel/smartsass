<?php
class Smartsass_Home_Marketing_Testimonials extends \Elementor\Widget_Base {
	public function get_name() {
		return "marketing_testimonial";
	}

	public function get_title() {
		return __( "Marketing Testimonials", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Marketing Testimonial Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'mtesti_title',[
				'label' => __( 'Testimonial Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'mtesti_stitle',[
				'label' => __( 'Testimonial Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'smartsaas' ),
				'types' => [ 'classic'],
				'selector' => '{{WRAPPER}} .change-white',
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'testbtn_img',[
				'label' => __( 'Testimonial Button Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$this->add_control(
			'test_btn_imgs',
			[
				'label' => __( 'Testimonial Button Small Image', 'TEXT' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);





		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'testi_clientimg',[
				'label' => __( 'Client Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'quote_img',[
				'label' => __( 'Testimonial Quote Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$repeater->add_control(
			'testim_content',[
				'label' => __( 'Testimonial Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'quotef_img',[
				'label' => __( 'Testimonial Quote Image Bottom', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$repeater->add_control(
			'testi_cmane',[
				'label' => __( 'Testimonial Client Name', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'testi_cposition',[
				'label' => __( 'Testimonial Client Position', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
				'marketing_rating',[
				'label' => __( 'Select Ratings', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'ratingm5',
				'label_block' => true,
				'options' => [
					'ratingm1'  => __( 'One Star', 'smartsaas' ),
					'ratingm2'  => __( 'Two Star', 'smartsaas' ),
					'ratingm3'  => __( 'Three Star', 'smartsaas' ),
					'ratingm4'  => __( 'Four Star', 'smartsaas' ),
					'ratingm5'  => __( 'Five Star', 'smartsaas' ),
				],
			]
		);
		$this->add_control(
			'marketing_testi',
			[
				'label' => __( 'Marketing Testimonial Section', 'TEXT' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$test_btn_imgs = $this->get_settings('test_btn_imgs');
		$marketing_testi = $this->get_settings('marketing_testi');
	?>
    <!-- testimonial section start here -->
	<section class="testimonial-section style-2 change-white padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <span><?php if(!empty($settings['mtesti_title'])): echo esc_html($settings['mtesti_title']); endif; ?></span>
				<h2><?php if(!empty($settings['mtesti_stitle'])): echo esc_html($settings['mtesti_stitle']); endif; ?></h2>
	        </div>
	        <div class="section-wrapper">
	            <div class="testimonial-slider-two">
	                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
	                    <ol class="carousel-indicators">
	                    	<?php 
							if(!empty($test_btn_imgs)):
							$counts = 0;
							foreach($test_btn_imgs as $testbtnimgs):
							$counts++;
							?>
	                        <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo esc_attr($counts); ?>" class="active">
	                            <img src="<?php echo wp_kses_post($testbtnimgs['testbtn_img']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
	                        </li>
	                        <?php
							endforeach;
							endif; 
							?>
	                    </ol>
	                    <div class="carousel-inner">
	                    	<?php
							if(!empty($marketing_testi)): 
							$active = 0;
							foreach($marketing_testi as $marketing_t):
							$active++;
								$qimg = wp_get_attachment_image_src($marketing_t['quote_img']['id'], 'full');
								$qimg2 = wp_get_attachment_image_src($marketing_t['quotef_img']['id'], 'full');
							?>
	                        <div class="carousel-item <?php if($active == 1): ?> active <?php endif; ?>">
	                            <div class="testi-item">
	                                <div class="testi-inner">
	                                    <div class="testi-thumb">
	                                    <?php if(!empty($marketing_t['testi_clientimg']['url'])): ?>
											<img src="<?php echo wp_kses_post($marketing_t['testi_clientimg']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
	                                    </div>
	                                    <div class="testi-content">
	                                        <p>
	                                        	<?php if(!empty($qimg)): ?><img src="<?php echo esc_url($qimg[0]); ?>" alt="<?php bloginfo( 'name' ); ?>" class="left-img"><?php endif; ?>
	                                        		<?php if(!empty($marketing_t['testim_content'])): echo esc_html($marketing_t['testim_content']); endif; ?>
	                                        	<?php if(!empty($qimg)): ?><img src="<?php echo esc_url($qimg2[0]); ?>" alt="<?php bloginfo( 'name' ); ?>" class="right-img"><?php endif; ?>
	                                        </p>
	                                        <h6><?php if(!empty($marketing_t['testi_cmane'])): echo esc_html($marketing_t['testi_cmane']); endif; ?>  <span>(<?php if(!empty($marketing_t['testi_cposition'])): echo esc_html($marketing_t['testi_cposition']); endif; ?>)</span></h6>
	                                        <div class="rating">
	                                            <?php if($marketing_t['marketing_rating'] == 'ratingm1'): ?>
													<i class="icofont-star"></i>
												<?php endif; ?>
												<?php if($marketing_t['marketing_rating'] == 'ratingm2'): ?>
													<i class="icofont-star"></i><i class="icofont-star"></i>
												<?php endif; ?>
												<?php if($marketing_t['marketing_rating'] == 'ratingm3'): ?>
													<i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i>
												<?php endif; ?>
												<?php if($marketing_t['marketing_rating'] == 'ratingm4'): ?>
													<i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i>
												<?php endif; ?>
												<?php if($marketing_t['marketing_rating'] == 'ratingm5'): ?>
													<i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i>
												<?php endif; ?>
	                                        </div>
	                                    </div>
	                                </div>
	                            </div>
	                        </div>
	                        <?php 
							endforeach;
							endif;
							?>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</section>
	<!-- testimonial section ending -->
	<?php
		
	}



}





