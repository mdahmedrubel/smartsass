<?php
class Smartsass_Portfolio_Style_Two extends \Elementor\Widget_Base {
	public function get_name() {
		return "portfolio_two";
	}

	public function get_title() {
		return __( "Portfolio Two", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Portfolio Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'portfolio2_btn',[
				'label' => __( 'Portfolio Two Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'portfolio2_btnurl',[
				'label' => __( 'Portfolio Two Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		

	?>
	<!-- Recent Case Section Start Here -->
	<section class="portfolio-section padding-tb">
		<div class="container">
			<div class="section-wrapper">
                <ul class="port-filter">
					<li data-filter="*" class="active"><i class="icofont-star"></i><span><?php esc_html_e('All', 'smartsaas'); ?></span><?php esc_html_e('Views', 'smartsaas'); ?></li>
					<?php  
					$portfolio_slugs = get_terms( 'Portfolio_cat', array(
				 	'hide_empty' => true,
					));

					if(!empty($portfolio_slugs)):
					foreach($portfolio_slugs as $portfolio_slug):
					?>
					<li data-filter=".<?php echo esc_attr($portfolio_slug->slug); ?>"><i class="icofont-image"></i><span><?php echo esc_html($portfolio_slug->name); ?></span></li>
					<?php 
	                endforeach; 
					endif;
	                ?>
				</ul>
                <div class="grid">
                	<?php 
	                 $portfolio_two = new WP_Query( array(
	                 	'post_type' => 'portfolio',
	                    'posts_per_page' => -1,
	                    'post_status' => 'publish',                           
	                ));
					?>
					<?php
					if($portfolio_two->have_posts()): 
					while($portfolio_two->have_posts()): $portfolio_two->the_post(); 
					$port_image_url = wp_get_attachment_image_src( get_post_thumbnail_id(), 'large'); 
					$portfo_slug = get_the_terms( get_the_ID(), 'Portfolio_cat',true );			
					?>
                    <div class="lab-item-3 port-item <?php  foreach($portfo_slug as $portfo_slg) { echo esc_attr("$portfo_slg->slug"); } ?>">
                        <div class="lab-inner">
                            <div class="lab-thumb">
                                <img src="<?php echo esc_url($port_image_url[0]); ?>" alt="<?php bloginfo('name'); ?>">
                                <div class="port-share">
                                    <div class="lab-content">
						                <span>
						                	<?php echo esc_html($portfo_slg->name); ?>
						                </span>						              
                                        <h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
                                    </div>
                                    <a href="<?php the_permalink(); ?>"><i class="icofont-link-alt"></i></a>
                                    <a href="<?php echo esc_url($port_image_url[0]); ?>"  data-rel="lightcase:myCollection"><i class="icofont-drag1"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
					endwhile; 
					endif; 
					wp_reset_query();  
					?>
                </div>
			</div>
			<?php if(!empty($settings['portfolio2_btn'])): ?>
			<div class="text-center">
				<a href="<?php echo esc_url($settings['portfolio2_btnurl']); ?>" class="lab-btn"><span><?php echo esc_html($settings['portfolio2_btn']); ?></span></a>
			</div>
			<?php endif; ?>
		</div>
	</section>
	<!-- Recent Case Section Ending Here -->
	<?php
	}



}





