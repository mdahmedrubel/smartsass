<?php
class Smartsass_Vpn_Faq extends \Elementor\Widget_Base {
	public function get_name() {
		return "vpn_faqs";
	}

	public function get_title() {
		return __( "Vpn Faqs", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Vpn Faq Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'vpn_faq_title',[
				'label' => __( 'Vpn Faqs Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'vpn_faq_cont',[
				'label' => __( 'Vpn Faqs Title Part Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'vpn_faq_img',[
				'label' => __( 'Faqs Right Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$this->add_control(
			'vpn_faqs',[
				'label' => __( 'Vpn Faqs Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [
                    [
                        'name' => 'faq_title',
                        'label' => esc_html__('Faqs Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'faq_content',
                        'label' => esc_html__('Faqs Content', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$vpn_faqs = $this->get_settings('vpn_faqs');
	?>
	<!-- faq section start here -->
	<section class="faq-section padding-tb">
	    <div class="container">
	        <div class="row justify-content-center flex-row-reverse">
	            <div class="col-xl-6 col-12">
	                <div class="faq-right-part">
	                    <div class="faq-thumb">
	                    	<?php if(!empty($settings['vpn_faq_img']['url'])): ?>
	                        	<img src="<?php echo wp_kses_post($settings['vpn_faq_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
	                		<?php endif; ?>
	                    </div>
	                </div>
	            </div>
	            <div class="col-xl-6 col-12">
	                <div class="faq-left-part">
	                    <div class="section-header style-2">
	                        <h2><?php if(!empty($settings['vpn_faq_title'])): echo esc_html($settings['vpn_faq_title']); endif; ?></h2>
	                        <h2><?php if(!empty($settings['vpn_faq_cont'])): echo esc_html($settings['vpn_faq_cont']); endif; ?></h2>
	                    </div>
	                    <div class="section-wrapper">
							<ul class="accordion">
								<?php 
				            	if(!empty($vpn_faqs)):
				            	foreach($vpn_faqs as $vpn_faq):
				            	?>
								<li class="accordion-item">
									<div class="accordion-list">
										<div class="left">
	                                        <div class="icon"></div>
	                                    </div>
	                                    <div class="right">
	                                        <h6><?php if(!empty($vpn_faq['faq_title'])): echo esc_html($vpn_faq['faq_title']); endif; ?></h6>
	                                    </div>
									</div>
									<div class="accordion-answer">
										<p><?php if(!empty($vpn_faq['faq_content'])): echo esc_html($vpn_faq['faq_content']); endif; ?></p>
									</div>
								</li>
								<?php 
				            	endforeach;
				            	endif;
				                ?>
							</ul>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</section>
	<!-- faq section ending here -->
	<?php
	}



}





