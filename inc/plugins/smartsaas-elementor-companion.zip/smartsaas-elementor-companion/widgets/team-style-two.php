<?php
class Smartsass_Team_Style_Two extends \Elementor\Widget_Base {
	public function get_name() {
		return "team_twos";
	}

	public function get_title() {
		return __( "Team Two", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Team Style Two Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		//wp_query for the seo blog post
		$team_style_2 = new WP_Query(
		    array(
		        'post_type'       => 'team',
		        'post_status'     => 'publish',
		        'posts_per_page' => 7
		    )
		);

		$tpost_data = array();
		while ( $team_style_2->have_posts() ) {
		    $team_style_2->the_post();
		    

		    $tpost_data[] = array(
		        "title" => wp_trim_words( get_the_title(), 4 ),
		        "permalink"=>get_permalink(),
		        "date"=>get_the_date('j F,Y'),
		        "thumbnail"=>get_the_post_thumbnail_url(get_the_ID(),"large"),
		        "excerpt"=>wp_trim_words(get_the_excerpt(), 18, ''),

		        "saas_team2" => get_post_meta(get_the_ID(), 'saas_team', true)

		    );
		}

	?>
	<?php if($team_style_2->post_count > 1): ?>
    <!-- Team Member Section Start here -->
	<div class="team-section padding-tb">
		<div class="container">
		    <div class="row">
		        <div class="col-12">
		            <div class="team-top">
		                <div class="team-top-area">
		                    <div class="row no-gutters align-items-center flex-row-reverse">
		                        <div class="col-lg-6 col-12">
		                            <div class="team-thumb">
		                               <img src="<?php echo esc_url($tpost_data[0]['thumbnail']); ?>" alt="<?php bloginfo( 'name' ); ?>">
		                            </div>
		                        </div>
		                        <div class="col-lg-6 col-12">
		                            <div class="team-content">
		                                <a href="<?php echo esc_url($tpost_data[0]['permalink']); ?>">
		                                	<h4 class="member-name"><?php echo esc_html($tpost_data[0]['title']); ?></h4>
		                                </a>
		                                <span class="member-dagi">
		                                	<?php 
												if(!empty($tpost_data[0]['saas_team2']['position'])):
											 		echo esc_html($tpost_data[0]['saas_team2']['position']); 
												endif;
											?>
		                                </span>
		                                <p class="member-details">
		                                	<?php echo esc_html($tpost_data[0]['excerpt']); ?>
		                                </p>
		                                <ul class="icon-style-list">
		                                    <li><i class="fas fa-home"></i><span><?php if(!empty($tpost_data[0]['saas_team2']['tam_address'])): echo esc_html($tpost_data[0]['saas_team2']['tam_address']); endif; ?></span></li>
		                                    <li><i class="fas fa-envelope"></i><span>
		                                    <?php if(!empty($tpost_data[0]['saas_team2']['team_mail'])): echo esc_html($tpost_data[0]['saas_team2']['team_mail']); endif; ?></span></li>
		                                    <li><i class="fas fa-phone-square"></i><span><?php if(!empty($tpost_data[0]['saas_team2']['team_number'])): echo esc_html($tpost_data[0]['saas_team2']['team_number']); endif; ?></span></li>
		                                    <li><i class="fas fa-globe"></i><span><?php if(!empty($tpost_data[0]['saas_team2']['team_website'])): echo esc_html($tpost_data[0]['saas_team2']['team_website']); endif; ?></span></li>
		                                    <li>
		                                        <i class="fas fa-share-alt-square"></i>
		                                        <ul class="d-flex flex-wrap justify-content-start">
                                           			<?php if(!empty($tpost_data[0]['saas_team2']['team_fburl'])): ?>
                                                    <li><a href="<?php echo esc_url($tpost_data[0]['saas_team2']['team_fburl']); ?>" class="facebook"><i class="fab fa-facebook-f"></i></a>
                                                    </li>
                                                	<?php endif; ?>
                                                	<?php if(!empty($tpost_data[0]['saas_team2']['team_piurl'])): ?>
                                                    <li><a href="<?php echo esc_url($tpost_data[0]['saas_team2']['team_piurl']); ?>" class="pinterest"><i class="fab fa-pinterest-p"></i></a></li>
                                                    <?php endif; ?>
                                                    <?php if(!empty($tpost_data[0]['saas_team2']['team_twurl'])): ?>
                                                    <li><a href="<?php echo esc_url($tpost_data[0]['saas_team2']['team_twurl']); ?>" class="twitter"><i class="fab fa-twitter"></i></a>
                                                    </li>
                                                    <?php endif; ?>

                                                    <?php if(!empty($tpost_data[0]['saas_team2']['team_gburl'])): ?>
                                                    <li><a href="<?php echo esc_url($tpost_data[0]['saas_team2']['team_gburl']); ?>" class="globe"><i class="fas fa-globe"></i></a>
                                                    </li>
                                                    <?php endif; ?>   
		                                        </ul>
		                                    </li>
		                                </ul>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </div>

		            <div class="team-bottom">
		                <div class="team-bottom-area">
		                    <div class="row justify-content-center align-items-center">
		                    	<?php
				                for($i=1; $i<7 ;$i++):
				                ?>
		                        <div class="col-xl-4 col-md-6 col-12">
		                            <div class="team-item">
		                                <div class="team-item-inner">
		                                    <div class="team-thumb">
		                                        <img src="<?php echo esc_url($tpost_data[$i]['thumbnail']); ?>" alt="<?php bloginfo( 'name' ); ?>">
		                                    </div>
		                                    <div class="team-content">
		                                        <a href="<?php echo esc_url($tpost_data[$i]['permalink']); ?>">
		                                        	<h5 class="member-name"><?php echo esc_html($tpost_data[$i]['title']); ?></h5>
		                                        </a>
		                                        <span class="member-dagi">
		                                        	<?php 
														if(!empty($tpost_data[$i]['saas_team2']['position'])):
													 		echo esc_html($tpost_data[$i]['saas_team2']['position']); 
														endif;
													?>
		                                        </span>
		                                        <p class="member-details">
		                                        	<?php echo esc_html($tpost_data[$i]['excerpt']); ?>
		                                        </p>
		                                        <ul class="icon-style-list">
		                                            <li><i class="fas fa-home"></i><span><?php if(!empty($tpost_data[$i]['saas_team2']['tam_address'])): echo esc_html($tpost_data[$i]['saas_team2']['tam_address']); endif; ?></span>
		                                            </li>
		                                            <li><i class="fas fa-globe"></i><span><?php if(!empty($tpost_data[$i]['saas_team2']['team_website'])): echo esc_html($tpost_data[$i]['saas_team2']['team_website']); endif; ?></span>
		                                            </li>
		                                        </ul>
		                                    </div>
		                                </div>
		                            </div>
		                        </div>
		                        <?php
								  endfor; 
								?>
		                    </div>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</div>
	<?php wp_reset_query(); endif; ?>
	<!-- Team Member Section Ending here -->
	<?php
		
	}



}





