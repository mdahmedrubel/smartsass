<?php
class Smartsass_Home_Vpn_Pricing_Plan extends \Elementor\Widget_Base {
	public function get_name() {
		return "vpn_pricing";
	}

	public function get_title() {
		return __( "VPN Pricing Plan", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Pricing Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Background', 'smartsaas' ),
				'types' => [ 'classic'],
				'selector' => '{{WRAPPER}} .pricing-table.vpn',
			]
		);
		$this->add_control(
			'vpnpricing1_title',[
				'label' => __( 'Pricing Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'vpnpricing1_stitle',[
				'label' => __( 'Pricing Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'vpnpackage_name',[
				'label' => __( 'Package Name', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'vpnpackage_desc',[
				'label' => __( 'Package Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpnpackage_price',[
				'label' => __( 'Package Price', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpnpackage_duration',[
				'label' => __( 'Package Duration', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpnpackage_feature1',[
				'label' => __( 'Package Feature 1', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpnpackage_feature2',[
				'label' => __( 'Package Feature 2', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpnpackage_feature3',[
				'label' => __( 'Package Feature 3', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpnpackage_feature4',[
				'label' => __( 'Package Feature 4', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpnpackage_feature5',[
				'label' => __( 'Package Feature 5', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpnpackage_btn',[
				'label' => __( 'Package Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpnpackage_url',[
				'label' => __( 'Package Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,

			]
		);
		$this->add_control(
			'vpnpricing_plans',
			[
				'label' => __( 'Pricing Plan Section', 'TEXT' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$vpnpricing_plans = $this->get_settings('vpnpricing_plans');
	?>
	<!-- Pricing Table Section Start Here -->
	<section class="pricing-table vpn padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['vpnpricing1_title'])): echo esc_html($settings['vpnpricing1_title']); endif; ?></h2>
				<p><?php if(!empty($settings['vpnpricing1_stitle'])): echo esc_html($settings['vpnpricing1_stitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<?php 
				if(!empty($vpnpricing_plans)):
				foreach($vpnpricing_plans as $vpnpricings):
				?>
				<div class="pricing-item">
					<div class="pricing-inner">
						<div class="pricing-head">
							<h4><?php if(!empty($vpnpricings['vpnpackage_name'])): echo esc_html($vpnpricings['vpnpackage_name']); endif; ?></h4>
							<p><?php if(!empty($vpnpricings['vpnpackage_desc'])): echo esc_html($vpnpricings['vpnpackage_desc']); endif; ?></p>
						</div>
						<div class="pricing-body">
							<div class="price">
								<h2><?php if(!empty($vpnpricings['vpnpackage_price'])): echo esc_html($vpnpricings['vpnpackage_price']); endif; ?></h2>
								<p><?php if(!empty($vpnpricings['vpnpackage_duration'])): echo esc_html($vpnpricings['vpnpackage_duration']); endif; ?></p>
							</div>
							<div class="price-list">
								<ul>
									<?php if(!empty($vpnpricings['vpnpackage_feature1'])): ?>
										<li><?php echo esc_html($vpnpricings['vpnpackage_feature1']); ?></li>
									<?php endif; ?>
									<?php if(!empty($vpnpricings['vpnpackage_feature2'])): ?>
										<li><?php echo esc_html($vpnpricings['vpnpackage_feature2']); ?></li>
									<?php endif; ?>
									<?php if(!empty($vpnpricings['vpnpackage_feature3'])): ?>
										<li><?php echo esc_html($vpnpricings['vpnpackage_feature3']); ?></li>
									<?php endif; ?>
									<?php if(!empty($vpnpricings['vpnpackage_feature4'])): ?>
										<li><?php echo esc_html($vpnpricings['vpnpackage_feature4']); ?></li>
									<?php endif; ?>
									<?php if(!empty($vpnpricings['vpnpackage_feature5'])): ?>
										<li><?php echo esc_html($vpnpricings['vpnpackage_feature5']); ?></li>
									<?php endif; ?>
								</ul>
							</div>
							<div class="price-btn">
								<?php if(!empty($vpnpricings['vpnpackage_btn'])): ?>
									<a href="<?php echo esc_url($vpnpricings['vpnpackage_url']['url']); ?>" class="lab-btn"><span><?php echo esc_html($vpnpricings['vpnpackage_btn']); ?></span></a>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
				<?php
				endforeach;
				endif; 
				?>
			</div>
		</div>
	</section>
	<!-- Pricing Table Section Ending Here -->
	<?php
		
	}



}





