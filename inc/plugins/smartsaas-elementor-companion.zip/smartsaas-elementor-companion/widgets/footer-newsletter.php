<?php
class Smartsass_Footer_NewsLetter_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "footer_nletter";
	}

	public function get_title() {
		return __( "Footer Newsletter", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Newsletter Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'newsl_title',[
				'label' => __( 'Newsletter Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'neswl_shortcode',[
				'label' => __( 'Newsletter Shortcode', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Newsletter Background', 'smartsaas' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .news-letter',
			]
		);
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

	?>
	<!-- Newsletter Section Start Here -->
	<div class="news-letter">
	    <div class="container">

            <div class="row">
	            <div class="col-md-5 col-sm-12 col-xs-12">
		            <div class="news-title">
		            	<?php if(!empty($settings['newsl_title'])): ?>
			                <h2><?php echo esc_html($settings['newsl_title']); ?></h2>
			            <?php endif; ?>
		            </div>
	            </div>
	            <div class="col-md-7 col-sm-12 col-xs-12">
		            <?php if(!empty($settings['neswl_shortcode'])): ?>
			            <div class="news-form">
			            	<div class="nf-list">
				                <?php echo do_shortcode($settings['neswl_shortcode']); ?>
				            </div>
			            </div>
			        <?php endif; ?>
		        </div>
	        </div>
	    </div>
	</div>
	<!-- Newsletter Section Ending Here -->
	<?php
		
	}



}





