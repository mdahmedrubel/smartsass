<?php
class Smartsass_Erp_Hr_Manager extends \Elementor\Widget_Base {
	public function get_name() {
		return "erp_hrmanager";
	}

	public function get_title() {
		return __( "Erp HR.Manager", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Hr Manager Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'choose_erpmanaer',[
				'label' => __( 'Select Feature style', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'hrmanager_one',
				'options' => [
					'hrmanager_one'  => __( 'Hr Manager Style One', 'smartsaas' ),
					'hrmanager_two' => __( 'Hr Manager Style Two', 'smartsaas' ),
					'hrmanager_three' => __( 'Hr Manager Style Three', 'smartsaas' ),
					'hrmanager_four' => __( 'Hr Manager Style Four', 'smartsaas' ),
				],
			]
		);
		//Hr manager section
		$this->add_control(
			'hr_one_bigimg',[
				'label' => __( 'Hr Manager One Big Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_one',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_one_smallimg',[
				'label' => __( 'Hr Manager One Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_one',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_manager_title1',[
				'label' => __( 'Hr Manager Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_one',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_manager_content1',[
				'label' => __( 'Hr Manager Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_one',
						]
					]
				]

			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'manager_icon',[
				'label' => __( 'Add Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'manager_tabtitle',[
				'label' => __( 'Hr Manager Tab Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'manager_tabcont',[
				'label' => __( 'Manager Tab Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'erps_managers',
			[
				'label' => __( 'Erp Managers Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_one',
						]
					]
				]
			]
		);

		$this->add_control(
			'manager_onebtn',[
				'label' => __( 'Hr Manager One Button', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_one',
						]
					]
				]

			]
		);
		$this->add_control(
			'manager_onebtnurl',[
				'label' => __( 'Hr Manager One Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_one',
						]
					]
				]

			]
		);

		//manager style two
		$this->add_control(
			'hr_one_bigimgs2',[
				'label' => __( 'Hr Manager One Big Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_two',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_one_smallimgs2',[
				'label' => __( 'Hr Manager One Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_two',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_manager_title1s2',[
				'label' => __( 'Hr Manager Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_two',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_manager_content1s2',[
				'label' => __( 'Hr Manager Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_two',
						]
					]
				]

			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'manager_icons2',[
				'label' => __( 'Add Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'manager_tabtitles2',[
				'label' => __( 'Hr Manager Tab Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'manager_tabconts2',[
				'label' => __( 'Manager Tab Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'erps_managerss2',
			[
				'label' => __( 'Erp Managers Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_two',
						]
					]
				]
			]
		);
		$this->add_control(
			'manager_onebtns2',[
				'label' => __( 'Hr Manager One Button', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_two',
						]
					]
				]

			]
		);
		$this->add_control(
			'manager_onebtnurls2',[
				'label' => __( 'Hr Manager One Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_two',
						]
					]
				]

			]
		);

		//manager style three
		$this->add_control(
			'hr_one_bigimgs3',[
				'label' => __( 'Hr Manager One Big Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_three',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_one_smallimgs3',[
				'label' => __( 'Hr Manager One Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_three',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_manager_title1s3',[
				'label' => __( 'Hr Manager Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_three',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_manager_content1s3',[
				'label' => __( 'Hr Manager Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_three',
						]
					]
				]

			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'manager_icons3',[
				'label' => __( 'Add Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'manager_tabtitles3',[
				'label' => __( 'Hr Manager Tab Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'manager_tabconts3',[
				'label' => __( 'Manager Tab Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'erps_managerss3',
			[
				'label' => __( 'Erp Managers Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_three',
						]
					]
				]
			]
		);
		$this->add_control(
			'manager_onebtns3',[
				'label' => __( 'Hr Manager One Button', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_three',
						]
					]
				]

			]
		);
		$this->add_control(
			'manager_onebtnurls3',[
				'label' => __( 'Hr Manager One Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_three',
						]
					]
				]

			]
		);

		//HR manager style four
		$this->add_control(
			'hr_one_bigimgs4',[
				'label' => __( 'Hr Manager One Big Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_four',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_one_smallimgs4',[
				'label' => __( 'Hr Manager One Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_four',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_manager_title1s4',[
				'label' => __( 'Hr Manager Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_four',
						]
					]
				]

			]
		);
		$this->add_control(
			'hr_manager_content1s4',[
				'label' => __( 'Hr Manager Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_four',
						]
					]
				]

			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'manager_icons4',[
				'label' => __( 'Add Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'manager_tabtitles4',[
				'label' => __( 'Hr Manager Tab Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'manager_tabconts4',[
				'label' => __( 'Manager Tab Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'erps_managerss4',
			[
				'label' => __( 'Erp Managers Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_four',
						]
					]
				]
			]
		);
		$this->add_control(
			'manager_onebtns4',[
				'label' => __( 'Hr Manager One Button', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_four',
						]
					]
				]

			]
		);
		$this->add_control(
			'manager_onebtnurls4',[
				'label' => __( 'Hr Manager One Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
				'terms' => [
						[
							'name'  => 'choose_erpmanaer',
							'operator'  => '==',
							'value'  => 'hrmanager_four',
						]
					]
				]

			]
		);
		

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$choose_erpmanaer = $this->get_settings('choose_erpmanaer');
		$erps_managers = $this->get_settings('erps_managers');
		$erps_managerss2 = $this->get_settings('erps_managerss2');
		$erps_managerss3 = $this->get_settings('erps_managerss3');
		$erps_managerss4 = $this->get_settings('erps_managerss4');
	?>
	<?php if($choose_erpmanaer == 'hrmanager_one'): ?>
	<section class="erp-manager bgc-1 padding-tb">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-12">
						<div class="lab-thumb">
							<div class="abs-lab-thumb">
								<span class="pluse_1"></span>
								<span class="pluse_2"></span>
								<?php if(!empty($settings['hr_one_smallimg']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['hr_one_smallimg']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
							</div>
							<?php if(!empty($settings['hr_one_bigimg']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['hr_one_bigimg']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="lab-content">
							<h2><?php if(!empty($settings['hr_manager_title1'])): echo esc_html($settings['hr_manager_title1']); endif; ?></h2>
							<p><?php if(!empty($settings['hr_manager_content1'])): echo esc_html($settings['hr_manager_content1']); endif; ?></p>
							<ul class="accordion">
								<?php 
								if(!empty($erps_managers)):
								foreach($erps_managers as $erps_manager):
								?>
								<li class="accordion-item">
									<div class="accordion-list">
										<div class="left">
											<span>
												<?php if(!empty($erps_manager['manager_icon']['url'])): ?>
													<img src="<?php echo wp_kses_post($erps_manager['manager_icon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
												<?php endif; ?>
											</span>
										</div>
										<div class="right">
											<h6><?php if(!empty($erps_manager['manager_tabtitle'])): echo esc_html($erps_manager['manager_tabtitle']); endif; ?></h6>
										</div>
									</div>
									<div class="accordion-answer">
										<p><?php if(!empty($erps_manager['manager_tabcont'])): echo esc_html($erps_manager['manager_tabcont']); endif; ?></p>
									</div>
								</li>
								<?php
								endforeach;
								endif; 
								?>
							</ul>
							<?php if(!empty($settings['manager_onebtn'])): ?>
								<a href="<?php echo esc_url($settings['manager_onebtnurl']); ?>" class="lab-btn">
									<span><?php echo esc_html($settings['manager_onebtn']); ?></span>
								</a>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
	</section>
	<?php elseif($choose_erpmanaer == 'hrmanager_two'): ?>
	<section class="erp-manager padding-tb">
			<div class="container">
				<div class="row flex-row-reverse">
					<div class="col-lg-6 col-12">
						<div class="lab-thumb">
							<div class="abs-lab-thumb pink">
								<span class="pluse_1"></span>
								<span class="pluse_2"></span>
								<?php if(!empty($settings['hr_one_smallimgs2']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['hr_one_smallimgs2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
							</div>
							<?php if(!empty($settings['hr_one_bigimgs2']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['hr_one_bigimgs2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="lab-content">
							<h2><?php if(!empty($settings['hr_manager_title1s2'])): echo esc_html($settings['hr_manager_title1s2']); endif; ?></h2>
							<p><?php if(!empty($settings['hr_manager_content1s2'])): echo esc_html($settings['hr_manager_content1s2']); endif; ?></p>
							<ul class="accordion">
								<?php 
								if(!empty($erps_managerss2)):
								foreach($erps_managerss2 as $erps_managerss):
								?>
								<li class="accordion-item">
									<div class="accordion-list">
										<div class="left">
											<span>
												<?php if(!empty($erps_managerss['manager_icons2']['url'])): ?>
													<img src="<?php echo wp_kses_post($erps_managerss['manager_icons2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
												<?php endif; ?>
											</span>
										</div>
										<div class="right">
											<h6><?php if(!empty($erps_managerss['manager_tabtitles2'])): echo esc_html($erps_managerss['manager_tabtitles2']); endif; ?></h6>
										</div>
									</div>
									<div class="accordion-answer">
										<p><?php if(!empty($erps_managerss['manager_tabconts2'])): echo esc_html($erps_managerss['manager_tabconts2']); endif; ?></p>
									</div>
								</li>
								<?php
								endforeach;
								endif; 
								?>
							</ul>
							<?php if(!empty($settings['manager_onebtns2'])): ?>
								<a href="<?php echo esc_url($settings['manager_onebtnurls2']); ?>" class="lab-btn">
									<span><?php echo esc_html($settings['manager_onebtns2']); ?></span>
								</a>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
	</section>	
	<?php elseif($choose_erpmanaer == 'hrmanager_three'): ?>
	<section class="erp-manager bgc-2 padding-tb">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-12">
						<div class="lab-thumb">
							<div class="abs-lab-thumb green">
								<span class="pluse_1"></span>
								<span class="pluse_2"></span>
								<?php if(!empty($settings['hr_one_smallimgs3']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['hr_one_smallimgs3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
							</div>
							<?php if(!empty($settings['hr_one_bigimgs3']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['hr_one_bigimgs3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="lab-content">
							<h2><?php if(!empty($settings['hr_manager_title1s3'])): echo esc_html($settings['hr_manager_title1s3']); endif; ?></h2>
							<p><?php if(!empty($settings['hr_manager_content1s3'])): echo esc_html($settings['hr_manager_content1s3']); endif; ?></p>
							<ul class="accordion">
								<?php 
								if(!empty($erps_managerss3)):
								foreach($erps_managerss3 as $erps_managersss):
								?>
								<li class="accordion-item">
									<div class="accordion-list">
										<div class="left">
											<span>
												<?php if(!empty($erps_managersss['manager_icons3']['url'])): ?>
													<img src="<?php echo wp_kses_post($erps_managersss['manager_icons3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
												<?php endif; ?>
											</span>
										</div>
										<div class="right">
											<h6><?php if(!empty($erps_managersss['manager_tabtitles3'])): echo esc_html($erps_managersss['manager_tabtitles3']); endif; ?></h6>
										</div>
									</div>
									<div class="accordion-answer">
										<p><?php if(!empty($erps_managersss['manager_tabconts3'])): echo esc_html($erps_managersss['manager_tabconts3']); endif; ?></p>
									</div>
								</li>
								<?php
								endforeach;
								endif; 
								?>
							</ul>
							<?php if(!empty($settings['manager_onebtns3'])): ?>
								<a href="<?php echo esc_url($settings['manager_onebtnurls3']); ?>" class="lab-btn">
									<span><?php echo esc_html($settings['manager_onebtns3']); ?></span>
								</a>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
	</section>	
	<?php elseif($choose_erpmanaer == 'hrmanager_four'): ?>
	<section class="erp-manager padding-tb">
			<div class="container">
				<div class="row flex-row-reverse">
					<div class="col-lg-6 col-12">
						<div class="lab-thumb">
							<div class="abs-lab-thumb pink">
									<span class="pluse_1"></span>
									<span class="pluse_2"></span>
								<?php if(!empty($settings['hr_one_smallimgs4']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['hr_one_smallimgs4']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
							</div>
							<?php if(!empty($settings['hr_one_bigimgs4']['url'])): ?>
								<img src="<?php echo wp_kses_post($settings['hr_one_bigimgs4']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="lab-content">
							<h2><?php if(!empty($settings['hr_manager_title1s4'])): echo esc_html($settings['hr_manager_title1s4']); endif; ?></h2>
							<p><?php if(!empty($settings['hr_manager_content1s4'])): echo esc_html($settings['hr_manager_content1s4']); endif; ?></p>
							<ul class="accordion">
								<?php 
								if(!empty($erps_managerss4)):
								foreach($erps_managerss4 as $erps_managerssss):
								?>
								<li class="accordion-item">
									<div class="accordion-list">
										<div class="left">
											<span>
												<?php if(!empty($erps_managerssss['manager_icons4']['url'])): ?>
													<img src="<?php echo wp_kses_post($erps_managerssss['manager_icons4']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
												<?php endif; ?>
											</span>
										</div>
										<div class="right">
											<h6><?php if(!empty($erps_managerssss['manager_tabtitles4'])): echo esc_html($erps_managerssss['manager_tabtitles4']); endif; ?></h6>
										</div>
									</div>
									<div class="accordion-answer">
										<p><?php if(!empty($erps_managerssss['manager_tabconts4'])): echo esc_html($erps_managerssss['manager_tabconts4']); endif; ?></p>
									</div>
								</li>
								<?php
								endforeach;
								endif; 
								?>
							</ul>
							<?php if(!empty($settings['manager_onebtns4'])): ?>
								<a href="<?php echo esc_url($settings['manager_onebtnurls4']); ?>" class="lab-btn">
									<span><?php echo esc_html($settings['manager_onebtns4']); ?></span>
								</a>
							<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
	</section>
	<?php
	endif;
	}



}





