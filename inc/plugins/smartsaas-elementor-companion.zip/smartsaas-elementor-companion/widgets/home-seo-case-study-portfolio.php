<?php
class Smartsass_CaseStudy_Portfolio extends \Elementor\Widget_Base {
	public function get_name() {
		return "case_studys";
	}

	public function get_title() {
		return __( "SEO CaseStudy", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'CaseStudy Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'case_title',[
				'label' => __( 'CaseStudy Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'case_stitle',[
				'label' => __( 'CaseStudy Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'case_count',[
				'label' => __( 'CaseStudy Count', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'case_bg',[
				'label' => __( 'CaseStudy Background', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$this->add_control(
			'case_btn',[
				'label' => __( 'CaseStudy Butotn', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'case_btnurl',[
				'label' => __( 'CaseStudy Butotn Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,

			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
	?>
	<!-- Recent Case Section Start Here -->
	<section class="recent-case padding-tb">
		<div class="pattern-img">
			<?php if(!empty($settings['case_bg']['url'])): ?>
				<img src="<?php echo wp_kses_post($settings['case_bg']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
			<?php endif; ?>
		</div>
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['case_title'])): echo esc_html($settings['case_title']); endif; ?></h2>
				<p><?php if(!empty($settings['case_stitle'])): echo esc_html($settings['case_stitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<?php 
				$case_study = new WP_Query(array(
					'post_type' 		=> 'portfolio',
					'posts_per_page'  	=> esc_attr($settings['case_count']),
                    'post_status'     	=> 'publish',
				));
				if ($case_study->have_posts()):
				 	while($case_study->have_posts()): 
				 	$case_study->the_post(); 

    	 		?>
				<div class="lab-item-3">
					<div class="lab-inner">
						<div class="lab-thumb">
							<?php
                            if ( has_post_thumbnail()): 
                              	the_post_thumbnail( ); 
                            endif; 
                            ?>
						</div>
						<div class="lab-content">
							<h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
							<span><?php echo get_the_term_list(get_the_ID(), 'Portfolio_cat', '', ', ', ''); ?></span>
						</div>
					</div>
				</div>
				<?php  
				endwhile;
				wp_reset_query(); 
				endif; 
				?>
			</div>
			<div class="text-center">
				<?php if(!empty($settings['case_btn'])): ?>
					<a href="<?php echo esc_url($settings['case_btnurl']['url']); ?>" class="lab-btn">
						<span><?php echo esc_html($settings['case_btn']);?></span>
					</a>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<!-- Recent Case Section Ending Here -->
	<?php
		
	}



}





