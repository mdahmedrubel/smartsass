<?php
class Smartsass_Home_Shopapp_Pricing_Plan extends \Elementor\Widget_Base {
	public function get_name() {
		return "shopapp_pricing";
	}

	public function get_title() {
		return __( "ShopApp Pricing", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Pricing Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'shopappp_title',[
				'label' => __( 'Pricing Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'shopappp_stitle',[
				'label' => __( 'Pricing Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'apppackage_name',[
				'label' => __( 'Package Name', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'apppackage_desc',[
				'label' => __( 'Package Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'apppackage_price',[
				'label' => __( 'Package Price', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'apppackage_duration',[
				'label' => __( 'Package Duration', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'apppackage_feature1',[
				'label' => __( 'Package Feature 1', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'apppackage_feature2',[
				'label' => __( 'Package Feature 2', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'apppackage_feature3',[
				'label' => __( 'Package Feature 3', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'apppackage_feature4',[
				'label' => __( 'Package Feature 4', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'appackage_feature5',[
				'label' => __( 'Package Feature 5', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'apppackage_btn',[
				'label' => __( 'Package Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'apppackage_url',[
				'label' => __( 'Package Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,

			]
		);
		$this->add_control(
			'shopapp_plans',
			[
				'label' => __( 'Pricing Plan Section', 'TEXT' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$shopapp_plans = $this->get_settings('shopapp_plans');
	?>
    <!-- Pricing Table Section Start Here -->
	<section class="pricing-table shopapp padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['shopappp_title'])): echo esc_html($settings['shopappp_title']); endif; ?></h2>
				<p><?php if(!empty($settings['shopappp_stitle'])): echo esc_html($settings['shopappp_stitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<?php 
				if(!empty($shopapp_plans)):
				foreach($shopapp_plans as $shopapps):
				?>
				<div class="pricing-item">
					<div class="pricing-inner">
						<div class="pricing-head">
							<h4><?php if(!empty($shopapps['apppackage_name'])): echo esc_html($shopapps['apppackage_name']); endif; ?></h4>
							<p><?php if(!empty($shopapps['apppackage_desc'])): echo esc_html($shopapps['apppackage_desc']); endif; ?></p>
						</div>
						<div class="pricing-body">
							<div class="price">
								<h2><?php if(!empty($shopapps['apppackage_price'])): echo esc_html($shopapps['apppackage_price']); endif; ?></h2>
								<p><?php if(!empty($shopapps['apppackage_duration'])): echo esc_html($shopapps['apppackage_duration']); endif; ?></p>
							</div>
							<div class="price-list">
								<ul>
									<?php if(!empty($shopapps['apppackage_feature1'])): ?>
										<li><?php echo esc_html($shopapps['apppackage_feature1']); ?></li>
									<?php endif; ?>
									<?php if(!empty($shopapps['apppackage_feature2'])): ?>
										<li><?php echo esc_html($shopapps['apppackage_feature2']); ?></li>
									<?php endif; ?>
									<?php if(!empty($shopapps['apppackage_feature3'])): ?>
										<li><?php echo esc_html($shopapps['apppackage_feature3']); ?></li>
									<?php endif; ?>
									<?php if(!empty($shopapps['apppackage_feature4'])): ?>
										<li><?php echo esc_html($shopapps['apppackage_feature4']); ?></li>
									<?php endif; ?>
									<?php if(!empty($shopapps['appackage_feature5'])): ?>
										<li><?php echo esc_html($shopapps['appackage_feature5']); ?></li>
									<?php endif; ?>
								</ul>
							</div>
							<div class="price-btn">
								<?php if(!empty($shopapps['apppackage_btn'])): ?>
									<a href="<?php echo esc_url($shopapps['apppackage_url']['url']); ?>" class="lab-btn"><span><?php echo esc_html($shopapps['apppackage_btn']); ?></span></a>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
				<?php
				endforeach;
				endif; 
				?>
			</div>
		</div>
	</section>
	<!-- Pricing Table Section Ending Here -->
	<?php
		
	}



}





