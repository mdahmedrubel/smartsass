<?php
class Smartsass_Portfolio_Style_One extends \Elementor\Widget_Base {
	public function get_name() {
		return "portfolio_one";
	}

	public function get_title() {
		return __( "Portfolio One", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Portfolio Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'portfolio1_count',[
				'label' => __( 'Portfolio Count', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'portfolio1_btn',[
				'label' => __( 'Portfolio One Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'portfolio1_btnurl',[
				'label' => __( 'Portfolio One Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);


		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		

	?>
	<!-- Recent Case Section Start Here -->
	<section class="portfolio-section padding-tb">
		<div class="container">
			<div class="section-wrapper">
	            <div class="row justify-content-center">

	            <?php  
				$portfolio_one = new WP_Query(
				    array(
				        'post_type'       => 'portfolio',
				        'post_status'     => 'publish',
				        'posts_per_page' => $settings['portfolio1_count'],
				        'order'       => 'ASC',
				        'orderby'       => 'rand',
				    )
				);

				if ( $portfolio_one->have_posts() ) :
				while ( $portfolio_one->have_posts() ):
	    		$portfolio_one->the_post();
				?>

	                <div class="col-xl-4 col-md-6 col-12">
	                    <div class="lab-item-3 port-item">
	                        <div class="lab-inner">
	                            <div class="lab-thumb">
	                                <?php
	                                $portfolio_thumb = get_the_post_thumbnail_url(get_the_ID(),"large");   
	                                ?>
	                                 <img src="<?php echo esc_url($portfolio_thumb); ?>" alt="<?php bloginfo('name'); ?>">
	                                <div class="port-share">
	                                    <a href="<?php the_permalink(); ?>"><i class="icofont-link-alt"></i></a>
	                                    <a href="<?php echo esc_url($portfolio_thumb); ?>"  data-rel="lightcase:myCollection"><i class="icofont-drag1"></i></a>
	                                </div>
	                            </div>
	                            <div class="lab-content">
	                                <h5><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h5>
	                                <span>
	                                	<?php echo get_the_term_list(get_the_ID(), 'Portfolio_cat', '', ', ', ''); ?>
	                                </span>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <?php 
					endwhile;
					wp_reset_query();  
					endif;
					?>
	            </div>
			</div>
			<div class="text-center">
				<?php if(!empty($settings['portfolio1_btn'])): ?>
				<div class="text-center">
					<a href="<?php echo esc_url($settings['portfolio1_btnurl']); ?>" class="lab-btn"><span><?php echo esc_html($settings['portfolio1_btn']); ?></span></a>
				</div>
				<?php endif; ?>
			</div>
		</div>
	</section>
	<!-- Recent Case Section Ending Here -->
	<?php
	}



}





