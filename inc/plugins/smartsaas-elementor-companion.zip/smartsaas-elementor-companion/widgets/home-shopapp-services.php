<?php
class Smartsaas_Home_Shopapp_Service extends \Elementor\Widget_Base {
	public function get_name() {
		return "shopapp_services";
	}

	public function get_title() {
		return __( "ShopApp Service", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Home Shopapp Service Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'select_appservice',[
				'label' => __( 'Select Shopapp Service', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'app-service1',
				'options' => [
					'app-service1' => __( 'Home App Service One', 'smartsaas' ),
					'app-service2' => __( 'Home App Service Two', 'smartsaas' ),
				],
			]
		);
		//servies one
		$this->add_control(
			'sappser_title',[
				'label' => __( 'Pos Service Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service1',
						]
					]
				]
			]
		);
		$this->add_control(
			'sappser_desc',[
				'label' => __( 'Pos Service Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Short Content', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service1',
						]
					]
				]
			]
		);
		$this->add_control(
			'sapp_services',[
				'label' => __( 'Pos Service Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service1',
						]
					]
				],
                'fields' => [
                    [
                        'name' => 'sapp_stitle',
                        'label' => esc_html__('Service Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		$this->add_control(
			'sapp_btn',[
				'label' => __( 'Service Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service1',
						]
					]
				]
			]
		);
		$this->add_control(
			'sapp_btnurl',[
				'label' => __( 'Service Button URl', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service1',
						]
					]
				]
			]
		);
		$this->add_control(
			'sapp_img',[
				'label' => __( 'Pos Service Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'placeholder' => __( 'Pos Service Image', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service1',
						]
					]
				]
			]
		);

		//servies Two
		$this->add_control(
			'sappser2_title',[
				'label' => __( 'Pos Service Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service2',
						]
					]
				]
			]
		);
		$this->add_control(
			'sappser2_desc',[
				'label' => __( 'Pos Service Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Short Content', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service2',
						]
					]
				]
			]
		);
		$this->add_control(
			'sapp2_services',[
				'label' => __( 'Pos Service Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service2',
						]
					]
				],
                'fields' => [
                    [
                        'name' => 'sapp2_stitle',
                        'label' => esc_html__('Service Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		$this->add_control(
			'sapp2_btn',[
				'label' => __( 'Service Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service2',
						]
					]
				]
			]
		);
		$this->add_control(
			'sapp2_btnurl',[
				'label' => __( 'Service Button URl', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service2',
						]
					]
				]
			]
		);
		$this->add_control(
			'sapp2_img',[
				'label' => __( 'Pos Service Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'placeholder' => __( 'Pos Service Image', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_appservice',
							'operator'  => '==',
							'value'  => 'app-service2',
						]
					]
				]
			]
		);
	$this->end_controls_section();

	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		$select_appservice = $this->get_settings('select_appservice');
	
	?>
	<?php if($select_appservice == 'app-service1'): ?> 
	<section class="shopapp-manager bgc-1 padding-tb">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-xl-6 col-12">
					<div class="lab-thumb wow fadeIn" data-wow-duration="1s" data-wow-delay=".2s">
						<?php if(!empty($settings['sapp_img']['url'])): ?>
                        	<img src="<?php echo wp_kses_post($settings['sapp_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
                		<?php endif; ?>
					</div>
				</div>
				<div class="col-xl-6 col-12">
					<div class="lab-content">
						<h2><?php if(!empty($settings['sappser_title'])): echo esc_html($settings['sappser_title']); endif; ?></h2>
						<p><?php if(!empty($settings['sappser_desc'])): echo esc_html($settings['sappser_desc']); endif; ?></p>
	                    <ul>
	                    	<?php 
			            	if(!empty($settings['sapp_services'])):
			            	foreach($settings['sapp_services'] as $sapps):
			            	?>
	                        <li>
	                        	<i class="icofont-tick-mark"></i>
	                        	<?php if(!empty($sapps['sapp_stitle'])): echo esc_html($sapps['sapp_stitle']); endif; ?> 
	                        </li>
	                        <?php 
			            	endforeach;
			            	endif;
			                ?>
	                    </ul>
						<?php if(!empty($settings['sapp_btn'])): ?>
                        	<a href="<?php echo esc_url($settings['sapp_btnurl']['url']); ?>" class="lab-btn"><span><?php echo esc_html($settings['sapp_btn']); ?></span></a>
                        <?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($select_appservice == 'app-service2'): ?> 
	<section class="shopapp-manager padding-tb">
		<div class="container">
			<div class="row flex-row-reverse align-items-center">
				<div class="col-xl-6 col-12">
					<div class="lab-thumb wow fadeIn" data-wow-duration="1s" data-wow-delay=".2s">
						<?php if(!empty($settings['sapp2_img']['url'])): ?>
                        	<img src="<?php echo wp_kses_post($settings['sapp2_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
                		<?php endif; ?>
					</div>
				</div>
				<div class="col-xl-6 col-12">
					<div class="lab-content">
						<h2><?php if(!empty($settings['sappser2_title'])): echo esc_html($settings['sappser2_title']); endif; ?></h2>
						<p><?php if(!empty($settings['sappser2_desc'])): echo esc_html($settings['sappser2_desc']); endif; ?></p>
	                    <ul>
	                    	<?php 
			            	if(!empty($settings['sapp2_services'])):
			            	foreach($settings['sapp2_services'] as $sappstwo):
			            	?>
	                        <li>
	                        	<i class="icofont-tick-mark"></i>
	                        	<?php if(!empty($sappstwo['sapp2_stitle'])): echo esc_html($sappstwo['sapp2_stitle']); endif; ?> 
	                        </li>
	                        <?php 
			            	endforeach;
			            	endif;
			                ?>
	                    </ul>
						<?php if(!empty($settings['sapp2_btn'])): ?>
                        	<a href="<?php echo esc_url($settings['sapp2_btnurl']['url']); ?>" class="lab-btn"><span><?php echo esc_html($settings['sapp2_btn']); ?></span></a>
                        <?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php
	endif;
	}



}


