<?php
class Smartsaas_Banner_Two_Extension extends \Elementor\Widget_Base {
	public function get_name() {
		return "smartsaas_banner_two";
	}

	public function get_title() {
		return __( "Smartsaas Banner Two", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Smartsaas Banner Two Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'select_banner',[
				'label' => __( 'Select Banner', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'home-pos',
				'options' => [
					'home-pos' => __( 'Home Pos', 'smartsaas' ),
					'home-marketing' => __( 'Home Marketing', 'smartsaas' ),
					'home-shopapp' => __( 'Home Shopapp', 'smartsaas' ),
					'home-crypto' => __( 'Home Crypto', 'smartsaas' ),
				],
			]
		);

		//pos banner controlls
		$this->add_control(
			'posbanner_title',[
				'label' => __( 'Banner Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your title here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);
		$this->add_control(
			'posbanner_desc',[
				'label' => __( 'Banner Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Banner discripion', 'smartsaas' ),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);
		$this->add_control(
			'posbutton_text',[
				'label' => __( 'Banner Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);
		$this->add_control(
			'posbutton_url',[
				'label' => __( 'Banner Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);
		$this->add_control(
			'posbanner_img',[
				'label' => __( 'Add Banner Fixed Left Shape One', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);
		$this->add_control(
			'posbanner_img1',[
				'label' => __( 'Add Banner Fixed Shape Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);
		$this->add_control(
			'posbanner_img2',[
				'label' => __( 'Right Curv Shape  Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);
		$this->add_control(
			'posbanner_img3',[
				'label' => __( 'Moving Girl Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);
		$this->add_control(
			'posbanner_img4',[
				'label' => __( 'Moving Top Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);
		$this->add_control(
			'posbanner_img5',[
				'label' => __( 'Moving Top Right Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-pos',
						]
					]
				]
			]
		);

		//Marketing banner controlls
		$this->add_control(
			'mrkbanner_title',[
				'label' => __( 'Banner Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your title here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]
			]
		);
		$this->add_control(
			'mrkbanner_desc',[
				'label' => __( 'Banner Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Banner discripion', 'smartsaas' ),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]
			]
		);
		$this->add_control(
			'mrkbutton_text',[
				'label' => __( 'Banner Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]
			]
		);
		$this->add_control(
			'mrkbutton_url',[
				'label' => __( 'Banner Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]
			]
		);
		$this->add_control(
			'mrkbanner_img',[
				'label' => __( 'Pos Banner Big Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]
			]
		);
		$this->add_control(
			'mrkbanner_img1',[
				'label' => __( 'Moving Comment Image Left', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]
			]
		);
		$this->add_control(
			'mrkbanner_img2',[
				'label' => __( 'Moving Comment Image Middle', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]
			]
		);
		$this->add_control(
			'mrkbanner_img3',[
				'label' => __( 'Moving Comment Image Right', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]
			]
		);
		$this->add_control(
			'mrkbanner_img4',[
				'label' => __( 'Moving Tree Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-marketing',
						]
					]
				]
			]
		);

		//Shopapp banner controlls
		$this->add_control(
			'appbanner_title',[
				'label' => __( 'Banner Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your title here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]
			]
		);
		$this->add_control(
			'appbanner_title2',[
				'label' => __( 'Banner Title Part Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your title here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]
			]
		);
		$this->add_control(
			'appbanner_desc',[
				'label' => __( 'Banner Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Banner discripion', 'smartsaas' ),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]
			]
		);
		$this->add_control(
			'appbutton_text',[
				'label' => __( 'Banner Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]
			]
		);
		$this->add_control(
			'appbutton_url',[
				'label' => __( 'Banner Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]
			]
		);
		$this->add_control(
			'appbanner_img',[
				'label' => __( 'Pos Banner Big Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]
			]
		);
		$this->add_control(
			'appbanner_img1',[
				'label' => __( 'Moving Cart Top Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]
			]
		);
		$this->add_control(
			'appbanner_img2',[
				'label' => __( 'Moving Box Left Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]
			]
		);
		$this->add_control(
			'appbanner_img3',[
				'label' => __( 'Moving Bottom Image Right', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-shopapp',
						]
					]
				]
			]
		);

		//Crypto banner controlls
			$this->add_control(
			'cryp_banner_shape',[
				'label' => __( 'Banner Shape Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				]
			]
		);
		$this->add_control(
			'crypbanner_title',[
				'label' => __( 'Banner Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your title here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				]
			]
		);
		$this->add_control(
			'crypbanner_desc',[
				'label' => __( 'Banner Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Banner discripion', 'smartsaas' ),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				]
			]
		);
		$this->add_control(
			'crypto_shortcode',[
				'label' => __( 'Banner Shortcode For Register', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Shortcode For Register', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				]
			]
		);

		$this->add_control(
			'regester_bottom',[
				'label' => __( 'Register Bottom Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'register bottom text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				]
			]
		);
		$this->add_control(
			'get_in_touch',[
				'label' => __( 'Get In Touch Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'get in touch text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				]
			]
		);
		$this->add_control(
			'get_in_touchurl',[
				'label' => __( 'Get In Touch Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'get in touch url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				]
			]
		);

		$this->add_control(
			'crypbanner_img',[
				'label' => __( 'Ctypto Banner Right Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				]
			]
		);
		$this->add_control(
			'index_text',[
				'label' => __( 'Index Found Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'index text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				]
			]
		);
		//group settings
		$this->add_control(
			'banner_bottoms',[
				'label' => __( 'Banner Bottom Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_banner',
							'operator'  => '==',
							'value'  => 'home-crypto',
						]
					]
				],
                'fields' => [
                    [
                        'name' => 'bb_title',
                        'label' => esc_html__('Banner bottom title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'bb_amount',
                        'label' => esc_html__('Bottom amount', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'bb_percent',
                        'label' => esc_html__('Bottom percent amount', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);

	$this->end_controls_section();

	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		$select_banner = $this->get_settings('select_banner');
		$banner_bottoms = $this->get_settings('banner_bottoms');
	
	?>
	<?php if($select_banner == 'home-pos'): ?>
	<section class="banner-section style-5">
	    <div class="pos-banner-shape">
	        <div class="pos-shape-1">
	            <?php if(!empty($settings['posbanner_img']['url'])): ?>
					<img src="<?php echo wp_kses_post($settings['posbanner_img']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
				<?php endif; ?>
	        </div>
	        <div class="pos-shape-2">
	        	<?php if(!empty($settings['posbanner_img2']['url'])): ?>
					<img src="<?php echo wp_kses_post($settings['posbanner_img2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
				<?php endif; ?>
	        </div>
	    </div>
		<div class="banner-area">
			<div class="container">
				<div class="row no-gutters align-items-center">
					<div class="col-xl-6 col-12">
						<div class="content-part">
							<div class="section-header style-2">
								<h2><?php if(!empty($settings['posbanner_title'])): echo esc_html($settings['posbanner_title']); endif; ?></h2>
								<p><?php if(!empty($settings['posbanner_desc'])): echo esc_html($settings['posbanner_desc']); endif; ?></p>
								<?php  if(!empty($settings['posbutton_text'])): ?>
		                            <a href="<?php echo esc_url($settings['posbutton_url']); ?>" class="lab-btn">
		                            	<span><?php echo esc_html($settings['posbutton_text']); ?></span>
		                            </a>
	                            <?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-xl-6 col-12">
						<div class="section-wrapper">
							<div class="banner-thumb">
								<?php if(!empty($settings['posbanner_img1']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['posbanner_img1']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
	                            <div class="thumb-shape">
									<div class="th-shape th-shape-1">
										<?php if(!empty($settings['posbanner_img4']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['posbanner_img4']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-2">
										<?php if(!empty($settings['posbanner_img5']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['posbanner_img5']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-3">
										<?php if(!empty($settings['posbanner_img3']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['posbanner_img3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($select_banner == 'home-marketing'): ?>
	<section class="banner-section style-6">
		<div class="banner-area">
			<div class="container">
				<div class="row no-gutters align-items-center">
					<div class="col-lg-6 col-12">
						<div class="content-part">
							<div class="section-header style-2">
								<h2><?php if(!empty($settings['mrkbanner_title'])): echo esc_html($settings['mrkbanner_title']); endif; ?></h2>
								<p><?php if(!empty($settings['mrkbanner_desc'])): echo esc_html($settings['mrkbanner_desc']); endif; ?></p>
	                            <?php  if(!empty($settings['mrkbutton_text'])): ?>
		                            <a href="<?php echo esc_url($settings['mrkbutton_url']); ?>" class="lab-btn">
		                            	<span><?php echo esc_html($settings['mrkbutton_text']); ?></span>
		                            </a>
	                            <?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="section-wrapper">
							<div class="banner-thumb">
	                            <?php if(!empty($settings['mrkbanner_img']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['mrkbanner_img']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
	                            <div class="thumb-shape">
									<div class="th-shape th-shape-1">
										<?php if(!empty($settings['mrkbanner_img1']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['mrkbanner_img1']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-2">
										<?php if(!empty($settings['mrkbanner_img3']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['mrkbanner_img3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-3">
										<?php if(!empty($settings['mrkbanner_img2']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['mrkbanner_img2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-4">
										<?php if(!empty($settings['mrkbanner_img4']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['mrkbanner_img4']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($select_banner == 'home-shopapp'): ?>
	<section class="banner-section style-6 shopapp">
		<div class="banner-area">
			<div class="container">
				<div class="row no-gutters align-items-center">
					<div class="col-lg-6 col-12">
						<div class="content-part">
							<div class="section-header style-2">
		                        <h2><?php if(!empty($settings['appbanner_title'])): echo esc_html($settings['appbanner_title']); endif; ?></h2>
		                        <h2><?php if(!empty($settings['appbanner_title2'])): echo esc_html($settings['appbanner_title2']); endif; ?></h2>
								<p><?php if(!empty($settings['appbanner_desc'])): echo esc_html($settings['appbanner_desc']); endif; ?></p>
		                        <?php  if(!empty($settings['appbutton_text'])): ?>
		                            <a href="<?php echo esc_url($settings['appbutton_url']); ?>" class="lab-btn">
		                            	<span><?php echo esc_html($settings['appbutton_text']); ?></span>
		                            </a>
	                            <?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="section-wrapper">
							<div class="banner-thumb">
		                        <?php if(!empty($settings['appbanner_img']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['appbanner_img']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
		                        <div class="thumb-shape">
									<div class="th-shape th-shape-1">
										<?php if(!empty($settings['appbanner_img2']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['appbanner_img2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-2">
										<?php if(!empty($settings['appbanner_img1']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['appbanner_img1']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-3">
										<?php if(!empty($settings['appbanner_img3']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['appbanner_img3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($select_banner == 'home-crypto'): ?>
	<section class="banner-section style-6 crypto crypto-bg">
		<div class="round-one d-none d-lg-block">
		    <?php if(!empty($settings['cryp_banner_shape']['url'])): ?>
            	<img src="<?php echo wp_kses_post($settings['cryp_banner_shape']['url']); ?>" alt="<?php bloginfo('name'); ?>">
    		<?php endif; ?>
		</div>
		<div class="lines">
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		    <div class="line"></div>
		</div>
		<div class="banner-area">
		    <div class="container">
		        <div class="row no-gutters align-items-center">
		            <div class="col-lg-6 col-12">
		                <div class="content-part">
		                    <div class="section-header style-2">
		                        <h2><?php if(!empty($settings['crypbanner_title'])): echo esc_html($settings['crypbanner_title']); endif; ?></h2>
		                        <p><?php if(!empty($settings['crypbanner_desc'])): echo esc_html($settings['crypbanner_desc']); endif; ?></p>

		                        	<?php 
		                        	if(!empty($settings['crypto_shortcode'])):
		                        		echo do_shortcode($settings['crypto_shortcode']);
		                        	endif;
		                        	?>

		                        <p class="mtops"><?php if(!empty($settings['regester_bottom'])): echo esc_html($settings['regester_bottom']); endif; ?> <a href="<?php if(!empty($settings['get_in_touchurl'])): echo esc_html($settings['get_in_touchurl']); endif; ?>"><?php if(!empty($settings['get_in_touch'])): echo esc_html($settings['get_in_touch']); endif; ?></a></p>
		                    </div>
		                </div>
		            </div>
		            <div class="col-lg-6 col-12">
		                <div class="section-wrapper">
		                    <div class="banner-thumb text-center">
		                        <?php if(!empty($settings['crypbanner_img']['url'])): ?>
					            	<img src="<?php echo wp_kses_post($settings['crypbanner_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
					    		<?php endif; ?> 
		                    </div>
		                </div>
		            </div>
		            <div class="col-lg-4 col-12">
		                <div class="bfl-content">
		                    <h4><?php if(!empty($settings['index_text'])): echo esc_html($settings['index_text']); endif; ?></h4>
		                </div>
		            </div>
		            <div class="col-lg-8 col-12">
		                <div class="bfr-contents">
		                	<?php 
			            	if(!empty($banner_bottoms)):
			            	foreach($banner_bottoms as $b_bottom):
			            	?>
		                    <div class="bfr-item">
		                        <div class="bfr-inner">
		                            <div class="bfr-content">
		                                <p class="bfr-name"><?php if(!empty($b_bottom['bb_title'])): echo esc_html($b_bottom['bb_title']); endif; ?></p>
		                                <p class="bfr-rate"><?php if(!empty($b_bottom['bb_amount'])): echo esc_html($b_bottom['bb_amount']); endif; ?></p>
		                                <p class="bfr-range"><?php if(!empty($b_bottom['bb_percent'])): echo esc_html($b_bottom['bb_percent']); endif; ?></p>
		                            </div>
		                        </div>
		                    </div>
		                    <?php 
			            	endforeach;
			            	endif;
			                ?>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>
	</section>
	<?php
	endif;
	}



}


