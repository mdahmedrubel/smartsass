<?php
class Smartsass_Comming_Soon_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "comming_soon";
	}

	public function get_title() {
		return __( "Comming Soon", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Comming Soom Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'cm_title',[
				'label' => __( 'Comming Soon Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cm_desc',[
				'label' => __( 'Comming Soon Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cm_date',[
				'label' => __( 'Comming Soon Date', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background',
				'label' => __( 'Newsletter Background', 'smartsaas' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .coming-soon',
			]
		);
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

	?>
	<div class="coming-soon">
		<div class="container">
		    <div class="coming-content-area m-top">
		    	<?php if(!empty($settings['cm_title'])): ?>
		        	<h2><?php echo esc_html($settings['cm_title']); ?></h2>
		        <?php endif;  ?>
		        <?php if(!empty($settings['cm_desc'])): ?>
		        	<p><?php echo esc_html($settings['cm_desc']); ?></p>
		        <?php endif;  ?>

	        	<ul class="countdown eventdate" data-date="<?php if(!empty($settings['cm_date'])): echo esc_attr($settings['cm_date']); endif; ?>">
	                <li class="clock-item">
	                    <div class="count-number days"><?php esc_html_e('0', 'smartsaas'); ?></div>
	                	<div class="days_text count-text"><?php esc_html_e('Days', 'smartsaas'); ?></div>
	                </li>
	                <li class="clock-item">
	                    <div class="count-number hours"><?php esc_html_e('09', 'smartsaas'); ?></div>
	                	<div class="hours_text count-text"><?php esc_html_e('Hours', 'smartsaas'); ?></div>
	                </li>
	                <li class="clock-item">
	                    <div class="count-number minutes"><?php esc_html_e('10', 'smartsaas'); ?></div>
	                	<div class="minutes_text count-text"><?php esc_html_e('Minutes', 'smartsaas'); ?></div>
	                </li>
	                <li class="clock-item">
	                    <div class="count-number seconds"><?php esc_html_e('27', 'smartsaas'); ?></div>
	                	<div class="seconds_text count-text"><?php esc_html_e('Seconds', 'smartsaas'); ?></div>
	                </li>
	            </ul>
	            
		    </div>
		</div>
	</div>
	<?php
	}

}





