<?php
class Smartsass_Seo_Customer_LoveUs extends \Elementor\Widget_Base {
	public function get_name() {
		return "customer_love";
	}

	public function get_title() {
		return __( "Customer Review", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Seo Customer Review Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'customer_review',[
				'label' => __( 'Select Review Style', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'style-one',
				'options' => [
					'style-one'  => __( 'Customer Review One', 'smartsaas' ),
					'style-two' => __( 'Customer Review Two', 'smartsaas' ),
				],
			]
		);

		//Customers Love Us style one
		$this->add_control(
			'customer_revtitle',[
				'label' => __( 'Seo Customer Review Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'customer_review',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]

			]
		);
		$this->add_control(
			'customer_revstitle',[
				'label' => __( 'Seo Customer Review Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'customer_review',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]

			]
		);
		$this->add_control(
			'client_groups',[
				'label' => __( 'Seo Client Revies', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'customer_review',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				],
                'fields' => [
                     [
                        'name' => 'seoclient_content',
                        'label' => esc_html__('Client Content', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ], 
                    [
                        'name' => 'seoclient_name',
                        'label' => esc_html__('Client Name', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'seoclient_designation',
                        'label' => esc_html__('Client Designation', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
						'name' => 'select_rating',
						'label' => __( 'Select Ratings', 'smartsaas' ),
						'type' => \Elementor\Controls_Manager::SELECT,
						'default' => 'rating5',
						'label_block' => true,
						'options' => [
							'rating1'  => __( 'One Star', 'smartsaas' ),
							'rating2'  => __( 'Two Star', 'smartsaas' ),
							'rating3'  => __( 'Three Star', 'smartsaas' ),
							'rating4'  => __( 'Four Star', 'smartsaas' ),
							'rating5'  => __( 'Five Star', 'smartsaas' ),
						],
					],
      
                    [
                        'name' => 'seoclient_thumb',
                        'label' => esc_html__('Client Image', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                    ],
                ],
                
			]
		);

		//Customers Love Us style two
		$this->add_control(
			'customer_revtitle2',[
				'label' => __( 'Seo Customer Review Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'customer_review',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]

			]
		);
		$this->add_control(
			'customer_revstitle2',[
				'label' => __( 'Seo Customer Review Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'customer_review',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]

			]
		);
		$this->add_control(
			'client2_groups',[
				'label' => __( 'Seo Client Revies', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'customer_review',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				],
                'fields' => [
                     [
                        'name' => 'seoclient_content2',
                        'label' => esc_html__('Client Content', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ], 
                    [
                        'name' => 'seoclient_name2',
                        'label' => esc_html__('Client Name', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'seoclient_designation2',
                        'label' => esc_html__('Client Designation', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
						'name' => 'select_rating2',
						'label' => __( 'Select Ratings', 'smartsaas' ),
						'type' => \Elementor\Controls_Manager::SELECT,
						'default' => 'rating55',
						'label_block' => true,
						'options' => [
							'rating11'  => __( 'One Star', 'smartsaas' ),
							'rating22'  => __( 'Two Star', 'smartsaas' ),
							'rating33'  => __( 'Three Star', 'smartsaas' ),
							'rating44'  => __( 'Four Star', 'smartsaas' ),
							'rating55'  => __( 'Five Star', 'smartsaas' ),
						],
					],
      
                    [
                        'name' => 'seoclient_thumb2',
                        'label' => esc_html__('Client Image', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                    ],
                ],
                
			]
		);
		

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$client_groups = $this->get_settings('client_groups');
		$client2_groups = $this->get_settings('client2_groups');
		$customer_review = $this->get_settings('customer_review');
	?>
	<?php if($customer_review == 'style-one'): ?>
	<!-- Clients Section Start Here -->
	<section class="clints-section padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['customer_revtitle'])): echo esc_html($settings['customer_revtitle']); endif; ?></h2>
				<p><?php if(!empty($settings['customer_revstitle'])): echo esc_html($settings['customer_revstitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<div class="clients">
					<?php 
	            	if(!empty($client_groups)):
	            	$client_count = 0;
	            	foreach($client_groups as $client_group):
	            	$client_count++;
	            	?>
					<div class="client-list">
						<div class="client-content">
							<p><?php if(!empty($client_group['seoclient_content'])): echo esc_html($client_group['seoclient_content']); endif; ?></p>
							<div class="client-info">
								<div class="name-desi">
									<h6><?php if(!empty($client_group['seoclient_name'])): echo esc_html($client_group['seoclient_name']); endif; ?></h6>
									<span><?php if(!empty($client_group['seoclient_designation'])): echo esc_html($client_group['seoclient_designation']); endif; ?></span>
								</div>
								<div class="rating">
									<ul>
										<?php if($client_group['select_rating'] == 'rating1'): ?>
											<li><i class="icofont-star"></i></li>
										<?php endif; ?>
										<?php if($client_group['select_rating'] == 'rating2'): ?>
											<li><i class="icofont-star"></i><i class="icofont-star"></i></li>
										<?php endif; ?>
										<?php if($client_group['select_rating'] == 'rating3'): ?>
											<li><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i></li>
										<?php endif; ?>
										<?php if($client_group['select_rating'] == 'rating4'): ?>
											<li><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i></li>
										<?php endif; ?>
										<?php if($client_group['select_rating'] == 'rating5'): ?>
											<li><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i></li>
										<?php endif; ?>
									</ul>
								</div>
							</div>
						</div>
						<div class="client-thumb">
							<?php if(!empty($client_group['seoclient_thumb']['url'])): ?>
								<img src="<?php echo wp_kses_post($client_group['seoclient_thumb']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
					</div>
					<?php 
	                if($client_count == 7){
	                	break;
	                }
	            	endforeach;
	            	endif;
	                ?>
				</div>
			</div>
		</div>
	</section>
	<!-- Clients Section Ending Here -->
	<?php elseif($customer_review == 'style-two'): ?>
	<!-- Clients Section Start Here -->
	<section class="clints-section bg-color padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['customer_revtitle2'])): echo esc_html($settings['customer_revtitle2']); endif; ?></h2>
				<p><?php if(!empty($settings['customer_revstitle2'])): echo esc_html($settings['customer_revstitle2']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<div class="clients">
					<?php
					if(!empty($client2_groups)): 
					foreach($client2_groups as $client2_group):
					?>
					<div class="client-list active">
						<div class="client-content">
							<p><?php if(!empty($client2_group['seoclient_content2'])): echo esc_html($client2_group['seoclient_content2']); endif; ?></p>
							<div class="client-info">
								<div class="name-desi">
									<h6><?php if(!empty($client2_group['seoclient_name2'])): echo esc_html($client2_group['seoclient_name2']); endif; ?></h6>
									<span><?php if(!empty($client2_group['seoclient_designation2'])): echo esc_html($client2_group['seoclient_designation2']); endif; ?></span>
								</div>
								<div class="rating">
									<ul>
										<?php if($client2_group['select_rating2'] == 'rating11'): ?>
											<li><i class="icofont-star"></i></li>
										<?php endif; ?>
										<?php if($client2_group['select_rating2'] == 'rating22'): ?>
											<li><i class="icofont-star"></i><i class="icofont-star"></i></li>
										<?php endif; ?>
										<?php if($client2_group['select_rating2'] == 'rating33'): ?>
											<li><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i></li>
										<?php endif; ?>
										<?php if($client2_group['select_rating2'] == 'rating44'): ?>
											<li><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i></li>
										<?php endif; ?>
										<?php if($client2_group['select_rating2'] == 'rating55'): ?>
											<li><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i><i class="icofont-star"></i></li>
										<?php endif; ?>
									</ul>
								</div>
							</div>
						</div>
						<div class="client-thumb">
							<?php if(!empty($client2_group['seoclient_thumb2']['url'])): ?>
								<img src="<?php echo wp_kses_post($client2_group['seoclient_thumb2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
						</div>
					</div>
					<?php 
					endforeach;
					endif;
					?>
				</div>
			</div>
		</div>
	</section>
	<!-- Clients Section Ending Here -->

	<?php
	endif;	
	}



}





