<?php
class Smartsass_Crypto_Blog_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "crypto_blog";
	}

	public function get_title() {
		return __( "Crypto Blog", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Crypto Blog Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'crypblog_title',[
				'label' => __( 'Crypto Blog Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypblog_stitle',[
				'label' => __( 'Crypto Blog Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypblog_count',[
				'label' => __( 'Crypto Blog Post Count', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypblog_btntxt',[
				'label' => __( 'Crypto Blog Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'cryppblog_btnurl',[
				'label' => __( 'Crypto Blog Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		$cryp_blog = new WP_Query(
		    array(
		        'post_type'       => 'post',
		        'post_status'     => 'publish',
		        'posts_per_page' => $settings['crypblog_count'],
		        'ignore_sticky_posts' => 1
		    )
		);
	?>
	<!-- Blog Section Start Here -->
	<section class="blog-section crypto crypto-bg padding-tb">
	    <div class="lines">
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	    </div>
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['crypblog_title'])): echo esc_html($settings['crypblog_title']); endif; ?></h2>
				<p><?php if(!empty($settings['crypblog_stitle'])): echo esc_html($settings['crypblog_stitle']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	            <div class="row justify-content-center">
	            	<?php 
					while ( $cryp_blog->have_posts() ):
		    		$cryp_blog->the_post();
					?>
	                <div class="col-lg-4 col-sm-6 col-12">
	                    <div class="post-item">
	                        <div class="post-item-inner">
	                            <div class="post-thumb">
	                                <?php
									 $cryp_thumb =  get_the_post_thumbnail_url(get_the_ID(),"large"); 
									 if(!empty($cryp_thumb)):
									?>
									<a href="<?php the_permalink(); ?>">
										<img src="<?php echo esc_url($cryp_thumb); ?>" alt="<?php bloginfo('name'); ?>">
									</a>
									<?php endif; ?>
	                                <div class="author-comment">
	                                    <a href="<?php the_permalink(); ?>">
	                                    	<?php echo get_avatar( get_the_author_meta( 'ID' ) , 32 ); ?>
	                                    	<?php echo get_the_author_meta( 'display_name' ); ?>	
	                                    </a>
	                                    <div class="comments">
	                                    	<i class="fa fa-comments"></i>
	                                    	<?php
											  comments_popup_link( 'No comment', '1 comment', '% comments', 'comments-link', 'Comments off');
											?>
	                                    </div>
	                                </div>
	                            </div>
	                            <div class="post-content">
	                                <h5>
	                                	<a href="<?php the_permalink(); ?>">
											<?php
											$title = get_the_title();
											$short_title = wp_trim_words( $title, 3, ' ...' );
											echo $short_title;
											?>
										</a>
	                                </h5>
	                                <div class="entry-meta">
	                                    <a href="<?php the_permalink(); ?>" class="date"><?php echo get_the_date('j F, Y') ?></a>
	                                </div>
	                            </div>
	                        </div>
	                    </div>
	                </div>
	                <?php 
					endwhile;
					wp_reset_query();  
					?>
	                <div class="col-12 text-center">
						<?php  if(!empty($settings['crypblog_btntxt'])): ?>
							<a href="<?php echo esc_url($settings['cryppblog_btnurl']); ?>" class="lab-btn"><span><?php echo esc_html($settings['crypblog_btntxt']); ?></span>
							</a>
						<?php endif;  ?>
					</div>
	            </div>
	        </div>
	    </div>
	</section>
	<!-- Blog Section Ending Here -->
	<?php
	}

}





