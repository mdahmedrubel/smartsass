<?php
class Smartsaas_Home_Marketing_We_Do extends \Elementor\Widget_Base {
	public function get_name() {
		return "marketing_we_do";
	}

	public function get_title() {
		return __( "Marketing What We Do", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Marketing What We Do Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'select_whatwe',[
				'label' => __( 'Select What We Do Style', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'style-one',
				'options' => [
					'style-one'  => __( 'Style One', 'smartsaas' ),
					'style-two' => __( 'Style Two', 'smartsaas' ),
				],
			]
		);
		//style one
		$this->add_control(
			'mark_title',[
				'label' => __( 'Section Short Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_whatwe',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);
		$this->add_control(
			'mark_desc',[
				'label' => __( 'Section Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Short Content', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_whatwe',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				]
			]
		);
		$this->add_control(
			'what_wedoes',[
				'label' => __( 'Marketing What We Do Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_whatwe',
							'operator'  => '==',
							'value'  => 'style-one',
						]
					]
				],
                'fields' => [
                	[
                        'name' => 'mkt_icon',
                        'label' => esc_html__('What We Do Image', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                    ],
                    [
                        'name' => 'mkt_title',
                        'label' => esc_html__('What We Do Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'mkt_sdesc',
                        'label' => esc_html__('What We Do Short Content', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                    
                ],
                
			]
		);

		//style two
		$this->add_control(
			'mark_title2',[
				'label' => __( 'Section Short Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_whatwe',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);
		$this->add_control(
			'mark_desc2',[
				'label' => __( 'Section Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Short Content', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_whatwe',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				]
			]
		);
		$this->add_control(
			'what_wedoes2',[
				'label' => __( 'Marketing What We Do Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_whatwe',
							'operator'  => '==',
							'value'  => 'style-two',
						]
					]
				],
                'fields' => [
                	[
                        'name' => 'mkt_icon2',
                        'label' => esc_html__('What We Do Image', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                    ],
                    [
                        'name' => 'mkt_title2',
                        'label' => esc_html__('What We Do Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'mkt_sdesc2',
                        'label' => esc_html__('What We Do Short Content', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                    
                ],
                
			]
		);


	$this->end_controls_section();

	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		$what_wedoes = $this->get_settings('what_wedoes');
		$what_wedoes2 = $this->get_settings('what_wedoes2');
		$select_whatwe = $this->get_settings('select_whatwe');
	
	?>
	<?php if($select_whatwe == 'style-one'): ?>
	<section class="about-section style-2 style-3 style-4 padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <span><?php if(!empty($settings['mark_title'])): echo esc_html($settings['mark_title']); endif; ?></span>
	            <h2><?php if(!empty($settings['mark_desc'])): echo esc_html($settings['mark_desc']); endif; ?></h2>
	        </div>
	        <div class="section-wrapper">
	        	<?php 
            	if(!empty($what_wedoes)):
            	foreach($what_wedoes as $what_wedo):
            	?>
	            <div class="lab-item">
	                <div class="lab-inner">
	                    <div class="lab-thumb">
	                        <?php if(!empty($what_wedo['mkt_icon']['url'])): ?>
	                        	<img src="<?php echo wp_kses_post($what_wedo['mkt_icon']['url']); ?>" alt="<?php bloginfo('name'); ?>">
	                		<?php endif; ?>
	                    </div>
	                    <div class="lab-content">
	                        <h4><?php if(!empty($what_wedo['mkt_title'])): echo esc_html($what_wedo['mkt_title']); endif; ?></h4>
	                        <p><?php if(!empty($what_wedo['mkt_sdesc'])): echo esc_html($what_wedo['mkt_sdesc']); endif; ?></p>
	                    </div>
	                </div>
	            </div>
	            <?php 
            	endforeach;
            	endif;
                ?> 
	        </div>
	    </div>
	</section>
	<?php elseif($select_whatwe == 'style-two'): ?>
	<div class="service-pricing padding-tb">
	    <section class="service-section style-2 style-6">
	        <div class="container">
	            <div class="section-header">
	                <span><?php if(!empty($settings['mark_title2'])): echo esc_html($settings['mark_title2']); endif; ?></span>
	            	<h2><?php if(!empty($settings['mark_desc2'])): echo esc_html($settings['mark_desc2']); endif; ?></h2>
	            </div>
	            <div class="section-wrapper">
	            	<?php 
	            	if(!empty($what_wedoes2)):
	            	foreach($what_wedoes2 as $what_we):
	            	?>
	                <div class="lab-item">
	                    <div class="lab-inner">
	                        <div class="lab-thumb">
	                            <?php if(!empty($what_we['mkt_icon2']['url'])): ?>
		                        	<img src="<?php echo wp_kses_post($what_we['mkt_icon2']['url']); ?>" alt="<?php bloginfo('name'); ?>">
		                		<?php endif; ?>
	                        </div>
	                        <div class="lab-content">
	                            <h4><?php if(!empty($what_we['mkt_title2'])): echo esc_html($what_we['mkt_title2']); endif; ?></h4>
	                        	<p><?php if(!empty($what_we['mkt_sdesc2'])): echo esc_html($what_we['mkt_sdesc2']); endif; ?></p>
	                        </div>
	                    </div>
	                </div>
	                <?php 
	            	endforeach;
	            	endif;
	                ?>
	            </div>
	        </div>
	    </section>
	</div>
	<?php
	endif;
	}



}


