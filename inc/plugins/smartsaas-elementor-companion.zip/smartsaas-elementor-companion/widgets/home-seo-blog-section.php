<?php
class Smartsass_Seo_Blog_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "seo_blog";
	}

	public function get_title() {
		return __( "SEO Blog", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Seo Blog Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'seoblog_title',[
				'label' => __( 'Seo Blog Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'seoblog_stitle',[
				'label' => __( 'Seo Blog Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();

		//wp_query for the seo blog post
		$seo_blog_q = new WP_Query(
		    array(
		        'post_type'       => 'post',
		        'post_status'     => 'publish',
		        'posts_per_page' => 5,
		        'ignore_sticky_posts' => 1
		    )
		);

		$post_data = array();
		while ( $seo_blog_q->have_posts() ) {
		    $seo_blog_q->the_post();

		    $post_data[] = array(
		        "title" => wp_trim_words( get_the_title(), 2 ),
		        "permalink"=>get_permalink(),
		        "date"=>get_the_date('j F,Y'),
		        "thumbnail"=>get_the_post_thumbnail_url(get_the_ID(),"large"),
		        "excerpt"=>wp_trim_words(get_the_excerpt(), 21, '')

		    );
		}
	?>
	<?php if($seo_blog_q->post_count > 1): ?>
	<!-- Blog Section Start Here -->
	<section class="blog-section padding-tb">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['seoblog_title'])): echo esc_html($settings['seoblog_title']); endif; ?></h2>
				<p><?php if(!empty($settings['seoblog_stitle'])): echo esc_html($settings['seoblog_stitle']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<div class="row">
					<div class="col-lg-6 col-12">
						<div class="left">
							<div class="post-item">
								<div class="post-item-inner">
									<div class="post-thumb">
										<a href="<?php echo esc_url($post_data[0]['permalink']); ?>">
											<?php if(!empty($post_data[0]['thumbnail'])): ?>
												<img src="<?php echo esc_url($post_data[0]['thumbnail']); ?>" alt="<?php bloginfo( 'name' ); ?>">
											<?php endif; ?>
										</a>
									</div>
									<div class="post-content">
										<h4><a href="<?php echo esc_url($post_data[0]['permalink']); ?>">
											<?php echo esc_html($post_data[0]['title']); ?></a>
										</h4>
										<div class="entry-meta">
											<a href="<?php echo esc_url($post_data[0]['permalink']); ?>" class="date"><?php echo esc_html($post_data[0]['date']); ?></a>
										</div>
										<p><?php echo esc_html($post_data[0]['excerpt']); ?></p>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="right">
							<?php
			                for($i=1; $i<5 ;$i++):
			                ?>
							<div class="post-item">
								<div class="post-item-inner">
									<div class="post-thumb">
										<a href="<?php echo esc_url($post_data[$i]['permalink']); ?>">
											<img src="<?php echo esc_url($post_data[$i]['thumbnail']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										</a>
									</div>
									<div class="post-content">
										<h6><a href="<?php echo esc_url($post_data[$i]['permalink']); ?>">
											<?php echo esc_html($post_data[$i]['title']); ?></a>
										</h6>
										<div class="entry-meta">
											<a href="<?php echo esc_url($post_data[$i]['permalink']); ?>" class="date"><?php echo esc_html($post_data[$i]['date']); ?></a>
										</div>
									</div>
								</div>
							</div>
							<?php
							  endfor; 
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php wp_reset_query(); endif; ?>
	<!-- Blog Section Ending Here -->
	<?php
		
	}



}





