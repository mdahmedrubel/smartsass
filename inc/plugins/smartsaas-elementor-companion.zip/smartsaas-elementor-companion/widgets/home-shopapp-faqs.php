<?php
class Smartsass_Home_Shopapp_Faqs extends \Elementor\Widget_Base {
	public function get_name() {
		return "shopapp_faqs";
	}

	public function get_title() {
		return __( "ShopApp Faqs", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Faqs Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'appfaq_title',[
				'label' => __( 'Faqs Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'appfaq_stitle',[
				'label' => __( 'Faqs Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'ftab_title',[
				'label' => __( 'Faqs Tab Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'ftab_content',[
				'label' => __( 'Faqs Tab Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		
		$this->add_control(
			'shopapp_faqs',
			[
				'label' => __( 'ShopApp Faqs Section', 'TEXT' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'ftab2_title',[
				'label' => __( 'Faqs Tab Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'ftab2_content',[
				'label' => __( 'Faqs Tab Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		
		$this->add_control(
			'shopapp2_faqs',
			[
				'label' => __( 'ShopApp Faqs Section', 'TEXT' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$shopapp_faqs = $this->get_settings('shopapp_faqs');
		$shopapp2_faqs = $this->get_settings('shopapp2_faqs');
	?>
    <!-- faq section start here -->
	<section class="faq-section shopapp padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['appfaq_title'])): echo esc_html($settings['appfaq_title']); endif; ?></h2>
				<p><?php if(!empty($settings['appfaq_stitle'])): echo esc_html($settings['appfaq_stitle']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	            <div class="row">
	                <div class="col-lg-6 col-12">

	                    <ul class="accordion">
	                    	<?php 
							if(!empty($shopapp_faqs)):
							foreach($shopapp_faqs as $shopapp_faq):
							?>
	                        <li class="accordion-item">
	                            <div class="accordion-list">
	                                <div class="left">
	                                    <div class="icon"></div>
	                                </div>
	                                <div class="right">
	                                    <h6><?php if(!empty($shopapp_faq['ftab_title'])): echo esc_html($shopapp_faq['ftab_title']); endif; ?></h6>
	                                </div>
	                            </div>
	                            <div class="accordion-answer">
	                                <p><?php if(!empty($shopapp_faq['ftab_content'])): echo esc_html($shopapp_faq['ftab_content']); endif; ?></p>
	                            </div>
	                        </li>
	                        <?php
							endforeach;
							endif; 
							?>
	                    </ul>
	                </div>
	                <div class="col-lg-6 col-12">
	                    <ul class="accordion">
	                    	<?php 
							if(!empty($shopapp2_faqs)):
							foreach($shopapp2_faqs as $shopapp2):
							?>
	                        <li class="accordion-item">
	                            <div class="accordion-list">
	                                <div class="left">
	                                    <div class="icon"></div>
	                                </div>
	                                <div class="right">
	                                    <h6><?php if(!empty($shopapp2['ftab2_title'])): echo esc_html($shopapp2['ftab2_title']); endif; ?></h6>
	                                </div>
	                            </div>
	                            <div class="accordion-answer">
	                                <p><?php if(!empty($shopapp2['ftab2_content'])): echo esc_html($shopapp2['ftab2_content']); endif; ?></p>
	                            </div>
	                        </li>
	                        <?php
							endforeach;
							endif; 
							?>
	                    </ul>
	                </div>
	            </div>
	        </div>
	    </div>
	</section>
	<!-- faq section ending here -->
	<?php
		
	}



}





