<?php
class Smartsass_Seo_Client_Carousel extends \Elementor\Widget_Base {
	public function get_name() {
		return "seo_logo_carousel";
	}

	public function get_title() {
		return __( "Sponsor Logo Carousel", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Sponsor Logo Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'choose_logo',[
				'label' => __( 'Select Sponsor Logo', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'sponsor-seo',
				'options' => [
					'sponsor-seo'  => __( 'Sponsor Seo', 'smartsaas' ),
					'sponsor-pos' => __( 'Sponsor Pos', 'smartsaas' ),
				],
			]
		);
		//seo sponsor style
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'seo_logo',[
				'label' => __( 'Seo Client Logos', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'seo_logo_url',[
				'label' => __( 'Seo Client Logos Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,

			]
		);
		$this->add_control(
			'client_logos',
			[
				'label' => __( 'Seo Client Logos', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_logo',
							'operator'  => '==',
							'value'  => 'sponsor-seo',
						]
					]
				]
			]
		);
		//post sponsor style
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'pos_logo',[
				'label' => __( 'Seo Client Logos', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'pos_logo_url',[
				'label' => __( 'Seo Client Logos Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'label_block' => true,

			]
		);
		$this->add_control(
			'client_logosss',
			[
				'label' => __( 'Seo Client Logos', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_logo',
							'operator'  => '==',
							'value'  => 'sponsor-pos',
						]
					]
				]
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$client_logos = $this->get_settings('client_logos');
		$client_logosss = $this->get_settings('client_logosss');
		$choose_logo = $this->get_settings('choose_logo');
	?>
	<!-- Sponsor Section Start Here -->
	<?php if($choose_logo == 'sponsor-seo'): ?>
	<div class="sponsor-section padding-tb">
		<div class="container">
			<div class="section-wrapper">
				<div class="sponsor-slider">
					<div class="swiper-wrapper">
						<?php 
						if(!empty($client_logos)):
						foreach($client_logos as $client_logo):
						?>
						<div class="swiper-slide">
							<div class="sponsor-item">
								<div class="sponsor-thumb">
									<?php if(!empty($client_logo['seo_logo']['url'])): ?>
									<a href="<?php if(!empty($client_logo['seo_logo_url']['url'])): echo esc_url($client_logo['seo_logo_url']['url']); endif; ?>">
										<img src="<?php echo wp_kses_post($client_logo['seo_logo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
									</a>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<?php
						endforeach;
						endif; 
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php elseif($choose_logo == 'sponsor-pos'): ?>
	<div class="sponsor-section pos-page padding-tb">
		<div class="container">
			<div class="section-wrapper">
				<div class="sponsor-slider-one">
					<div class="swiper-wrapper">
						<?php 
						if(!empty($client_logosss)):
						foreach($client_logosss as $logosss):
						?>
						<div class="swiper-slide">
							<div class="sponsor-item">
								<div class="sponsor-thumb">
									<?php if(!empty($logosss['pos_logo']['url'])): ?>
									<a href="<?php if(!empty($logosss['pos_logo_url']['url'])): echo esc_url($logosss['pos_logo_url']['url']); endif; ?>">
										<img src="<?php echo wp_kses_post($logosss['pos_logo']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
									</a>
									<?php endif; ?>
								</div>
							</div>
						</div>
						<?php
						endforeach;
						endif; 
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Sponsor Section Ending Here -->
	<?php
	endif;
	}



}





