<?php
class Smartsass_Crypto_holders extends \Elementor\Widget_Base {
	public function get_name() {
		return "benefits_cripto";
	}

	public function get_title() {
		return __( "Benefits Of Cripto Holders", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Vpn Faq Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'crpb_title',[
				'label' => __( 'Section Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crpb_descs',[
				'label' => __( 'Section Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'crypto_hobenefits',[
				'label' => __( 'Benefits Of Cripto Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [
                    [
                        'name' => 'criptos_simg',
                        'label' => esc_html__('Cripto About Box Image', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'criptos_title',
                        'label' => esc_html__('Cripto Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'criptos_content',
                        'label' => esc_html__('Cripto Content', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'criptos_btn',
                        'label' => esc_html__('Cripto Button Text', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'criptos_btnurl',
                        'label' => esc_html__('Cripto Button Url', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$crypto_hobenefits = $this->get_settings('crypto_hobenefits');
	?>
	<!-- About Section Start Here -->
	<section class="about-section style-2 style-3 crypto-about crypto-bg padding-tb">
	    <div class="lines">
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	        <div class="line"></div>
	    </div>
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['crpb_title'])): echo esc_html($settings['crpb_title']); endif; ?></h2>
	            <p><?php if(!empty($settings['crpb_descs'])): echo esc_html($settings['crpb_title']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	        	<?php 
            	if(!empty($crypto_hobenefits)):
            	foreach($crypto_hobenefits as $cryptoes):
            	?>
	            <div class="lab-item">
	                <div class="lab-inner">
	                    <div class="lab-thumb">
	                        <?php if(!empty($cryptoes['criptos_simg']['url'])): ?>
	                        	<img src="<?php echo wp_kses_post($cryptoes['criptos_simg']['url']); ?>" alt="<?php bloginfo('name'); ?>">
	                		<?php endif; ?>
	                    </div>
	                    <div class="lab-content">
	                        <h4><?php if(!empty($cryptoes['criptos_title'])): echo esc_html($cryptoes['criptos_title']); endif; ?></h4>
	                        <p><?php if(!empty($cryptoes['criptos_content'])): echo esc_html($cryptoes['criptos_content']); endif; ?></p>
	                        <?php if(!empty($cryptoes['criptos_btn'])): ?>
	                        <a href="<?php echo esc_url($cryptoes['criptos_btnurl']); ?>" class="text-btn"><?php echo esc_html($cryptoes['criptos_btn']); ?><i class="icofont-double-right"></i></a>
	                        <?php  endif;  ?>
	                    </div>
	                </div>
	            </div>
	            <?php 
            	endforeach;
            	endif;
                ?>
	        </div>
	    </div>
	</section>
	<!-- About Section Ending Here -->
	<?php
	}



}





