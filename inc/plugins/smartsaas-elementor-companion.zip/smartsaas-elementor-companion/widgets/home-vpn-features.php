<?php
class Smartsass_Vpn_Features extends \Elementor\Widget_Base {
	public function get_name() {
		return "vpn_feature";
	}

	public function get_title() {
		return __( "Vpn Features", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Vpn Feature Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'vpn_ftitle',[
				'label' => __( 'Feature Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'vpn_fstitle',[
				'label' => __( 'Vpn Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'vpn_ficon',[
				'label' => __( 'Vpn Small Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'vpnf_boxtitle',[
				'label' => __( 'Vpn Box Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'vpn_boxfcon',[
				'label' => __( 'Vpn Box Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'vpn_boxs',
			[
				'label' => __( 'Seo Service Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$vpn_boxs = $this->get_settings('vpn_boxs');
	?>
	<!-- Service Section Start Here -->
	<section class="service-section style-4 padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['vpn_ftitle'])): echo esc_html($settings['vpn_ftitle']); endif; ?></h2>
				<p><?php if(!empty($settings['vpn_fstitle'])): echo esc_html($settings['vpn_fstitle']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	        	<?php 
				if(!empty($vpn_boxs)):
				foreach($vpn_boxs as $vpn_bxs):
				?>
	            <div class="lab-item">
	                <div class="lab-inner">
	                    <div class="lab-thumb">
	                        <?php if(!empty($vpn_bxs['vpn_ficon']['url'])): ?>
								<img src="<?php echo wp_kses_post($vpn_bxs['vpn_ficon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
							<?php endif; ?>
	                    </div>
	                    <div class="lab-content">
	                        <h4><?php if(!empty($vpn_bxs['vpnf_boxtitle'])): echo esc_html($vpn_bxs['vpnf_boxtitle']); endif; ?></h4>
	                        <p><?php if(!empty($vpn_bxs['vpn_boxfcon'])): echo esc_html($vpn_bxs['vpn_boxfcon']); endif; ?></p>
	                    </div>
	                </div>
	            </div>
	            <?php
				endforeach;
				endif; 
				?>
	        </div>
	    </div>
	</section>
	<!-- Service Section Ending Here -->
	<?php
	}



}





