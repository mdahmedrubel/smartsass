<?php
class Smartsaas_Home_Pos_Service extends \Elementor\Widget_Base {
	public function get_name() {
		return "pos_services";
	}

	public function get_title() {
		return __( "Home Pos Service", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Home Pos Service Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'select_posservice',[
				'label' => __( 'Select Pos Service', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'pos-Omnichannel',
				'options' => [
					'pos-Omnichannel' => __( 'Home Pos Service One', 'smartsaas' ),
					'pos-Allinone' => __( 'Home Pos Service Two', 'smartsaas' ),
					'pos-retail' => __( 'Home Pos Service Three', 'smartsaas' ),
				],
			]
		);
		//servies one
		$this->add_control(
			'posser_title',[
				'label' => __( 'Pos Service Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Omnichannel',
						]
					]
				]
			]
		);
		$this->add_control(
			'posser_desc',[
				'label' => __( 'Pos Service Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Short Content', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Omnichannel',
						]
					]
				]
			]
		);
		$this->add_control(
			'hpos_services',[
				'label' => __( 'Pos Service Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Omnichannel',
						]
					]
				],
                'fields' => [
                    [
                        'name' => 'service_stitle',
                        'label' => esc_html__('Service Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		$this->add_control(
			'posser_btn',[
				'label' => __( 'Pos Service Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Omnichannel',
						]
					]
				]
			]
		);
		$this->add_control(
			'posser_btnurl',[
				'label' => __( 'Pos Service Button URl', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Omnichannel',
						]
					]
				]
			]
		);
		$this->add_control(
			'posser_img',[
				'label' => __( 'Pos Service Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'placeholder' => __( 'Pos Service Image', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Omnichannel',
						]
					]
				]
			]
		);
		$this->add_control(
			'left_right',
			[
				'label' => __( 'Show Image Left or Right', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Left', 'smartsaas' ),
				'label_off' => __( 'Right', 'smartsaas' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Omnichannel',
						]
					]
				]
			]
		);

		//services two
		$this->add_control(
			'posser_title2',[
				'label' => __( 'Pos Service Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Allinone',
						]
					]
				]
			]
		);
		$this->add_control(
			'posser_desc2',[
				'label' => __( 'Pos Service Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Short Content', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Allinone',
						]
					]
				]
			]
		);
		$this->add_control(
			'hpos_services2',[
				'label' => __( 'Pos Service Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Allinone',
						]
					]
				],
                'fields' => [
                    [
                        'name' => 'service_stitle2',
                        'label' => esc_html__('Service Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		$this->add_control(
			'posser_btn2',[
				'label' => __( 'Pos Service Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Allinone',
						]
					]
				]
			]
		);
		$this->add_control(
			'posser_btnurl2',[
				'label' => __( 'Pos Service Button URl', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Allinone',
						]
					]
				]
			]
		);
		$this->add_control(
			'posser_img2',[
				'label' => __( 'Pos Service Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'placeholder' => __( 'Pos Service Image', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Allinone',
						]
					]
				]
			]
		);
		$this->add_control(
			'left_right2',
			[
				'label' => __( 'Show Image Left or Right', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => __( 'Left', 'smartsaas' ),
				'label_off' => __( 'Right', 'smartsaas' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-Allinone',
						]
					]
				]
			]
		);

		//service three pos
		$this->add_control(
			'posser_title3',[
				'label' => __( 'Pos Service Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-retail',
						]
					]
				]
			]
		);
		$this->add_control(
			'posser_desc3',[
				'label' => __( 'Pos Service Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Short Content', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-retail',
						]
					]
				]
			]
		);
		$this->add_control(
			'hpos_services3',[
				'label' => __( 'Pos Service Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-retail',
						]
					]
				],
                'fields' => [
                    [
                        'name' => 'service_stitle3',
                        'label' => esc_html__('Service Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		$this->add_control(
			'posser_btn3',[
				'label' => __( 'Pos Service Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-retail',
						]
					]
				]
			]
		);
		$this->add_control(
			'posser_btnurl3',[
				'label' => __( 'Pos Service Button URl', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-retail',
						]
					]
				]
			]
		);
		$this->add_control(
			'posser_img3',[
				'label' => __( 'Pos Service Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'placeholder' => __( 'Pos Service Image', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'select_posservice',
							'operator'  => '==',
							'value'  => 'pos-retail',
						]
					]
				]
			]
		);


	$this->end_controls_section();

	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		$select_posservice = $this->get_settings('select_posservice');
	
	?>
	<?php if($select_posservice == 'pos-Omnichannel'): ?> 
	<section class="pos-section padding-tb">
        <div class="container">
            <div class="row <?php if('yes' === $settings['left_right']): ?> flex-row-reverse <?php endif; ?>align-items-center">
                <div class="col-lg-6 col-12">
                    <div class="pos-thmub">
                        <?php if(!empty($settings['posser_img']['url'])): ?>
                        	<img src="<?php echo wp_kses_post($settings['posser_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
                		<?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="pos-content-area">
                        <div class="section-header style-3">
                            <h2><?php if(!empty($settings['posser_title'])): echo esc_html($settings['posser_title']); endif; ?></h2>
							<p><?php if(!empty($settings['posser_desc'])): echo esc_html($settings['posser_desc']); endif; ?></p>
                        </div>
                        <div class="section-wrapper">
                            <ul>
                            	<?php 
				            	if(!empty($settings['hpos_services'])):
				            	foreach($settings['hpos_services'] as $posservice):
				            	?>
				            	<?php if(!empty($posservice['service_stitle'])): ?>
                                	<li><i class="icofont-tick-mark"></i><?php echo esc_html($posservice['service_stitle']); ?></li>
                            	<?php endif; ?>
                                <?php 
				            	endforeach;
				            	endif;
				                ?>
                            </ul>
                            <?php if(!empty($settings['posser_btn'])): ?>
                            	<a href="<?php echo esc_url($settings['posser_btnurl']['url']); ?>" class="lab-btn"><span><?php echo esc_html($settings['posser_btn']); ?></span></a>
                            <?php endif; ?>
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </section>
	<?php elseif($select_posservice == 'pos-Allinone'): ?>
	<section class="pos-section bgc-3 padding-tb">
        <div class="container">
            <div class="row <?php if('yes' === $settings['left_right2']): ?> flex-row-reverse <?php endif; ?> align-items-center">
                <div class="col-lg-6 col-12">
                    <div class="pos-thmub">
                        <?php if(!empty($settings['posser_img2']['url'])): ?>
                        	<img src="<?php echo wp_kses_post($settings['posser_img2']['url']); ?>" alt="<?php bloginfo('name'); ?>">
                		<?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="pos-content-area">
                        <div class="section-header style-3">
                            <h2><?php if(!empty($settings['posser_title2'])): echo esc_html($settings['posser_title2']); endif; ?></h2>
							<p><?php if(!empty($settings['posser_desc2'])): echo esc_html($settings['posser_desc2']); endif; ?></p>
                        </div>
                        <div class="section-wrapper"> 
                            <ul>
                                <?php 
				            	if(!empty($settings['hpos_services2'])):
				            	foreach($settings['hpos_services2'] as $posservices):
				            	?>
				            	<?php if(!empty($posservices['service_stitle2'])): ?>
                                	<li><i class="icofont-tick-mark"></i><?php echo esc_html($posservices['service_stitle2']); ?>
                                	</li>
                            	<?php endif; ?>
                                <?php 
				            	endforeach;
				            	endif;
				                ?> 
                            </ul>
                            <?php if(!empty($settings['posser_btn2'])): ?>
                            	<a href="<?php echo esc_url($settings['posser_btnurl2']['url']); ?>" class="lab-btn"><span><?php echo esc_html($settings['posser_btn2']); ?></span></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php elseif($select_posservice == 'pos-retail'): ?>
    <section class="pos-section padding-tb">
        <div class="container">
            <div class="row flex-row-reverse align-items-center">
                <div class="col-lg-6 col-12">
                    <div class="pos-thmub">
                        <?php if(!empty($settings['posser_img3']['url'])): ?>
                        	<img src="<?php echo wp_kses_post($settings['posser_img3']['url']); ?>" alt="<?php bloginfo('name'); ?>">
                		<?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 col-12">
                    <div class="pos-content-area">
                        <div class="section-header style-3">
                            <h2><?php if(!empty($settings['posser_title3'])): echo esc_html($settings['posser_title3']); endif; ?></h2>
							<p><?php if(!empty($settings['posser_desc3'])): echo esc_html($settings['posser_desc3']); endif; ?></p>
                        </div>
                        <div class="section-wrapper">
                            <ul>
                                <?php 
				            	if(!empty($settings['hpos_services3'])):
				            	foreach($settings['hpos_services3'] as $posservices3):
				            	?>
				            	<?php if(!empty($posservices3['service_stitle3'])): ?>
                                	<li><i class="icofont-tick-mark"></i><?php echo esc_html($posservices3['service_stitle3']); ?>
                                	</li>
                            	<?php endif; ?>
                                <?php 
				            	endforeach;
				            	endif;
				                ?> 
                            </ul>
                            <?php if(!empty($settings['posser_btn3'])): ?>
                            	<a href="<?php echo esc_url($settings['posser_btnurl3']['url']); ?>" class="lab-btn"><span><?php echo esc_html($settings['posser_btn3']); ?></span></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
	<?php
	endif;
	}



}


