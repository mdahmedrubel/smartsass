<?php
class Smartsaas_Banner_Extension extends \Elementor\Widget_Base {
	public function get_name() {
		return "smartsaas_banner";
	}

	public function get_title() {
		return __( "Smartsaas Banner", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {

		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Smartsaas Banner Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'choose_banner',[
				'label' => __( 'Select Banner', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'label_block' => true,
				'default' => 'home-seo',
				'options' => [
					'home-seo'  => __( 'Home Seo', 'smartsaas' ),
					'home-host' => __( 'Home Host', 'smartsaas' ),
					'home-erp' => __( 'Home Erp', 'smartsaas' ),
					'home-vpn' => __( 'Home Vpn', 'smartsaas' ),
				],
			]
		);

		//seo banner controlls
		$this->add_control(
			'banner_title',[
				'label' => __( 'Banner Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your title here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_desc',[
				'label' => __( 'Banner Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Banner discripion', 'smartsaas' ),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'button_text',[
				'label' => __( 'Banner Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'button_url',[
				'label' => __( 'Banner Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'video_url',[
				'label' => __( 'Banner Video Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Video Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'overview',[
				'label' => __( 'Banner Overview Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Overview Text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_img_1',[
				'label' => __( 'Add Banner Round Shape Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_img_2',[
				'label' => __( 'Moving Arrow Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_img_3',[
				'label' => __( 'Moving Search Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_img_4',[
				'label' => __( 'Moving Person Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_img_5',[
				'label' => __( 'Big Screen Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-seo',
						]
					]
				]
			]
		);


		//Host banner controlls
		$this->add_control(
			'circle_text',[
				'label' => __( 'Citcle Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your circle text here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'circle_price',[
				'label' => __( 'Circle Price', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Circle Price', 'smartsaas' ),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'title_part1',[
				'label' => __( 'Banner Title Part One', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Banner title part one', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'title_part2',[
				'label' => __( 'Banner Title Part Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Banner title part two', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'title_part3',[
				'label' => __( 'Banner Title Part Three', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Banner title part three', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_hosts',[
				'label' => __( 'Host Banner Features', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				],
                'fields' => [
                     [
                        'name' => 'h_feature',
                        'label' => esc_html__('Host banner features', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ], 
                ],
                
			]
		);
		$this->add_control(
			'hbutton_text',[
				'label' => __( 'Banner Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'hbutton_url',[
				'label' => __( 'Banner Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'hvideo_url',[
				'label' => __( 'Banner Video Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Video Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'hoverview',[
				'label' => __( 'Banner Overview Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Overview Text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'hoverview_time',[
				'label' => __( 'Banner Overview Time', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Overview time', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_sliders',[
				'label' => __( 'Host Banner Slider', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-host',
						]
					]
				],
                'fields' => [
                     [
                        'name' => 'host_slide',
                        'label' => esc_html__('Host banner slider', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                    ], 
                ],
                
			]
		);


		//Erp banner controlls
		$this->add_control(
			'erp_bannerbg',[
				'label' => __( 'Banner Background Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'placeholder' => __( 'add your img here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'erpbanner_title',[
				'label' => __( 'Banner Title Part one', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your title here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_titlep2',[
				'label' => __( 'Banner Title Part Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Banner title part two', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_titlep3',[
				'label' => __( 'Banner Title Part Three', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Banner title part three', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'banner_sdesc',[
				'label' => __( 'Banner Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Banner discripion', 'smartsaas' ),
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'erpbbtn_text',[
				'label' => __( 'Banner Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'erpbbtn_url',[
				'label' => __( 'Banner Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);

		$this->add_control(
			'erp_bannerimg1',[
				'label' => __( 'Add Banner Big Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'erp_bannerimg2',[
				'label' => __( 'Top Moving Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'erp_bannerimg3',[
				'label' => __( 'Top Right Moving Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'erp_bannerimg4',[
				'label' => __( 'Left Moving Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'erp_bannerimg5',[
				'label' => __( 'Right Moving Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);
		$this->add_control(
			'erp_bannerimg6',[
				'label' => __( 'Bottom Moving Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-erp',
						]
					]
				]
			]
		);


		//VPN banner controlls
		$this->add_control(
			'vpn_bannerbg',[
				'label' => __( 'Banner Background Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'placeholder' => __( 'Add your image here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpnbanner_title',[
				'label' => __( 'Banner Title Part one', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Type your title here', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpnbanner_titlep2',[
				'label' => __( 'Banner Title Part Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Banner title part two', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpnbanner_sdesc',[
				'label' => __( 'Banner Short Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Banner short description', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpnbanner_timer',[
				'label' => __( 'Banner Counter Timer', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Add this format 12/22/2022 17:00:00', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpnbbtn_text',[
				'label' => __( 'Banner Button Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button text', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpnbbtn_url',[
				'label' => __( 'Banner Button Url', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __( 'Button Url', 'smartsaas' ),
				'label_block' => true,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);

		$this->add_control(
			'vpn_bannerimg1',[
				'label' => __( 'Add Banner Big Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpn_bannerimg2',[
				'label' => __( 'Moving Message Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpn_bannerimg3',[
				'label' => __( 'Moving Love Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpn_bannerimg4',[
				'label' => __( 'Moving Mobile Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		$this->add_control(
			'vpn_bannerimg5',[
				'label' => __( 'Moving Comment Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'conditions'  =>[
					'terms' => [
						[
							'name'  => 'choose_banner',
							'operator'  => '==',
							'value'  => 'home-vpn',
						]
					]
				]
			]
		);
		

	$this->end_controls_section();

	}



	protected function render() {
		$settings = $this->get_settings_for_display();
		$choose_banner = $this->get_settings('choose_banner');
		$banner_hosts = $this->get_settings('banner_hosts');
		$banner_sliders = $this->get_settings('banner_sliders');
		
		if(isset($settings['erp_bannerbg']['id'])){
			$erp_bg = wp_get_attachment_image_url($settings['erp_bannerbg']['id'], 'large');
		}
		if(isset($settings['vpn_bannerbg']['id'])){
			$vpn_bg = wp_get_attachment_image_url($settings['vpn_bannerbg']['id'], 'full');
		}
		
	
	?>
	<?php if($choose_banner == 'home-seo'): ?>
	<section class="banner-section seo-banner">
		<div class="round-shape d-none d-lg-block">
			<div class="round">
				<?php if(!empty($settings['banner_img_1']['url'])): ?>
					<img src="<?php echo wp_kses_post($settings['banner_img_1']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
				<?php endif; ?>
			</div>
		</div>
		<div class="codex-shape">
			<div class="line line_1"></div>
			<div class="line line_2"></div>
			<div class="line line_3"></div>
			<div class="line line_4"></div>
			<div class="line line_5"></div>
			<div class="line line_6"></div>
		</div>
		<div class="banner-area">
			<div class="container">
				<div class="row no-gutters align-items-center justify-content-center">
					<div class="col-xl-6 col-md-8 col-12">
						<div class="content-part">
							<div class="section-header style-2">
								<h2><?php if(!empty($settings['banner_title'])): echo esc_html($settings['banner_title']); endif; ?></h2>
								<p><?php if(!empty($settings['banner_desc'])): echo esc_html($settings['banner_desc']); endif; ?></p>
								<div class="button-group">
									<?php if(!empty($settings['button_text'])): ?>
									<a href="<?php echo esc_url($settings['button_url']); ?>" class="lab-btn">
										<span><?php echo esc_html($settings['button_text']); ?></span>
									</a>
									<?php endif; ?>
									<div class="banner-video">
										<a href="<?php if(!empty($settings['video_url'])): echo esc_url($settings['video_url']); endif; ?>" data-rel="lightcase"><i class="icofont-play-alt-2"></i></a>
										<span><?php if(!empty($settings['overview'])): echo esc_html($settings['overview']); endif; ?></span>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-6 col-12">
						<div class="section-wrapper">
							<div class="banner-thumb">
								<?php if(!empty($settings['banner_img_5']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['banner_img_5']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
								<div class="thumb-shape">
									<div class="th-shape th-shape-1">
										<?php if(!empty($settings['banner_img_3']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['banner_img_3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>

									<div class="th-shape th-shape-2">
										<?php if(!empty($settings['banner_img_2']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['banner_img_2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-3">
										<?php if(!empty($settings['banner_img_4']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['banner_img_4']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($choose_banner == 'home-host'): ?>
	<!-- Banner Section start here -->
	<section class="banner-section style-2">
		<div class="banner-area">
			<div class="left-side">
				<div class="section-wrapper">
					<div class="banner-slider">
						<div class="swiper-wrapper">
							<?php
							if(!empty($banner_sliders)): 
							foreach($banner_sliders as $banner_slider):
							$host_banner = wp_get_attachment_image_url($banner_slider['host_slide']['id'], 'full');
							?>
							<div class="swiper-slide slide-1 host-slide" style="background: url(<?php echo esc_url($host_banner); ?>);"></div>
							<?php 
							endforeach;
							endif;
							?>
						</div>
						<div class="banner-pagination"></div>
					</div>
				</div>
			</div>
			<div class="right-side">
				<div class="content-part">
					<div class="section-header style-2">
						<?php if(!empty($settings['circle_text'])): ?>
							<div class="banner-price">
								<p><?php echo esc_html($settings['circle_text']); ?></p>
								<span><sup><?php _e('$', 'smartsaas'); ?></sup><?php echo esc_html($settings['circle_price']); ?></span>
							</div>
						<?php endif; ?>
						<h2><span><?php if(!empty($settings['title_part1'])): echo esc_html($settings['title_part1']); endif; ?></span></h2>
						<h2><span><?php if(!empty($settings['title_part1'])): echo esc_html($settings['title_part2']); endif; ?></span></h2>
						<h2><?php if(!empty($settings['title_part1'])): echo esc_html($settings['title_part3']); endif; ?></h2>
						<ul>
							<?php
							 if(!empty($banner_hosts)): 
							 	foreach($banner_hosts as $banner_host):
							?>
							<?php if(!empty($banner_host['h_feature'])): ?>
								<li><i class="icofont-ghost"></i><?php echo esc_html($banner_host['h_feature']); ?></li>
							<?php endif; ?>
							<?php 
							endforeach;
							endif;
							?>
						</ul>
						<div class="button-group">
							<a href="<?php echo esc_url($settings['hbutton_url']); ?>" class="lab-btn"><span><?php echo esc_html($settings['hbutton_text']); ?></span></a>
							<div class="banner-video">
								<?php if(!empty($settings['hvideo_url'])): ?>
									<a href="<?php echo esc_url($settings['hvideo_url']); ?>" data-rel="lightcase"><i class="icofont-play-alt-2"></i></a>
								<?php endif; ?>
								<span><?php if(!empty($settings['hoverview'])): echo esc_html($settings['hoverview']); endif; ?><b><?php if(!empty($settings['hoverview_time'])): echo esc_html($settings['hoverview_time']); endif; ?></b></span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($choose_banner == 'home-erp'): ?>
	<section class="banner-section bg_size style-3" <?php if(!empty($erp_bg)): ?> style="background-image: url(<?php echo esc_url($erp_bg); ?>);" <?php endif; ?>>
	    <div class="round-shape d-none d-lg-block">
	        <div class="shape round-1"></div>
	        <div class="shape round-2"></div>
	        <div class="shape round-3"></div>
	        <div class="shape round-4"></div>
	        <div class="shape round-5"></div>
		</div>
		<div class="banner-area">
			<div class="container">
				<div class="row no-gutters align-items-center">
					<div class="col-xl-6 col-12">
						<div class="content-part">
							<div class="section-header style-2">
								<h2><?php if(!empty($settings['erpbanner_title'])): echo esc_html($settings['erpbanner_title']); endif; ?></h2>
	                            <h2><?php if(!empty($settings['banner_titlep2'])): echo esc_html($settings['banner_titlep2']); endif; ?></h2>
	                            <span><?php if(!empty($settings['banner_titlep3'])): echo esc_html($settings['banner_titlep3']); endif; ?></span>
								<p><?php if(!empty($settings['banner_sdesc'])): echo esc_html($settings['banner_sdesc']); endif; ?></p>
								<?php if(!empty($settings['erpbbtn_text'])): ?>
	                            <a href="<?php echo esc_url($settings['erpbbtn_url']); ?>" class="lab-btn"><span><?php echo esc_html($settings['erpbbtn_text']); ?></span>
	                            </a>
	                        	<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-xl-6 col-12">
						<div class="section-wrapper">
							<div class="banner-thumb">
								<?php if(!empty($settings['erp_bannerimg1']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['erp_bannerimg1']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
								<div class="thumb-shape">
									<div class="th-shape th-shape-1">
										<?php if(!empty($settings['erp_bannerimg4']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['erp_bannerimg4']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-2">
										<?php if(!empty($settings['erp_bannerimg2']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['erp_bannerimg2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-3">
										<?php if(!empty($settings['erp_bannerimg3']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['erp_bannerimg3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-4">
										<?php if(!empty($settings['erp_bannerimg5']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['erp_bannerimg5']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-5">
										<?php if(!empty($settings['erp_bannerimg6']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['erp_bannerimg6']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<?php elseif($choose_banner == 'home-vpn'): ?>
	<section class="banner-section style-4" <?php if(!empty($vpn_bg)): ?> style="background-image: url(<?php echo esc_url($vpn_bg); ?>);" <?php endif; ?>>
		<div class="banner-area">
			<div class="container">
				<div class="row no-gutters align-items-center">
					<div class="col-lg-6 col-12">
						<div class="content-part">
							<div class="section-header style-2">
								<h2><?php if(!empty($settings['vpnbanner_title'])): echo esc_html($settings['vpnbanner_title']); endif; ?></h2>
		                        <h2><?php if(!empty($settings['vpnbanner_titlep2'])): echo esc_html($settings['vpnbanner_titlep2']); endif; ?></h2>
		                        <p><?php if(!empty($settings['vpnbanner_sdesc'])): echo esc_html($settings['vpnbanner_sdesc']); endif; ?></p>
			                    <ul class="countdown eventdate" data-date="<?php if(!empty($settings['vpnbanner_timer'])): echo esc_attr($settings['vpnbanner_timer']); endif; ?>">
					                <li class="clock-item">
					                    <div class="count-number days"><?php esc_html_e('0', 'smartsaas'); ?></div>
					                	<div class="days_text count-text"><?php esc_html_e('Days', 'smartsaas'); ?></div>
					                </li>
					                <li class="clock-item">
					                    <div class="count-number hours"><?php esc_html_e('09', 'smartsaas'); ?></div>
					                	<div class="hours_text count-text"><?php esc_html_e('Hours', 'smartsaas'); ?></div>
					                </li>
					                <li class="clock-item">
					                    <div class="count-number minutes"><?php esc_html_e('10', 'smartsaas'); ?></div>
					                	<div class="minutes_text count-text"><?php esc_html_e('Minutes', 'smartsaas'); ?></div>
					                </li>
					                <li class="clock-item">
					                    <div class="count-number seconds"><?php esc_html_e('27', 'smartsaas'); ?></div>
					                	<div class="seconds_text count-text"><?php esc_html_e('Seconds', 'smartsaas'); ?></div>
					                </li>
					            </ul>
		                        <?php if(!empty($settings['vpnbbtn_text'])): ?>
		                        <a href="<?php if(!empty($settings['vpnbbtn_url'])): echo esc_url($settings['vpnbbtn_url']); endif; ?>" class="lab-btn">
		                        	<span><?php echo esc_html($settings['vpnbbtn_text']); ?></span>
		                        </a>
		                        <?php endif; ?>
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-12">
						<div class="section-wrapper">
							<div class="banner-thumb">
								<?php if(!empty($settings['vpn_bannerimg1']['url'])): ?>
									<img src="<?php echo wp_kses_post($settings['vpn_bannerimg1']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
								<?php endif; ?>
								<div class="thumb-shape">
									<div class="th-shape th-shape-1">
										<?php if(!empty($settings['vpn_bannerimg5']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['vpn_bannerimg5']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-2">
										<?php if(!empty($settings['vpn_bannerimg2']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['vpn_bannerimg2']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-3">
										<?php if(!empty($settings['vpn_bannerimg4']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['vpn_bannerimg4']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
									<div class="th-shape th-shape-4">
										<?php if(!empty($settings['vpn_bannerimg3']['url'])): ?>
											<img src="<?php echo wp_kses_post($settings['vpn_bannerimg3']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
										<?php endif; ?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

	</section>

	<?php
	endif;
	}



}


