<?php
class Smartsaas_Domain_Search_Addon extends \Elementor\Widget_Base {
	public function get_name() {
		return "smartsaas_domain_search";
	}

	public function get_title() {
		return __( "Domain Search", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'smartsaas_domain',[
				'label' => __( 'Domain Search', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'domain_title',[
				'label' => __( 'Add Domain Search Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'placeholder' => __('Add title ', 'smartsaas'),
				'label_block' => true,
			]
		);
		$this->add_control(
			'domain_desc',[
				'label' => __( 'Add Domain Search Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __('Add short description ', 'smartsaas'),
				'label_block' => true,

			]
		);
		$this->add_control(
			'domain_search',[
				'label' => __( 'Add Domain Search Shortcode', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => __('add shortcode ', 'smartsaas'),
				'default'    => __('[ajaxdomainchecker width="741" button="Search"]', 'smartsaas'),
			]
		);
		$this->add_control(
			'domain_bg',[
				'label' => __( 'Add Domain Background', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'domain_text',[
				'label' => __( 'Add Domain Price Text', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'domain_groups',
			[
				'label' => __( '', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

	$this->end_controls_section();

}


	protected function render() {
		$settings = $this->get_settings_for_display();
		$domain_bg = wp_get_attachment_image_url($settings['domain_bg']['id'], 'large');

	?>
	<!-- Doming Check Section Start Here -->
	<section class="doming-section bg_size padding-tb" <?php if(!empty($domain_bg)): ?> style="background-image: url(<?php echo esc_url($domain_bg); endif; ?>);">
		<div class="container">
			<div class="section-header">
				<h2><?php if(!empty($settings['domain_title'])): echo esc_html($settings['domain_title']); endif; ?></h2>
				<p><?php if(!empty($settings['domain_desc'])): echo esc_html($settings['domain_desc']); endif; ?></p>
			</div>
			<div class="section-wrapper">
				<div class="domain-btn">
					<?php if(!empty($settings['domain_search'])):  ?>
						<?php echo do_shortcode($settings['domain_search']); ?>
					<?php endif; ?>
				</div>
				<ul>
					<?php 
					if(!empty($settings['domain_groups'])):
					foreach($settings['domain_groups'] as $domains):
					?>
					<li><span><?php esc_html_e('.Com', 'smartsaas'); ?></span> <?php if(!empty($domains['domain_text'])): echo esc_html($domains['domain_text']); endif; ?></li>
					<?php
					endforeach;
					endif; 
					?>
				</ul>
			</div>
		</div>
	</section>
	<!-- Doming Check Section Ending Here -->
	<?php
		
	}



}


