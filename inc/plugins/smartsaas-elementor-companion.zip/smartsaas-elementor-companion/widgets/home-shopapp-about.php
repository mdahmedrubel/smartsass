<?php
class Smartsass_Shopapp_About extends \Elementor\Widget_Base {
	public function get_name() {
		return "shopapp_about";
	}

	public function get_title() {
		return __( "ShopApp About", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'About Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'appabout_title',[
				'label' => __( 'About Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'appabout_cont',[
				'label' => __( 'About Description', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'shopapps',[
				'label' => __( 'Shop App About Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'separator' => 'before',
                'fields' => [
                    [
                        'name' => 'ap_img',
                        'label' => esc_html__('App About Image', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::MEDIA,
                    ],
                    [
                        'name' => 'ap_title',
                        'label' => esc_html__('App About Title', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXT,
                        'label_block' => true,
                    ],
                    [
                        'name' => 'ap_desc',
                        'label' => esc_html__('About Content', 'smartsaas'),
                        'type' => \Elementor\Controls_Manager::TEXTAREA,
                        'label_block' => true,
                    ],
                ],
                
			]
		);
		
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$shopapps = $this->get_settings('shopapps');
	?>
	<!-- About Section Start Here -->
	<section class="about-section style-5 padding-tb">
	    <div class="container">
	        <div class="section-header">
	            <h2><?php if(!empty($settings['appabout_title'])): echo esc_html($settings['appabout_title']); endif; ?></h2>
	            <p><?php if(!empty($settings['appabout_cont'])): echo esc_html($settings['appabout_cont']); endif; ?></p>
	        </div>
	        <div class="section-wrapper">
	        	<?php 
            	if(!empty($shopapps)):
            	$times = 0;
            	foreach($shopapps as $shopapp):
            	$times++;

            	if($times == 1){
            		$count = "3";
            	}elseif($times == 2){
            		$count = "4";
            	}elseif($times == 3){
            		$count = "5";
            	}
            	?>
	            <div class="lab-item wow fadeInUp" data-wow-duration="1s" data-wow-delay=".<?php echo esc_attr($count); ?>s">
	                <div class="lab-inner">
	                    <div class="lab-thumb">
	                        <?php if(!empty($shopapp['ap_img']['url'])): ?>
	                        	<img src="<?php echo wp_kses_post($shopapp['ap_img']['url']); ?>" alt="<?php bloginfo('name'); ?>">
	                		<?php endif; ?>
	                    </div>
	                    <div class="lab-content">
	                        <h4><?php if(!empty($shopapp['ap_title'])): echo esc_html($shopapp['ap_title']); endif; ?></h4>
	                        <p><?php if(!empty($shopapp['ap_desc'])): echo esc_html($shopapp['ap_desc']); endif; ?></p>
	                    </div>
	                </div>
	            </div>
	            <?php 
            	endforeach;
            	endif;
                ?>
	        </div>
	    </div>
	</section>
	<!-- About Section Ending Here -->
	<?php
	}



}





