<?php
class Smartsass_Home_Shopapp_Smartphone extends \Elementor\Widget_Base {
	public function get_name() {
		return "shopapp_smartphone";
	}

	public function get_title() {
		return __( "Shopapp Smartphone", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Available Smartphone Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'smartphone_title',[
				'label' => __( 'Smartphone Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'smartphone_desc',[
				'label' => __( 'Smartphone Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'smartp_icon',[
				'label' => __( 'Download Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
			]
		);
		$repeater->add_control(
			'smartp_download',[
				'label' => __( 'Download Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$repeater->add_control(
			'plsystore',[
				'label' => __( 'Playstore Title', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'smart_stores',
			[
				'label' => __( 'Appstore Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);

		$this->add_control(
			'smartphone_rimgs',[
				'label' => __( 'Smartphone Right Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);



		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$smart_stores = $this->get_settings('smart_stores');
	?>
	<!-- Food Apps Section Start here -->
	<section class="shopapp-apps">
		<div class="container">
			<div class="row flex-row-reverse align-items-center">
				<div class="col-lg-6 col-12">
					<div class="apps-thumb">
						<?php if(!empty($settings['smartphone_rimgs']['url'])): ?>
							<img src="<?php echo wp_kses_post($settings['smartphone_rimgs']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
						<?php endif; ?>
					</div>
				</div>
				<div class="col-lg-6 col-12">
					<div class="apps-content">
						<div class="section-header">
							<h2><?php if(!empty($settings['smartphone_title'])): echo esc_html($settings['smartphone_title']); endif; ?></h2>
							<p><?php if(!empty($settings['smartphone_desc'])): echo esc_html($settings['smartphone_desc']); endif; ?></p>
							<div class="shopapp-btn-group">
								<?php 
								if(!empty($smart_stores)):
								foreach($smart_stores as $smart_store):
								?>
								<a href="#">
									<?php if(!empty($smart_store['smartp_icon']['url'])): ?>
										<img src="<?php echo wp_kses_post($smart_store['smartp_icon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
									<?php endif; ?>
									<div class="app-download">
										<p><?php if(!empty($smart_store['smartp_download'])): echo esc_html($smart_store['smartp_download']); endif; ?></p>
										<span><?php if(!empty($smart_store['plsystore'])): echo esc_html($smart_store['plsystore']); endif; ?></span>
									</div>
								</a>
								<?php
								endforeach;
								endif; 
								?>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- Food Apps Section Ending here -->
	<?php
	}



}





