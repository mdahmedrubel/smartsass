<?php
class Smartsass_Host_Global_Data_Center extends \Elementor\Widget_Base {
	public function get_name() {
		return "data_center";
	}

	public function get_title() {
		return __( "Host Data Center", 'smartsaas' );
	}

	public function get_icon() {
		return 'eicon-image';
	}

	public function get_categories() {
		return array( 'smartsaas');
	}

	protected function _register_controls() {
		$this->register_content_controls();

	}

	protected function register_content_controls() {
		$this->start_controls_section(
			'content_section',[
				'label' => __( 'Data Center Settings', 'smartsaas' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'host_titles',[
				'label' => __( 'Data Center Title Part One', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'title_part2',[
				'label' => __( 'Data Center Title Part Two', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,

			]
		);
		$this->add_control(
			'host_desc',[
				'label' => __( 'Data Center Short Content', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label_block' => true,

			]
		);
		$this->add_control(
			'host_mapbg',[
				'label' => __( 'Data Center Map Bg', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'label_block' => true,

			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name' => 'background_clr',
				'label' => __( 'Background', 'smartsaas' ),
				'types' => [ 'classic'],
				'selector' => '{{WRAPPER}} .transportation-section.style-2',
			]
		);

		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'center_name',[
				'label' => __( 'Country Name', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'flage_icon',[
				'label' => __( 'Country Flag Image', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::MEDIA,

			]
		);
		$this->add_control(
			'data_centers',
			[
				'label' => __( 'Global Data Center Section', 'TEXT' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		//country name
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'center_rname',[
				'label' => __( 'Country Name', 'smartsaas' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->add_control(
			'data_rcenters',
			[
				'label' => __( 'Global Data Center Right Content', 'TEXT' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
			]
		);
		$this->end_controls_section();

	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$data_centers = $this->get_settings('data_centers');
		$data_rcenters = $this->get_settings('data_rcenters');
		$host_mapbg = wp_get_attachment_image_url($settings['host_mapbg']['id'], 'true');
	?>
	<!-- Transportation Section Start Here -->
	<section class="transportation-section style-2 padding-tb">
	    <div class="container">
	        <div class="section-wrapper">
	            <div class="row">
	                <div class="col-lg-6 col-12">
	                    <div class="left">
	                        <div class="section-header style-2">
	                            <h2><?php if(!empty($settings['host_titles'])): echo esc_html($settings['host_titles']); endif; ?></h2>
	                            <h2><?php if(!empty($settings['title_part2'])): echo esc_html($settings['title_part2']); endif; ?></h2>
								<p><?php if(!empty($settings['host_desc'])): echo esc_html($settings['host_desc']); endif; ?></p>
	                            <ul>
	                            	<?php 
									if(!empty($data_centers)):
									foreach($data_centers as $data_center):
									?>
	                                <li>
	                                    <div class="thumb"> 
	                                    	<?php if(!empty($data_center['flage_icon']['url'])): ?>
												<img src="<?php echo wp_kses_post($data_center['flage_icon']['url']); ?>" alt="<?php bloginfo( 'name' ); ?>">
											<?php endif; ?>
	                                    </div>
	                                    <div class="content">
	                                    	<p><?php if(!empty($data_center['center_name'])): echo esc_html($data_center['center_name']); endif; ?></p>
	                                    </div>
	                                </li>
	                                <?php
									endforeach;
									endif; 
									?>
	                            </ul>
	                        </div>
	                    </div>
	                </div>
	                <div class="col-lg-6 col-12">
	                    <div class="right" <?php if(!empty($host_mapbg)): ?> style="background-image: url( <?php echo esc_url($host_mapbg); ?>);" <?php endif; ?>>
	                    	<?php 
							if(!empty($data_rcenters)):
							foreach($data_rcenters as $data_rcenter):
							?>
							<div class="lab-line">
								<span></span>
								<div class="lab-tooltip">
									<p><?php if(!empty($data_rcenter['center_rname'])): echo esc_html($data_rcenter['center_rname']); endif; ?></p>
								</div>
							</div>
							<?php
							endforeach;
							endif; 
							?>
	                    </div>
	                </div>
	            </div>
	        </div>
	    </div>
	</section>
	<!-- Transportation Section Ending Here -->
	<?php
		
	}



}





