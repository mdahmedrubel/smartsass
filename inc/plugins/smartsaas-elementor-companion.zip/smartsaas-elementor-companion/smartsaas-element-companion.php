<?php
/*
Plugin Name: Smartsaas Elementor Companion
Plugin URI: 
Description: This plugin is mandatory for Smartsaas theme. 
Version: 1.0.0
Author: CodexCoder.
Author URI: 
Text Domain: smartsaas
Domain Path: /languages/
*/
use \Elementor\Plugin as Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	die( __( "Direct Access is not allowed", 'smartsaas' ) );
}

final class Smartsaas_Elementor_Helper_Extension {

	const VERSION = "1.0.0";
	const MINIMUM_ELEMENTOR_VERSION = "2.0.0";
	const MINIMUM_PHP_VERSION = "5.6";

	private static $_instance = null;

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;

	}

	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'init' ] );
	}

	public function init() {
		load_plugin_textdomain( 'smartsaas', false, dirname( __FILE__ ) . "/languages" );

		// Check if Elementor installed and activated-----------------
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );

			return;
		}

		// Check for required Elementor version-------------------
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );

			return;
		}

		// Check for required PHP version------------------------------------
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );

			return;
		}

		////register with add action all category style css js and init here -------------------------
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );
		add_action( "elementor/elements/categories_registered", [ $this, 'register_new_category' ] );
		add_action( "elementor/frontend/after_enqueue_styles", [ $this, 'frontend_assets_styles' ] );
		add_action( "elementor/frontend/after_enqueue_scripts", [ $this, 'frontend_assets_scripts' ] );

	}

	//register all widgets js file  here --------------------------------------
	function frontend_assets_scripts(){
		//wp_enqueue_script("progressbar-js",plugins_url("/assets/js/progressbar.min.js",__FILE__),array('jquery'),'1.0',true);
		
	}


	//enqueue all widgets css file here--------------------------------------
	function frontend_assets_styles() {
		 wp_enqueue_style("smartsaas-style-css",plugins_url("/assets/css/style.css",__FILE__));
	}

	//register category for plugins---------------------------------
	public function register_new_category( $manager ) {
		$manager->add_category( 'smartsaas', [
			'title' => __( 'smartsaas Companion Widgets', 'smartsaas' ),
			'icon'  => 'fa fa-image'
		] );

	}

	/*register all widget file here*/
	public function init_widgets() {
		require_once (__DIR__."/widgets/smartsaas-banner-addon.php");
		require_once (__DIR__."/widgets/home-seo-companey-feature.php");
		require_once (__DIR__."/widgets/home-seo-smartseo-section.php");
		require_once (__DIR__."/widgets/home-seo-services.php");
		require_once (__DIR__."/widgets/home-seo-analysis-section.php");
		require_once (__DIR__."/widgets/home-seo-case-study-portfolio.php");
		require_once (__DIR__."/widgets/home-seo-pricing-plane.php");
		require_once (__DIR__."/widgets/home-seo-client-carousel.php");
		require_once (__DIR__."/widgets/home-seo-customer-love-us.php");
		require_once (__DIR__."/widgets/home-seo-blog-section.php");
		
		require_once (__DIR__."/widgets/host-monaim-checker.php");
		require_once (__DIR__."/widgets/host-global-data-center.php");
		require_once (__DIR__."/widgets/home-host-pricing-plane.php");
		require_once (__DIR__."/widgets/client-logo-section-addon.php");
		require_once (__DIR__."/widgets/footer-newsletter.php");
		require_once (__DIR__."/widgets/home-erp-companey-hr-manager.php");
		require_once (__DIR__."/widgets/home-erp-blog-section.php");
		require_once (__DIR__."/widgets/erp-foter-author-area.php");
		require_once (__DIR__."/widgets/home-vpn-about-section.php");
		require_once (__DIR__."/widgets/home-vpn-features.php");
		require_once (__DIR__."/widgets/home-vpn-pricing-plane.php");
		require_once (__DIR__."/widgets/home-vpn-how-it-works.php");
		require_once (__DIR__."/widgets/home-vpn-faq.php");

		require_once (__DIR__."/widgets/smartsaas-banner-two-addon.php");
		require_once (__DIR__."/widgets/home-pos-services.php");
		require_once (__DIR__."/widgets/home-pos-retail-store.php");
		require_once (__DIR__."/widgets/home-pos-review-carousel-addon.php");
		
		require_once (__DIR__."/widgets/home-marketing-what-we-do.php");
		require_once (__DIR__."/widgets/home-marketing-counterup-section.php");
		require_once (__DIR__."/widgets/home-marketing-pricing.php");
		require_once (__DIR__."/widgets/home-marketing-testimonials.php");
		require_once (__DIR__."/widgets/home-marketing-blog.php");

		require_once (__DIR__."/widgets/home-shopapp-about.php");
		require_once (__DIR__."/widgets/home-shopapp-services.php");
		require_once (__DIR__."/widgets/home-shopapp-pricing.php");
		require_once (__DIR__."/widgets/home-shopapp-faqs.php");
		require_once (__DIR__."/widgets/home-shopapp-smartphone-store.php");

		require_once (__DIR__."/widgets/what-is-crypto-addon.php");
		require_once (__DIR__."/widgets/benefits-of-cripto-holders.php");
		require_once (__DIR__."/widgets/invest-in-cripto-addon.php");
		require_once (__DIR__."/widgets/crypto-wallet-and-cold-storage.php");
		require_once (__DIR__."/widgets/how-crypto-works-addon.php");
		require_once (__DIR__."/widgets/home-crypto-blog-section.php");
		require_once (__DIR__."/widgets/comming-soons.php");
		require_once (__DIR__."/widgets/contact-page-form.php");
		require_once (__DIR__."/widgets/team-style-one.php");
		require_once (__DIR__."/widgets/team-style-two.php");
		require_once (__DIR__."/widgets/smartsaas-services-one.php");
		require_once (__DIR__."/widgets/smartsaas-services-two.php");
		require_once (__DIR__."/widgets/smartsaas-services-three.php");
		require_once (__DIR__."/widgets/portfolio-style-one.php");
		require_once (__DIR__."/widgets/portfolio-style-two.php");
		



		

		
		/* Register widget*/
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsaas_Banner_Extension());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Companey_Feature());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass__Seo_Section());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Seo_Services());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass__Seo_Analysis_Section());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_CaseStudy_Portfolio());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Home_Seo_Pricing_Plan());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Seo_Client_Carousel());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Seo_Customer_LoveUs());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Seo_Blog_Addon());
		
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsaas_Domain_Search_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Host_Global_Data_Center());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Home_Host_Pricing_Plan());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Logo_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Footer_NewsLetter_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Erp_Hr_Manager());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Erp_Blog_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Footer_Erp_Author_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Vpn_About());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Vpn_Features());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Home_Vpn_Pricing_Plan());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Vpn_How_It_Work());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Vpn_Faq());
		
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsaas_Banner_Two_Extension());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsaas_Home_Pos_Service());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsaas_Home_Pos_Retail_Store());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Pos_Review_Addon());

		Plugin::instance()->widgets_manager->register_widget_type(new Smartsaas_Home_Marketing_We_Do());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Marketing_Counterup());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Home_Marketing_Pricing_Plan());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Home_Marketing_Testimonials());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Home_Marketing_Blog());

		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Shopapp_About());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsaas_Home_Shopapp_Service());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Home_Shopapp_Pricing_Plan());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Home_Shopapp_Faqs());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Home_Shopapp_Smartphone());
		
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_What_Is_Crypto());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Crypto_holders());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Invest_Cripto_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Cripto_Waller_Cole_Storage());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_How_Crypto_works());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Crypto_Blog_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Comming_Soon_Addon());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Contact_Form());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Team_Style_One());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Team_Style_Two());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_One_Services());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Two_Services());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Three_Services());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Portfolio_Style_One());
		Plugin::instance()->widgets_manager->register_widget_type(new Smartsass_Portfolio_Style_Two());

	
	}



	public function admin_notice_minimum_php_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'smartsaas' ),
			'<strong>' . esc_html__( 'Elementor Test Extension', 'smartsaas' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'smartsaas' ) . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	public function admin_notice_minimum_elementor_version() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'smartsaas' ),
			'<strong>' . esc_html__( 'Elementor Test Extension', 'smartsaas' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'smartsaas' ) . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	public function admin_notice_missing_main_plugin() {
		if ( isset( $_GET['activate'] ) ) {
			unset( $_GET['activate'] );
		}

		$message = sprintf(
		/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'smartsaas' ),
			'<strong>' . esc_html__( 'Elementor Test Extension', 'smartsaas' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'smartsaas' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );


	}

}
Smartsaas_Elementor_Helper_Extension::instance();



